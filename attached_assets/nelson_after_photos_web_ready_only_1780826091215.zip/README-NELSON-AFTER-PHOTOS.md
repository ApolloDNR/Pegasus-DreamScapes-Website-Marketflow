# Nelson Dr after/listing photos — Replit-ready package

Source: Gmail email from Kristine Royeca, subject `4369 Nelson Dr. Pictures and Videos`, dated May 19, 2025. These are after/listing photos for the Nelson Dr case study.

Public project data to keep on the website:
- Project: Nelson Dr
- Location: Richmond / El Sobrante Area, CA
- Public record label where appropriate: 4369 Nelson Drive, Richmond, CA 94803
- Acquisition: around $600K
- Improvement budget: $100K
- Finished exit: $840K
- Settlement: September 2025
- Type: Value-Add Rehab / Retail Exit

Upload destination inside Replit:
`client/public/images/nelson/`

Recommended wiring:
- `nelson-hero-1280.jpg` — Nelson case study hero image
- `nelson-exterior-1280.jpg` — exterior/proof card image
- `nelson-after-1280.jpg` — main after/gallery image
- `nelson-kitchen-1280.jpg` — kitchen image
- `nelson-primary-bath-1280.jpg` — bath image
- `nelson-bedroom-1280.jpg` — bedroom image
- `nelson-patio-1280.jpg` — exterior/patio/carport detail

Important:
- These are AFTER/listing photos only.
- Do not label any of these as before or progress photos.
- Keep before/progress placeholders until actual before/progress photos are found.
- Do not publish private settlement, payoff, escrow, APN, loan, or seller-proceeds details.
- Keep the case-study disclaimer: project outcomes are illustrative and not guarantees.
