# 10_SIGNAGE — Specification
**Pegasus Dreamscapes**
Version 1.0

---

## Signage categories

| Category | Use case | Brand variant |
|---|---|---|
| Yard sign — KW context | Active KW listings (For Sale signs) | KW templated (per KW Brand Standards) |
| Yard sign — Pegasus context | "We Buy Houses" direct-to-seller marketing, off-market acquisition | Pegasus Dreamscapes brand |
| Jobsite sign | Active construction sites | Pegasus Dreamscapes brand + safety/permit info |
| Office wall sign | Pegasus office reception or wall feature | Pegasus Dreamscapes brand |
| Open house sign | KW open house directional signs | KW templated |
| Property feature sign | Marketing finished development properties | Pegasus brand or per-project marketing name |

This spec covers the Pegasus-branded signage. KW signage uses KW-issued templates and is sourced through the KW Market Center.

---

## Pegasus Yard Sign — Direct-to-Seller / "We Buy Houses"

### Use case
Acquisition marketing. Placed in target neighborhoods where Pegasus is sourcing distressed-property leads. Phone number and brand mark; nothing else.

### Specifications
- **Dimensions:** 24" wide × 18" tall (standard yard sign), or 24" × 24" for high-visibility installations
- **Material:** Coroplast (corrugated plastic) for affordable temporary use; aluminum composite for premium / longer-term placement
- **Background:** Midnight `#1A2332`
- **Border:** Thin Copper border, 0.25" inset from edge
- **Layout:**
  - Top half: Pegasus Dreamscapes primary stacked logo, centered
  - Below logo: "WE BUY HOUSES" in Inter Bold, all caps, tracking +20%, Cream `#D4CFC4`, large
  - Below headline: thin Copper rule
  - Bottom half: Phone icon (Copper outlined) + "925-948-6566" in Inter Bold, Cream, large readable from 30+ feet
  - Bottom-right corner (small): "pegasusdreamscapes.com" in Inter Regular, Cream at 80%
- **Stake:** Standard H-frame wire stake (included with most coroplast orders) or U-channel ground post for premium tier

### Doctrine note
The "We Buy Houses" copy is intentionally direct because that is the operator-vernacular for this category. Sellers searching for distressed-property buyers recognize it. The brand restraint shows up in the typography and the absence of clutter (no "FAST CASH! NO COMMISSIONS! ANY CONDITION!") rather than in softening the headline.

---

## Pegasus Jobsite Sign

### Use case
Posted on active Pegasus construction sites — both as legal/permitting signage and as brand visibility.

### Specifications
- **Dimensions:** 36" wide × 24" tall (large jobsite visibility); 24" × 18" for smaller projects
- **Material:** Aluminum composite (weatherproof, durable for project duration)
- **Background:** Midnight `#1A2332`
- **Layout:**
  - Top zone (40%): Pegasus Dreamscapes primary stacked logo, centered
  - Middle zone (30%): Project information in Inter Medium, Cream
    - "PROJECT MANAGED BY PEGASUS DREAMSCAPES"
    - Project address (smaller, optional)
    - Permit number (when required by local jurisdiction)
  - Bottom zone (30%): Contact information
    - "Construction inquiries: [Project Manager Name + Phone]"
    - "925-948-6566 | pegasusdreamscapes.com"
- **Border:** Copper rule, 0.5" inset
- **Optional safety overlay:** "HARD HAT AREA / NO TRESPASSING" in red, applied as a separate weather-resistant overlay (do not embed in branded sign — keeps brand sign clean across job phases)
- **Mounting:** Plywood-backed, posted to chain-link fence or temporary stake

### Compliance overlay
Many jurisdictions (and most general contractor licenses) require posted signage with the contractor's license number visible at the jobsite. When applicable, add a separate compliance plate (smaller, ~12"×8") posted alongside the brand sign with:
- Contractor's name
- License number
- Permit number
- Owner contact

This compliance plate is functional, not branded. Standard jobsite-sign template.

---

## Pegasus Office Wall Sign

### Use case
Reception or feature wall in Pegasus office (when office is established).

### Specifications
- **Material:** Brushed metal (copper or bronze finish) or premium acrylic with metallic finish
- **Mounting:** Standoff mounting (raised 0.5–1.0" off wall) — premium effect
- **Dimensions:** Scale to wall (typical: 36" wide × 18" tall)
- **Design:**
  - Pegasus Dreamscapes primary stacked logo, sized to wall
  - Background: wall surface (Midnight-painted accent wall preferred)
- **Lighting:** Optional uplight or backlighting for premium presentation
- **Tagline plate:** Optional separate plate below main sign with "DREAM IT. BUILD IT. LIVE IT." engraved or routed

### Doctrine note
Office signage is a long-term brand investment. Production cost is justified because the asset is photographed, used in social/web content, and seen by every visitor. Treat it as a capital expense, not a marketing expense.

---

## Property Feature Sign (Development Marketing)

### Use case
For Pegasus development projects (ground-up or substantial remodel) being marketed to buyers or tenants. Displayed on-property or at sales centers.

### Specifications
- **Dimensions:** Variable based on installation; common: 4' × 6' panel for street-facing display
- **Material:** Aluminum composite or PVC, weather-rated
- **Layout:**
  - Project marketing name (top, large, Playfair Display Bold) — e.g., "THE SENTINEL AT WALNUT CREEK"
  - Tagline / pitch (below project name, Inter Regular, Cream)
  - Visual: rendering or photography of the project
  - Pegasus Dreamscapes logo (bottom-left, smaller — supporting brand)
  - Contact info or QR code to project page (bottom-right)

This sign is **per-project** rather than a stock template. Each major development project gets its own sign design (within brand standards), because the marketing name and visual are project-specific.

---

## Sign placement protocol

### Yard signs (acquisition marketing)
- Local permitting must be respected (some municipalities prohibit off-premise signs)
- Track every sign location in Pegasus HQ as part of marketing-channel attribution
- Refresh signs every 90 days minimum (faded, knocked-over signs hurt the brand)

### Jobsite signs
- Posted within 48 hours of project start
- Removed within 7 days of project completion
- Photographed for project documentation before removal

### Office sign
- Installation coordinated with office build-out
- Photographed at completion for brand asset library

---

## Files needed in `12_VENDOR_READY/`

- [ ] `pegasus-dreamscapes_yard-sign_24x18.pdf` (print-ready)
- [ ] `pegasus-dreamscapes_yard-sign_24x18.svg`
- [ ] `pegasus-dreamscapes_jobsite-sign_36x24.pdf`
- [ ] `pegasus-dreamscapes_jobsite-sign_36x24.svg`
- [ ] `pegasus-dreamscapes_office-sign_template.pdf`
- [ ] Project feature sign template (Figma source for per-project customization)

---

## Pre-production checklist (per sign type)

- [ ] Vector files exported at exact production dimensions
- [ ] Vendor selected and quoted
- [ ] Color match (Pantone 7572 C copper) confirmed
- [ ] Material samples reviewed in person before mass production
- [ ] Mockup reviewed by Apollo
- [ ] First-production proof reviewed before run

---

*End of Signage Spec v1.0.*
