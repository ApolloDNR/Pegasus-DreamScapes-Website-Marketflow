# 10_SIGNAGE

Pegasus Dreamscapes signage across acquisition marketing, jobsite, office, and project marketing surfaces. See `Signage_Spec.md`.

## Files

| File | Status |
|---|---|
| `Signage_Spec.md` | ✓ Specification locked |
| Production-ready vector files | Pending designer + vendor quote |
| Per-project feature sign templates | Created on a per-project basis |

## What's NOT in this folder

- KW-templated yard signs and open-house signs (sourced from KW Market Center, not the Pegasus vault)
- Permit and compliance plates (functional, not branded — produced per local jurisdiction requirements)

## Production phasing

**Phase 1:** Yard sign + Jobsite sign — operational signage needed for active work
**Phase 2:** Office wall sign — when office is established
**Phase 3:** Project feature signs — per-project, on-demand
