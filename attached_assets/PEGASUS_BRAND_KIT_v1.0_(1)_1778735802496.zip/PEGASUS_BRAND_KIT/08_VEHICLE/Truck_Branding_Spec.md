# 08_VEHICLE — Truck Branding Specification
**Pegasus Dreamscapes**
Version 1.0

---

## Doctrine: restraint over saturation

The wrong instinct on vehicle branding is "wrap the whole truck." That signals contractor-tier, not operator-tier. Pegasus is a developer/operating company; the vehicle should read as a **founder's vehicle that happens to display a brand**, not a rolling billboard.

The right instinct is **subtle, premium, ownable**. Three to five carefully placed elements on a clean dark vehicle. Read at a glance. Doesn't shout.

---

## Recommended vehicle base

If choosing or selecting a vehicle for branding:
- **Color:** Midnight black, charcoal grey, or deep navy. Light vehicles (white, silver) work too but require darker decals for contrast.
- **Vehicle type:** Truck or SUV (operator credible — Apollo can show up to a jobsite or capital meeting in the same vehicle). Sedan acceptable for capital-meeting-only context.
- **Avoid:** Bright colors (red, blue), sports cars (signal mismatch), commercial vans (wrong tier — Pegasus operators don't drive panel vans).

The vehicle is brand collateral. Treat selection as a brand decision.

---

## Decal placement (locked)

Five decal positions. **No more.**

### 1. Driver door (primary brand mark)
- **Decal:** Pegasus Dreamscapes primary stacked logo
- **Size:** 12–14" wide
- **Color:** Cream + Copper on Midnight vehicle (or Midnight + Copper on Cream vehicle)
- **Finish:** Matte vinyl preferred (avoids glare); satin acceptable; gloss avoided (signals contractor-tier)
- **Optional premium tier:** Brushed metallic copper foil for the wordmark accent

### 2. Passenger door (mirror)
- Same as driver door

### 3. Tailgate (rear-facing brand mark)
- **Decal:** Pegasus Dreamscapes horizontal logo
- **Size:** 18–24" wide depending on tailgate dimensions
- **Color:** Same treatment as door decals
- **Position:** Centered horizontally; vertically positioned in upper third of tailgate

### 4. Rear window (small badge)
- **Decal:** Pegasus icon-only mark
- **Size:** 4–5" tall
- **Color:** Single-color Cream or Copper, semi-transparent vinyl
- **Position:** Bottom-right corner of rear window

### 5. Optional: subtle pinstripe accent
- **Decal:** Thin Copper pinstripe, 1/8" wide, running along the body crease line below the door handles
- **Length:** Door-to-door across both sides
- **Color:** Copper metallic vinyl
- **Function:** Adds the "branded vehicle" cue without committing to full decals

This is the maximum decal set. **No vehicle wrap. No tagline lettering. No phone number on the vehicle.** Phone numbers on vehicles signal HVAC/plumbing tier; they do not fit the operator brand.

---

## What's NOT on the vehicle

| Element | Why not |
|---|---|
| Phone number | Wrong-tier signal. Contractor vans display numbers; operating-company vehicles do not. |
| Website URL | Same reason. Curious viewers Google "Pegasus Dreamscapes." |
| Tagline lettering ("Dream it. Build it. Live it.") | Text on vehicles reads as advertising; the brand mark alone reads as identity. |
| Email address | Same as phone. |
| "Licensed and Insured" badges | Real estate/development context, not contractor-tier. |
| Multiple service-line callouts ("Real Estate • Development • Renovation") | Brand should communicate, not enumerate. |
| KW co-branding on the vehicle | Apollo's KW affiliation is professional; the Pegasus vehicle is the Pegasus brand surface. KW elements on the same vehicle dilute both brands. (KW provides agent-branded magnetic signs for showings; use those only when actively showing properties.) |
| QR codes | Visual noise on a vehicle. |

---

## Vehicle photo opportunities (brand asset)

The branded vehicle becomes a brand asset itself — photographed in front of properties, jobsites, or in interesting urban settings. These photos populate:
- Website "Approach" sections
- LinkedIn and Instagram founder content
- Press / media kit images

Photography spec:
- Shot on real project sites or aesthetically aligned urban backdrops
- Not staged in front of a generic suburban driveway
- Magic-hour lighting preferred (warm, restrained, premium)

---

## Production specifications

| Spec | Value |
|---|---|
| Vinyl type | Premium cast vinyl (3M IJ180Cv3 or equivalent) — outlasts calendar vinyl 5+ years |
| Finish | Matte (preferred) or satin |
| Colors | Cream, Copper, Midnight per `01_BRAND_GUIDE/02_Color_System.md` |
| Application | Professional installer required — not DIY |
| Removal | Vinyl chosen must be removable without paint damage (relevant for leased vehicles) |
| Warranty | Vendor-warranted minimum 5 years against fade and lift |

---

## Vendor requirements

- Local Bay Area shop preferred (Apollo can drop off and inspect)
- Must work from supplied vector files (do not let the shop redraw the logo)
- Must provide a printed proof or vehicle mockup before cutting vinyl
- Must apply Copper as Pantone-matched vinyl, not process print

Recommended request to vendor:
> Five-position decal set on [vehicle make/model/color]. Vector files supplied. Pantone 7572 C copper. Matte cast vinyl. Need a vehicle mockup before production. Quoting one vehicle now; planning a fleet of 2–3 within 12 months.

---

## Files needed in `12_VENDOR_READY/`

- [ ] `pegasus-dreamscapes_vehicle-decal_door.svg` (vector)
- [ ] `pegasus-dreamscapes_vehicle-decal_door.pdf` (print-ready)
- [ ] `pegasus-dreamscapes_vehicle-decal_tailgate.svg`
- [ ] `pegasus-dreamscapes_vehicle-decal_tailgate.pdf`
- [ ] `pegasus-dreamscapes_vehicle-decal_window-badge.svg`
- [ ] `pegasus-dreamscapes_vehicle-decal_window-badge.pdf`
- [ ] `pegasus-dreamscapes_vehicle-pinstripe.svg`
- [ ] Production spec sheet with measurements, color callouts, application notes
- [ ] Vehicle mockup PDF showing all five positions

---

## Pre-production checklist

- [ ] Vehicle confirmed (make, model, color)
- [ ] All five decal vector files exported and approved
- [ ] Vendor quoted and selected
- [ ] Vehicle mockup approved by Apollo
- [ ] Application date scheduled

---

*End of Vehicle Branding Spec v1.0.*
