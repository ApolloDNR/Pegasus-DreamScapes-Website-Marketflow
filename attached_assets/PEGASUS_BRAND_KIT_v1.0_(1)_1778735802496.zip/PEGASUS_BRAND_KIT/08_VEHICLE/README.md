# 08_VEHICLE

Pegasus Dreamscapes vehicle branding. Restraint over saturation — see `Truck_Branding_Spec.md`.

## Files

| File | Status |
|---|---|
| `Truck_Branding_Spec.md` | ✓ Specification locked |
| Production-ready vector files | Pending designer + vendor quote |
| Vehicle mockup | Pending vehicle confirmation |

## Workflow

1. Confirm specific vehicle (make / model / year / color)
2. Designer produces vector decal files at exact dimensions
3. Vendor produces vehicle mockup
4. Apollo approves mockup
5. Files move to `12_VENDOR_READY/Vehicle/`
6. Production scheduled
7. Post-installation photos added to brand asset library
