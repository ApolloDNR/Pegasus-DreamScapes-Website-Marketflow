# 03 — TYPOGRAPHY SYSTEM
**Pegasus Dreamscapes**
Version 1.0 — Locked

---

## The two fonts

Pegasus Dreamscapes uses two typefaces. Not three, not four, not five. Adding additional display, body, accent, or "secondary heading" fonts is a doctrine violation.

| Font | Role | Weight access |
|---|---|---|
| **Playfair Display** | Marketing headlines, brand wordmark, ceremonial use only | Regular 400, Bold 700, Black 900 |
| **Inter** | All UI, body copy, captions, buttons, forms, numbers, functional text | 300, 400, 500, 600, 700, 800 |

### Why these two
- **Playfair Display** — A high-contrast classical serif. Carries the "classical aesthetic" doctrine without slipping into ornamentation. Its weight contrast (thin verticals, thick horizontals) signals architectural precision.
- **Inter** — The most legible neutral sans on the web at small sizes. Variable weight access. Battle-tested in financial and enterprise UI. Does not compete with Playfair in marketing contexts; complements it in functional ones.

### Why no others
- A third "secondary heading" font creates ambiguity. Playfair handles all editorial weight. Inter handles all functional weight.
- A separate "UI font" beyond Inter is unnecessary — Inter is the UI font.
- A separate "accent font" or "small caps font" creates a sandbox-drift pattern that erodes the system. Use Inter weight 600 in uppercase tracking (+10%) for small-caps treatments.

---

## Font sourcing

### Web
- Playfair Display: Google Fonts (`<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&display=swap" rel="stylesheet">`)
- Inter: Google Fonts (`<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">`)

### Application
- Both fonts: self-host the variable font files in `/public/fonts/` with `font-display: swap` and preload the regular weights in the document head.

### Print / Adobe / Figma
- Playfair Display: Free via Google Fonts and Adobe Fonts.
- Inter: Free via Google Fonts and Adobe Fonts.
- For print vendors that don't have access: supply outlined PDFs or include the font files (both are open-licensed under SIL Open Font License).

---

## Hierarchy — Marketing surfaces (web, decks, PDFs)

| Level | Font | Weight | Size (web) | Size (print) | Notes |
|---|---|---|---|---|---|
| H1 (Hero) | Playfair Display | 900 | 64–96px | 48–72pt | Tracking -1% |
| H2 (Section) | Playfair Display | 700 | 40–56px | 28–36pt | Tracking 0 |
| H3 (Subsection) | Playfair Display | 700 | 28–36px | 20–24pt | Tracking 0 |
| Eyebrow / section label | Inter | 600 | 12–14px | 9–10pt | UPPERCASE, tracking +10% |
| Body | Inter | 400 | 16–18px | 11–12pt | Line height 1.6 |
| Caption | Inter | 400 | 12–14px | 9–10pt | Line height 1.4 |
| Quote / pull quote | Playfair Display | 400 italic | 24–32px | 16–22pt | Indented 2em |

**Marketing rule:** Playfair Display does not appear at sizes below 18px. Below that threshold, switch to Inter. Playfair's high contrast becomes illegible at small sizes.

---

## Hierarchy — Application UI (Pegasus HQ, Pegasus Systems products)

| Level | Font | Weight | Size | Notes |
|---|---|---|---|---|
| Page title | Inter | 700 | 24px | Never Playfair in app UI |
| Section header | Inter | 600 | 18px | |
| Body | Inter | 400 | 14px | Line height 1.5 |
| Label / form field | Inter | 500 | 13px | UPPERCASE, tracking +5% |
| Caption / helper text | Inter | 400 | 12px | Cream at 70% on dark |
| Number / metric (KPI tile) | Inter | 700 | 32–48px | Tabular figures enabled |
| Code / log output | Inter (with `font-feature-settings: "tnum"`) or system mono | 400 | 13px | Use system mono only when displaying actual code |

**Application rule:** Playfair Display **never** appears inside the application chrome. The application is functional. Playfair is reserved for marketing and ceremonial brand surfaces. The single exception: the Pegasus Dreamscapes wordmark, which is locked typography and remains Playfair wherever it appears.

---

## Wordmark typography

The Pegasus Dreamscapes wordmark is locked artwork:
- **PEGASUS** — Playfair Display Black, set in Cream `#D4CFC4`, tracking +50%, all caps
- **DREAMSCAPES** — Playfair Display Bold, set in Copper `#C87A3A`, tracking +30%, all caps, smaller than PEGASUS
- Optional descriptor line ("REAL ESTATE DEVELOPMENT" or "DREAM IT. BUILD IT. LIVE IT.") — Inter Medium, all caps, tracking +20%, set in Cream

The wordmark is delivered as locked vector artwork (see `02_LOGOS/Pegasus_Dreamscapes/`). It is not retypeset. If a vendor needs to set the wordmark, they receive the vector file, not font instructions.

---

## OpenType features (when supported)

Enable in CSS or in design tool typography panels:

```css
font-feature-settings: 
  "kern" 1,    /* kerning */
  "liga" 1,    /* standard ligatures */
  "calt" 1,    /* contextual alternates */
  "tnum" 1;    /* tabular numbers — REQUIRED for all financial UI */
```

**`tnum` (tabular figures) is required everywhere numbers are stacked or aligned** — proformas, ledger lines, KPI tiles, deal lists. Without it, numbers in columns will visibly shift width and undermine the investor-grade feel.

---

## Forbidden treatments

- **No font outlines** — never apply a stroke outline to text
- **No drop shadows on text** — except a subtle 1px Midnight shadow on Cream text over photography for legibility
- **No gradients on text** — copper is solid, type is solid
- **No condensed or extended variants** of either font (Inter has these; do not use them)
- **No italics in headlines** — Playfair Italic is reserved for pull quotes and editorial flourish, not section headers
- **No mixing serifs** — if Playfair is on the page, no other serif appears anywhere
- **No mixing sans-serifs** — if Inter is on the page, no other sans-serif (no Helvetica, no Arial, no Roboto, no system stack fallback in production)
- **No fake bold or fake italic** — only use weights and styles that ship with the font

---

## Fallbacks

If a system somewhere cannot load the brand fonts (legacy email clients, certain SaaS exports), use these fallbacks:

```css
/* Playfair fallback */
font-family: "Playfair Display", "Georgia", "Times New Roman", serif;

/* Inter fallback */
font-family: "Inter", -apple-system, "Helvetica Neue", "Arial", sans-serif;
```

For Word documents (vendor-shareable):
- Replace Playfair with **Georgia** as a workable serif fallback
- Replace Inter with **Arial** (per Blueprint preference for reliable rendering)

---

## Hand-off checklist for designers

- [ ] Both fonts available in design tool (Figma, Adobe, Canva)
- [ ] Wordmark received as vector artwork, not retypeset
- [ ] `tnum` enabled in any UI showing stacked numbers
- [ ] No third font introduced
- [ ] Application UI uses Inter exclusively (with the wordmark exception)
- [ ] Marketing uses Playfair for headings, Inter for body
- [ ] Output checked at minimum sizes (Playfair never under 18px)

---

*End of Typography System v1.0.*
