# 05 — LOGO USAGE GUIDE
**Pegasus Dreamscapes**
Version 1.0 — Locked

---

## The logo system

Pegasus Dreamscapes operates a **single primary mark** with controlled variants. There is no alternate logo, no fun version, no holiday version. The mark is the mark.

### Variants delivered in the vault (`02_LOGOS/Pegasus_Dreamscapes/`)

| Variant | When to use |
|---|---|
| Primary stacked (winged horse + house above wordmark) | Hero placements: business card backs, deck covers, signage, vehicle wrap centerpiece |
| Horizontal (mark left, wordmark right) | Email signatures, website header, letterhead, narrow horizontal applications |
| Icon only (winged horse + house, no wordmark) | App icons, favicons, social profile images, embroidery patches under 1.5", any case where the wordmark would be illegible |
| Wordmark only (PEGASUS DREAMSCAPES typography) | Footer rows, partner co-branding strips, situations where another logo carries the visual mark |
| Crest version | Reserved. Currently **deprecated** (see Note at end). Do not use without Apollo approval. |

---

## Color treatments delivered

For each of the variants above, the vault contains:

- **Full color on dark** — Cream + Copper on Midnight (default)
- **Full color on light** — Midnight + Copper on Cream (for printed light surfaces)
- **One-color Cream** — for use on Midnight or Navy when copper printing is not available
- **One-color Midnight** — for use on Cream when copper printing is not available
- **One-color Copper** — for use on Cream or white when a single-color metallic treatment is desired (foil stamp, copper thread)
- **Reverse / knock-out** — pure shape silhouette for sign cutting or vinyl

---

## Clear space

The minimum clear space around the logo on any surface is equal to the height of the "house" element in the wordmark. Nothing — text, images, edges, other logos — enters this space.

```
[ clear space ]
[              ]
[   ▲ LOGO ▲   ]
[              ]
[ clear space ]
```

For the icon-only mark, clear space equals 25% of the icon's width on all four sides.

---

## Minimum sizes

| Application | Minimum size |
|---|---|
| Primary stacked logo (digital) | 120px tall |
| Horizontal logo (digital) | 32px tall |
| Icon only (digital) | 24px tall |
| Favicon | 16px (delivered as `.ico` and `.png`) |
| Primary stacked (print) | 1.0" tall |
| Horizontal (print) | 0.4" tall |
| Embroidery (left chest) | 3" wide, icon + horizontal wordmark |
| Embroidery (cap) | 2.5" wide, icon only |
| Vehicle door decal | 12–18" wide (full primary stacked) |

Below minimum size, the wordmark loses legibility. Use the icon-only variant.

---

## Approved backgrounds

Always:
- Midnight `#1A2332` — preferred
- Navy `#243044` — acceptable
- Cream `#D4CFC4` — acceptable, use Midnight + Copper version
- White `#FFFFFF` — acceptable for print, use Midnight + Copper version
- Photography of architecture, neutral interiors, or jobsite settings — acceptable with sufficient contrast

Never:
- Bright or saturated colors (red, green, blue, purple, etc.) — destroys the palette
- Busy patterns or photographs without a solid color overlay
- Gradients
- Surfaces where the contrast ratio drops below 4.5:1 against the logo's primary tone

---

## Wrong-usage examples (forbidden)

- Stretching, squashing, or rotating the logo
- Recoloring the logo outside the approved palette (no green Pegasus, no rainbow Pride version, no team-color variants)
- Adding effects: drop shadows, glows, bevels, embosses (the logo already carries embossing in its vector design)
- Cropping the logo or using only part of the wing or house
- Outlining the logo
- Placing text over the logo
- Setting the logo on Copper background (copper logo on copper destroys the brand color hierarchy)
- Combining the wordmark with another company's wordmark inside a single composed graphic — co-branding uses two separate logos with appropriate clear space, never a merged lockup
- Animating the logo with bounces, spins, or fades beyond a single fade-in on page load
- Using the logo as a watermark covering content (ghost-watermark applications are permitted at 5–10% opacity)

---

## When to use which variant

| Scenario | Variant |
|---|---|
| Business card front (Pegasus card) | Primary stacked, Cream + Copper on Midnight |
| Business card back | Same primary stacked, single instance, centered |
| Pitch deck cover slide | Primary stacked, large, centered |
| Pitch deck interior slides | Horizontal in top-left corner at 20% header height |
| Website header (top of page) | Horizontal, left-aligned |
| Website footer | Wordmark only or icon, depending on layout |
| Email signature | Horizontal, 32px tall |
| App icon (Pegasus HQ on iOS/Android) | Icon only, on Midnight square with rounded corners per OS |
| Favicon | Icon only |
| Social profile picture | Icon only on Midnight |
| Social cover / banner | Horizontal with tagline below |
| Letterhead top-left | Horizontal |
| One-pager top-left | Horizontal |
| Yard sign | Primary stacked, large, centered |
| Vehicle door | Primary stacked at 12–18" |
| Vehicle rear / tailgate | Horizontal or primary stacked depending on space |
| Apparel left chest embroidery | Horizontal at 3" |
| Apparel sleeve embroidery | Icon only |
| Cap front | Icon only at 2.5" |
| Cap back closure strap | Wordmark only at 2" |

---

## Co-branding (Pegasus Dreamscapes + Keller Williams)

When both brands appear on the same surface:

1. Pegasus Dreamscapes and KW logos are **separated by a vertical rule** (1px Copper, full content height) — never overlapping, never merged.
2. Pegasus dominant: when Apollo is acting primarily as a Pegasus founder with the KW affiliation as compliance disclosure (e.g., the dual-brand business card), Pegasus logo is sized 1.5x larger than the KW logo and placed left or top.
3. KW dominant: only on KW-prescribed templates (KW-issued listing presentations, KW-templated marketing). On these, Pegasus does not appear at all, or appears only as a compliance footer line.
4. Compliance: KW co-branded materials must include the brokerage name "Keller Williams Realty," Apollo's DRE license number, and Equal Housing logo per CA real estate advertising rules. See `_COMPLIANCE/KW_Compliance_Requirements.md`.

---

## Note on the crest variant (DEPRECATED)

The crest version of the logo (winged horse with shield, crown, and laurel — seen in earlier exploration mockups) is **not part of the active brand system**. It violates the Pegasus restraint doctrine: heraldry, crowns, and laurels read as overdecoration, not classical authority.

The crest exists in the archive for historical reference only. Do not use on any active brand surface. Designers requesting "the crest version" should be redirected to the primary stacked logo.

---

## Vendor hand-off

When sending logo files to a vendor:

- [ ] Send the appropriate variant for their use case (don't send the full kit unless requested)
- [ ] Send vector (SVG, PDF, or AI) for any production work; PNG only for digital placeholder
- [ ] Include the color spec (`02_Color_System.md`) and this usage guide
- [ ] Specify the minimum size for their application
- [ ] Specify the background the logo will sit on
- [ ] For print: specify Pantone or copper foil if applicable
- [ ] For embroidery: specify Madeira thread color
- [ ] Require vendor to send a proof for review before mass production

---

*End of Logo Usage Guide v1.0.*
