# 01_BRAND_GUIDE

The doctrine layer. Everything in the rest of the vault flows from here.

## Documents

| File | Purpose |
|---|---|
| `01_Master_Brand_Bible.md` | Identity, mission, vision, values, founder story. The parent of all other docs. |
| `02_Color_System.md` | Locked four-color palette. HEX/RGB/CMYK/Pantone. Five Uses Rule for copper. |
| `03_Typography_System.md` | Locked two fonts (Playfair Display + Inter). Hierarchy, sizes, OpenType features. |
| `04_Voice_and_Tone.md` | Voice attributes, audience-specific tone, word/sentence/document rules. Side-by-side examples. |
| `05_Logo_Usage_Guide.md` | When/how to use which variant. Clear space, minimums, forbidden treatments, co-branding rules. |
| `06_Brand_Architecture.md` | Parent → arms → sub-brand → products. Naming and endorsement strategy. |

## Reading order for new vendors

1. Master Brand Bible (10 min) — get the identity
2. Color System (5 min) — internalize palette + Five Uses Rule
3. Typography System (5 min) — internalize the two-font lock
4. Logo Usage Guide (5 min) — know what NOT to do
5. Voice & Tone (10 min) — for any copy work
6. Brand Architecture (5 min) — for any multi-entity work

A vendor who has not read at least the first three documents should not be producing branded work for Pegasus Dreamscapes.

## Versioning

These documents are doctrine. Changes require:
- Apollo approval
- Version increment (v1.0 → v1.1)
- Cascade updates to dependent vault docs
- Old version archived (never deleted) — append-only

## Eventual deliverables

Once locked, these six documents become the source for:
- A consolidated **Brand Bible PDF** (vendor hand-off package)
- A **Notion / web-based brand portal** for designers
- A **one-page brand summary** for partner co-branding requests

These are downstream artifacts; the markdown source files in this folder are the truth.
