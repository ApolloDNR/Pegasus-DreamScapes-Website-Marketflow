# 04 — VOICE & TONE
**Pegasus Dreamscapes**
Version 1.0 — Locked

---

## The voice in one sentence

A founder who has done the work, knows the numbers, and has nothing to prove.

---

## Voice attributes (always-on)

These never change regardless of audience or surface:

1. **Direct.** Lead with the conclusion. The reader's time is the asset.
2. **Specific.** Cite numbers, dates, addresses, names whenever they exist. Vague language signals you don't know.
3. **Operator-mature.** Treat the reader as a peer who's done deals. Never explain what they already know.
4. **Quietly confident.** Conviction without volume. Never use exclamation points except in literal quotes.
5. **Doctrine-bound.** Reference systems and templates, not vibes. "Per the strategy doctrine" beats "we like to think about it this way."

## Tone shifts (audience-dependent)

Voice stays constant. Tone shifts:

| Audience | Tone | Example move |
|---|---|---|
| Capital partners / sophisticated investors | Crisp, schematic, numbers-first | Lead with deal-level economics, cite the proforma, state the ask in dollars |
| Distressed sellers | Calm, respectful, low-pressure | Acknowledge their situation, state what we do plainly, offer specific next step |
| Retail buyers / KW context | Warm, knowledgeable, fiduciary | Lead with their goal, demonstrate market knowledge, never sell harder than they're buying |
| Contractors / vendors | Practical, scope-clear, paying-on-time | Specify scope, timeline, payment terms; assume professional competence |
| Internal team | Doctrinal, decisive, reference-heavy | Cite the Blueprint section or vault doc; minimize debate-by-Slack |
| Marketing / public | Aspirational but grounded | Lead with concrete project specifics; let the work speak louder than adjectives |

---

## Word-level rules

### Always
- Use active voice. ("We acquired the property" not "The property was acquired by us.")
- Use the Oxford comma.
- Spell out numbers under 10 in narrative copy ("eight contractors") but use numerals in financial copy ("8 units," "$840K ARV").
- Capitalize product names exactly: Pegasus HQ, BuildForge, CapStack, MarketFlow, Peggy.
- Capitalize doctrine terms when referencing them by name: the Strategy Approval, the War Room, the Pegasus Stamp.

### Never
- "Just" as a softener ("we just wanted to follow up")
- "Really," "truly," "literally" as intensifiers
- "Reach out" — use "contact," "email," "call"
- "Synergy," "leverage" (as a verb), "best-in-class," "cutting-edge," "world-class"
- "Excited to announce" — start with what was announced
- "Game-changer," "disruptor," "ninja," "rockstar"
- "Passionate" — show it through specificity, don't claim it
- AI-tells: "It's worth noting that…," "Let's dive in," "In today's fast-paced world…"
- "Going forward" — use "from now on," or omit entirely
- Emojis in any business communication

### Hedge words to cut
"Should probably," "maybe," "kind of," "sort of," "I think," "I feel like." If you need to hedge a recommendation, hedge with a number: "60% confidence," not "I think maybe."

---

## Sentence-level rules

- Open with the strongest sentence in the paragraph. Edit until that's true.
- Vary sentence length aggressively. Three short sentences. Then one longer one that earns the breath. Then short again.
- One idea per sentence in operator copy. Multi-clause sentences are reserved for narrative founder copy (where flow matters more than scan).
- End paragraphs with the most quotable line, not a transition.

---

## Document-level rules

- Lead with the conclusion. State what you're recommending in the first 100 words. Then defend it.
- If the document is over 500 words, add headers. Operators scan; they don't read.
- Use numbered lists for sequence-dependent content. Bulleted lists for parallel options.
- Include specifics: dollar amounts, percentages, dates, addresses, named parties. A document without specifics is a document a competitor wrote.

---

## Side-by-side examples

### Example 1: Property acquisition email

**Wrong:**
> Hi Mr. Smith! I just wanted to reach out and let you know that we're a really passionate, dynamic team that's super excited about the possibility of working with you on your home. We'd love to hop on a quick call to chat about your situation and see how we can help! 😊

**Right:**
> Mr. Smith — I'm Apollo Duran with Pegasus Dreamscapes. We're a Bay Area operator that buys distressed properties direct, all-cash, and closes in 14 days. I'd like to walk the property at 1234 Elm and put a number on the table by Friday. Would Tuesday at 10am or Wednesday at 2pm work?

### Example 2: Investor update

**Wrong:**
> Q3 was an incredible journey for the Pegasus team! We're truly excited to share that we've been crushing it on the operational side and have some really exciting opportunities in the pipeline.

**Right:**
> Q3 closed two acquisitions (Concord SFR, Walnut Creek BRRRR) at a blended 14% projected IRR. Three additional deals are under LOI. Construction at the Concord property is on schedule for Nov 18 completion; ARV holds at $840K against $612K all-in basis.

### Example 3: Website hero

**Wrong:**
> Pegasus Dreamscapes is a passionate, dynamic real estate company that leverages cutting-edge systems to deliver world-class results for our valued clients and partners.

**Right:**
> Pegasus Dreamscapes is a vertically integrated real estate operating company. We acquire, develop, and operate properties across the Bay Area and Sacramento — using software we built ourselves.

### Example 4: Contractor scope confirmation

**Wrong:**
> Hey Mike, just wanted to circle back and see if we're all good to go on the kitchen stuff for next week. Let me know if you need anything from us! Thanks so much! 🙌

**Right:**
> Mike — confirming kitchen demo + rough-in starts Monday 11/4 at 1234 Elm. Scope per the SOW dated 10/28: full demo to studs, R&R cabinets, plumbing rough-in, electrical rough-in. Payment milestone 1 ($14,200) will release upon rough-in inspection pass. Call me by Friday if anything's blocking.

---

## Voice for specific surfaces

### Business cards
- Founder card: title is "Founder" or "Founder, Pegasus Dreamscapes." Not "CEO & Founder." Not "Visionary." Not "Operator." Founder.
- KW card: title is "Realtor" with the registered trademark symbol. Compliance copy as required.
- Dual card: "Founder, Pegasus Dreamscapes | Realtor®, Keller Williams" with the broker affiliation in compliance form.

### Email signatures
- Three lines maximum: Name + Title, Company, Phone | Email.
- No quotes, no inspirational signatures, no "Sent from my iPhone" defaults.
- Pegasus signature uses Cream text on Midnight block. KW signature follows KW brand standards (red wordmark, black text, white background).

### Social media
- Captions follow the same voice rules as everything else. Investor-grade tone, even on Instagram.
- No emojis. The brand's discipline is the brand's voice.
- Hashtags placed at the end of the caption, not woven in. Maximum five.

### Internal Slack / docs
- Doctrine-bound. Reference Blueprint sections by number. Reference vault docs by path.
- Decisions get logged in the relevant vault doc, not in Slack threads. Slack is the conversation; the vault is the record.

---

## When the voice should soften

Three contexts where the default crispness should warm:

1. **Distressed seller conversations.** The person is often in financial or emotional distress. Lead with humanity. Stay direct, but slow the pace and use the seller's name.
2. **Founder's personal narrative.** When Apollo is telling his own story (founder bio, podcast intro, personal LinkedIn post), the tone can carry more first-person reflection. Still no AI hedges, still no exclamation points, but more "I" and more arc.
3. **Family-oriented community marketing.** When marketing developments to end-residents (homebuyers, renters), warmth matters more than schema. Still specific, still architectural, but the audience is buying a home — the voice should respect that.

---

## When in doubt

Read the sentence aloud. Would you say it to a senior capital partner across a desk? If you'd be embarrassed to say it, don't write it.

If you'd write it but wouldn't say it, rewrite it as if you were saying it.

The brand voice is whatever a disciplined founder would actually say.

---

*End of Voice & Tone v1.0.*
