# 06 — BRAND ARCHITECTURE
**Pegasus Dreamscapes**
Version 1.0 — Locked

---

## The architecture in one diagram

```
┌──────────────────────────────────────────────────────┐
│                                                      │
│              PEGASUS DREAMSCAPES                     │
│            (parent operating company)                │
│                                                      │
└────────────┬───────────────┬─────────────┬───────────┘
             │               │             │
   ┌─────────▼──────┐  ┌─────▼──────┐  ┌──▼──────────┐
   │  DEVELOPMENT   │  │ INVESTMENTS│  │   SYSTEMS   │
   │                │  │            │  │ (Pegasus    │
   │ • Ground-up    │  │ • BRRRR    │  │  Systems)   │
   │ • Value-add    │  │ • Flip     │  │             │
   │ • Renovation   │  │ • Whole-   │  │ Software    │
   │                │  │   sale     │  │ infra arm   │
   │                │  │ • Hold     │  │             │
   └────────────────┘  └────────────┘  └──────┬──────┘
                                              │
                       ┌──────────┬───────────┼───────────┬──────────┐
                       │          │           │           │          │
                  ┌────▼───┐ ┌────▼─────┐ ┌──▼───────┐ ┌─▼────────┐ ┌▼──────┐
                  │PEGASUS │ │BUILDFORGE│ │ CAPSTACK │ │MARKETFLOW│ │ PEGGY │
                  │   HQ   │ │          │ │          │ │          │ │ (AI)  │
                  └────────┘ └──────────┘ └──────────┘ └──────────┘ └───────┘
```

---

## Naming hierarchy and branding rules

### Tier 1 — Parent company

**Pegasus Dreamscapes**

This is the brand that lives on business cards, the website domain, the vehicle, the apparel, and Apollo's title. When in doubt, this is the brand that appears.

- Public-facing: "Pegasus Dreamscapes"
- Legal/contractual: "Pegasus Dreamscapes Corp"
- Never abbreviated: do not use "PD," "Pegasus," or "Dreamscapes" alone in formal contexts
- Tagline: "Dream it. Build it. Live it."

### Tier 2 — Operational arms (three)

**Development. Investments. Systems.**

These are the three operating arms of the parent. They do not have separate brand identities — they share the parent's logo and palette. They are referenced by name when context-relevant ("Pegasus Dreamscapes Development," "Pegasus Dreamscapes Investments," "Pegasus Systems").

- Development and Investments do not get their own logos. They are operational categories under the parent brand.
- **Systems is the exception.** "Pegasus Systems" is the public-facing name of the software arm and gets its own visual sub-identity (see Tier 2.5 below) because it has external customers, its own products, and its own market positioning.

### Tier 2.5 — Pegasus Systems (the software arm)

**Pegasus Systems**

Pegasus Systems is the operating infrastructure arm of Pegasus Dreamscapes. It builds the tools, intelligence, and workflows that power disciplined real estate execution — first for Pegasus Dreamscapes itself (dogfood), then licensed to the broader operator market (SaaS).

- Tagline (descriptor): "Operating infrastructure for disciplined real estate execution."
- Visual identity: shares the Pegasus Dreamscapes color palette and typography, but uses its own wordmark variant ("PEGASUS SYSTEMS") for product surfaces and SaaS marketing.
- Relationship to parent: clearly disclosed. Pegasus Systems marketing refers to Pegasus Dreamscapes as the "founding operator and dogfood customer," establishing credibility without ambiguity about ownership.

### Tier 3 — Product fleet (under Pegasus Systems)

The five products. Each has its own:
- App icon
- Wordmark
- Single-line description
- Tagline
- Position within the authority hierarchy (per Blueprint Doctrine 9: HQ commands → Fleet proposes → Peggy advises)

| Product | Role | Tagline (working) |
|---|---|---|
| **Pegasus HQ** | Command core / source of truth / deal execution OS | Command core for real estate execution. |
| **BuildForge** | Construction execution / development workflows | Construction execution, built with discipline. |
| **CapStack** | Capital management / investor tracking / funding structure | Capital structure with clarity. |
| **MarketFlow** | Deal distribution / listings / market pipeline | Move opportunities through the market. |
| **Peggy** | AI advisor / intelligence layer | Intelligence at every step. |

Product names are written exactly as shown — capitalization, spacing, no spaces inside compound names. (`BuildForge` not `Build Forge`. `CapStack` not `Cap Stack`.)

---

## Endorsement strategy

How each entity references its parent:

| Entity | Endorsement line on its surfaces |
|---|---|
| Pegasus Dreamscapes (parent) | None — it is the parent. |
| Pegasus Systems | "An operating company of Pegasus Dreamscapes" (in footer or about section) |
| Pegasus HQ | "By Pegasus Systems" (in product chrome footer; in App Store description) |
| BuildForge, CapStack, MarketFlow | Same: "By Pegasus Systems" |
| Peggy | "By Pegasus Systems" (and inside the app: "Peggy is your Pegasus Systems advisor") |

This creates the chain: User sees Peggy → connected to Pegasus Systems → connected to Pegasus Dreamscapes. The parent is never hidden, but the products lead with their own identity.

---

## What the architecture is not

- **Not a sub-brand zoo.** Pegasus Dreamscapes will not spawn dozens of separate brands. Three arms, one software sub-brand, five products. That's the system.
- **Not a holding-company vibe.** The architecture is operator-led, not portfolio-led. Pegasus Dreamscapes does the work; Pegasus Systems builds the tools for the work; products are the tools.
- **Not negotiable per project.** A new development project does not get its own brand. It operates under Pegasus Dreamscapes Development. Marketing materials may reference the project name (e.g., "The Sentinel at Walnut Creek") but the originating brand is always Pegasus Dreamscapes.

---

## When to add a new entity to the architecture

Adding a new tier-2 arm, a new product, or a new sub-brand requires:

1. A clear category gap (the existing entities cannot reasonably absorb the new function)
2. A documented business case (revenue, customer, strategic rationale)
3. Apollo approval + Blueprint version increment
4. A naming decision logged in this document
5. A visual identity decision logged in `02_LOGOS/` and `01_BRAND_GUIDE/`

This is intentionally hard. The brand earns its discipline by refusing to expand without cause.

---

## Project naming conventions

Individual projects (specific properties, developments, deals) use this format:

- **Address-based (operational):** "1234 Elm — Concord SFR" (used in CRM, internal docs, deal records)
- **Marketing names (development projects only):** "The Sentinel at Walnut Creek" — must be Apollo-approved, must not conflict with existing trademarks, must complement (not compete with) the Pegasus Dreamscapes brand

Marketing names are scarce. A wholesale or single fix-and-flip does not need one. Ground-up developments and held-asset properties do.

---

## Guadalajara legacy project

The long-term Guadalajara, Jalisco development project will likely receive its own marketing name (TBD) when it activates. It remains under the Pegasus Dreamscapes Development arm and will follow the architecture rules above. This is flagged here because of its strategic importance and the likelihood of bilingual (English/Spanish) brand assets at that time.

---

*End of Brand Architecture v1.0.*
