# 02 — COLOR SYSTEM
**Pegasus Dreamscapes**
Version 1.0 — Locked

---

## The four colors

Pegasus Dreamscapes uses a four-color palette. There is no fifth color. Silver, steel, gold, white, and any additional metallic are **not** part of the palette and will not be added.

| Color | HEX | RGB | CMYK | Pantone (closest) |
|---|---|---|---|---|
| Midnight | `#1A2332` | `26, 35, 50` | `89, 79, 53, 65` | PMS 539 C |
| Navy | `#243044` | `36, 48, 68` | `87, 75, 47, 47` | PMS 5395 C |
| Copper | `#C87A3A` | `200, 122, 58` | `15, 60, 90, 5` | PMS 7572 C |
| Cream | `#D4CFC4` | `212, 207, 196` | `5, 5, 12, 5` | PMS Warm Gray 2 C |

---

## Surface roles

| Surface | Color | Notes |
|---|---|---|
| Primary background (dark mode app, marketing dark surfaces) | Midnight `#1A2332` | The default canvas |
| Secondary background, panels, cards | Navy `#243044` | Adds depth without leaving the dark family |
| Authority accent, CTAs, active-state indicators | Copper `#C87A3A` | See "Five Uses Rule" below |
| Light surfaces (printed contact strips, document body, scoped light panels) | Cream `#D4CFC4` | Warm, never pure white |
| Body text on dark | Cream `#D4CFC4` at 90% | Reduces eye strain vs. pure white |
| Body text on light | Midnight `#1A2332` | Always Midnight on Cream, never Navy |

**Pure white (`#FFFFFF`) is not in the palette.** When a near-white is needed (e.g., for legibility on Midnight), use Cream. This keeps the brand consistently warm.

---

## The Five Uses Rule (Copper)

Copper is the authority signal. It is not decoration. Its scarcity is what makes it work. Across any given surface — a webpage, a card, a slide, a screen — copper appears in **at most five distinct uses**. There is no sixth.

**The five permitted uses:**

1. **Primary CTAs** — buttons that command action ("Approve Strategy," "Submit Bid")
2. **Section labels and tags** — small caps copper text marking section types
3. **Active-state indicators** — the 4px left-edge bar on the active sidebar item; the underline on an active tab
4. **Brand wordmark accents** — the "DREAMSCAPES" line of the logo; the diamond accent in the contact card
5. **Authority lines** — thin copper rules (1px) that separate authority blocks (founder name from title, deal address from status)

**Copper is never used for:**
- Long-form body text (illegibility on either Midnight or Cream)
- Decorative borders around entire pages or large blocks
- Backgrounds of any surface larger than a button
- Gradients (copper must read as solid metal)
- Hover states for non-CTA elements (use Cream tint instead)

**Visual share:** Across any composed surface, copper occupies **~20% maximum** of the visual weight. If a vendor, designer, or template appears to use copper more than this, it is a doctrine violation and must be reduced.

---

## Mode strategy

### Dark mode (primary)
- Background: Midnight `#1A2332`
- Panels: Navy `#243044`
- Text: Cream `#D4CFC4` (body) / `#FFFFFF` at 95% (only for high-contrast headlines, used sparingly)
- Accents: Copper `#C87A3A`

This is the default for:
- Pegasus HQ application UI
- Pegasus Systems product surfaces
- Marketing site hero sections
- Pitch decks
- Business card backs
- Vehicle wraps
- Apparel embroidery base

### Light mode (scoped)
- Background: Cream `#D4CFC4`
- Panels: pure white at low usage
- Text: Midnight `#1A2332`
- Accents: Copper `#C87A3A`

Permitted for:
- Document body (letterhead, proposals, one-pagers)
- Printed business card contact strips (where dark would impede readability of legal copy)
- Specific app surfaces explicitly designed for light treatment (e.g., printable invoice views)

Light mode is **never** the default for marketing or app UI.

---

## Accessibility

Contrast ratios (WCAG):

| Combination | Ratio | Status |
|---|---|---|
| Cream `#D4CFC4` on Midnight `#1A2332` | 11.8:1 | AAA ✓ |
| Cream `#D4CFC4` on Navy `#243044` | 8.4:1 | AAA ✓ |
| Copper `#C87A3A` on Midnight `#1A2332` | 5.1:1 | AA ✓ (large text AAA) |
| Copper `#C87A3A` on Navy `#243044` | 3.6:1 | AA large text only ⚠️ |
| Midnight `#1A2332` on Cream `#D4CFC4` | 11.8:1 | AAA ✓ |
| Copper `#C87A3A` on Cream `#D4CFC4` | 2.4:1 | Fails AA — never use copper text on cream |

**Compliance rules:**
- Never set copper as body text on cream — it fails contrast.
- Copper on Navy is only acceptable for large-text headlines (24px+) or non-text accents (rules, dots, icons).
- All body text must hit AAA (7:1) — use the Cream-on-Midnight pairing as default.

---

## Print specifications

For print vendors (business cards, signage, vehicle wraps, apparel):

- Always supply **CMYK** values, not RGB.
- For copper specifically: request a **Pantone match (PMS 7572 C)** when the budget allows. Process CMYK copper drifts toward orange or muddy brown depending on press; Pantone holds the metallic quality.
- For premium business cards: specify **copper foil stamp** for the wordmark accent rather than printed copper. The metallic foil is the brand's most defensible physical signal.
- For embroidery: copper thread color reference is **Madeira Polyneon 1623 (Copper)** or equivalent. Confirm thread match before mass production.

---

## Hand-off checklist for designers

When delivering work to a vendor, include:

- [ ] HEX values for digital
- [ ] RGB values for digital
- [ ] CMYK values for print
- [ ] Pantone reference for copper (PMS 7572 C)
- [ ] Copper foil specification when applicable
- [ ] Madeira thread reference for embroidery when applicable
- [ ] This document's link or attached PDF

---

*End of Color System v1.0.*
