# 01 — MASTER BRAND BIBLE
**Pegasus Dreamscapes**
Version 1.0 — Founding Lock

---

## Section 1 — Identity

### Legal entity
Pegasus Dreamscapes Corp — California S-Corporation.

### Public-facing brand
**Pegasus Dreamscapes**

### Tagline
**Dream it. Build it. Live it.**

Three verbs in deliberate sequence: vision, execution, occupation. Mirrors the company's vertical integration — we don't hand off between phases, we own them. Always written with periods, never commas. Title case, no italics.

### Founder
Apollo Duran (legal: Paolo Duran). Founder, CEO. Holds an active California real estate license through Keller Williams. Currently pursuing California contractor license.

---

## Section 2 — Brand Architecture

Pegasus Dreamscapes is a vertically integrated real estate operating company with three operational arms:

```
                   PEGASUS DREAMSCAPES
                  (parent operating company)
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
   DEVELOPMENT         INVESTMENTS         SYSTEMS
   (build & flip)      (capital deploy)    (Pegasus Systems)
                                                 │
                          ┌──────────┬───────────┼──────────┬──────────┐
                          │          │           │          │          │
                       PEGASUS    BUILD-      CAP-       MARKET-     PEGGY
                          HQ      FORGE       STACK      FLOW       (AI)
```

**Naming conventions:**
- The parent company is *Pegasus Dreamscapes* in marketing, *Pegasus Dreamscapes Corp* in legal/contractual contexts.
- The software arm is *Pegasus Systems* publicly, never abbreviated to "Systems" alone.
- Product names are always written exactly: Pegasus HQ, BuildForge, CapStack, MarketFlow, Peggy. No spaces in BuildForge, CapStack, MarketFlow.
- *FundBase* is dead. Permanently merged into CapStack. Never reference.

---

## Section 3 — Mission, Vision, Values

### Mission
To turn distressed properties into designed investments through disciplined operational systems and classical aesthetic execution.

### Vision
A vertically integrated real estate operating company that develops communities ground-up, deploys generational capital, and operates the software infrastructure the rest of the industry will eventually run on.

### Core values (locked — do not modify)
1. **Discipline** — Architecture before building. No shortcuts.
2. **Transparency** — Investor-grade documentation at every layer.
3. **Innovation** — Build the operating system, don't rent it.
4. **Integrity** — The deal is the deal. The doctrine is the doctrine.
5. **Excellence** — Classical execution. Premium finish. No "good enough."
6. **Efficiency** — Templates are the doctrine. Repeatable systems > heroic effort.

### Brand positioning statement
For real estate operators who refuse to let chaos compound, Pegasus Dreamscapes is a vertically integrated operating company that builds, invests, and operates real estate using its own software infrastructure — because outsourced systems and ad-hoc execution cap the ceiling.

### Where distressed properties become designed investments.
This is the operator-facing tagline. Use in pitch decks, capital conversations, project case studies. Do not confuse with "Dream it. Build it. Live it." which is the public-facing tagline.

---

## Section 4 — Brand Personality

| Pegasus Dreamscapes is | Pegasus Dreamscapes is not |
|---|---|
| Disciplined | Rigid |
| Premium | Snobbish |
| Classical | Old-fashioned |
| Visionary | Speculative |
| Operator-mature | Hustle-culture |
| Quiet authority | Loud salesmanship |
| Architectural | Decorative |
| Confident | Arrogant |

**The voice you hear in your head when reading a Pegasus document:** A founder who has done the work, knows the numbers, and has nothing to prove. Concise. Direct. Cites specifics. Does not hedge. Does not apologize. Does not perform.

---

## Section 5 — Voice & Tone (summary; full guide in `04_Voice_and_Tone.md`)

**Default register:** Investor-grade. Schema-level. No fluff.

**Always:**
- Lead with the conclusion.
- Cite specifics (numbers, dates, addresses, names) when available.
- Use active voice.
- Treat the reader as a peer.

**Never:**
- "We're excited to announce…"
- "Pegasus is a passionate, dynamic, innovative…"
- "Synergy," "leverage" (as a verb), "cutting-edge," "best-in-class"
- "Just," "really," "truly," "literally"
- AI-sounding hedges: "It's worth noting that…" / "It's important to remember…"
- Emojis in any business communication

---

## Section 6 — Visual Identity (summary; full specs in `02_Color_System.md` and `03_Typography_System.md`)

**Color palette (locked, four colors):**
- Midnight `#1A2332` — backgrounds, primary surfaces
- Navy `#243044` — secondary surfaces, depth
- Copper `#C87A3A` — authority signal, never decoration
- Cream `#D4CFC4` — light surfaces, body copy contrast on dark

**Typography (locked, two fonts):**
- Playfair Display — marketing headlines, brand wordmark, ceremonial use only
- Inter — all UI, body copy, captions, functional text

**Visual motifs (approved):**
- Pegasus wing
- Roofline (the "house" silhouette in the wordmark)
- Architectural linework (thin copper rules)
- Diamond accent (small copper diamond used as section separator)
- Chevron (forward motion, used sparingly on contact cards)

**Visual motifs (rejected — do not use):**
- Crown
- Shield with laurel
- Ornate heraldry beyond the existing wordmark
- Gradients on copper (it should always read as solid metal, not glowing)
- Drop shadows beyond subtle embossing

---

## Section 7 — Founder Story (short version)

Apollo Duran started building businesses in high school — day trading, flooring coordination, project management. By 24, he was operating Pegasus Dreamscapes alongside his father (a licensed general contractor) and partner (an interior designer), having completed his first fix-and-flip and wholesale deal in Contra Costa County. The company is structured to do something most operators don't: build the software that runs it. Pegasus Systems — the technology arm — is being developed in parallel with the operating company itself, on the principle that the operators who own their infrastructure end up owning their margins.

*Use this verbatim or adapt by section. Do not add adjectives.*

---

## Section 8 — Long-form Company Description

Pegasus Dreamscapes is a vertically integrated real estate operating company headquartered in the San Francisco Bay Area, focused on the Bay Area, Sacramento, and a long-term legacy development project in Guadalajara, Jalisco. The company operates across three arms: Development (ground-up and value-add construction), Investments (capital deployment across BRRRR, fix-and-flip, wholesale, and held assets), and Systems (Pegasus Systems — the software arm building the operating infrastructure for disciplined real estate execution). The company is built on classical architectural aesthetics, operator-first product design, and an append-only documentation doctrine that treats every deal as a permanent record. Pegasus Dreamscapes does not outsource its operating system — it builds it.

---

## Section 9 — Architectural Notes

This Brand Bible is the parent of every other document in the vault. If a vendor, designer, or team member encounters a conflict between this document and any other vault document, this document wins. Any change to this document requires:

1. A documented reason
2. A version increment
3. Cascade updates to dependent specs

The vault is append-only. Old versions of this Bible are archived, never deleted.

---

*End of Master Brand Bible v1.0.*
