# DRE License Placement Guide
**Pegasus Dreamscapes — Apollo Duran (Paolo Duran)**
Version 1.0 — Operational guidance, not legal advice

---

## What this document is

A practical reference for where Apollo's California DRE license number must appear, what format it must take, and what minimum legibility standards apply.

This is the operational implementation of the requirement documented in `01_KW_Compliance_Requirements.md` Section 2.

---

## The legal basis

California Business and Professions Code §10140.6 requires:

> Any solicitation materials intended to be the first point of contact with consumers and any real property purchase agreements when the licensee is acting as an agent in those transactions shall contain the license name and license number of the real estate licensee.

Plain language: if Apollo's marketing reaches a consumer (potential buyer, seller, or client) and the consumer might use that material to decide whether to engage him, his DRE license must be present and legible.

---

## Required placement (every surface)

| Surface | DRE placement requirement |
|---|---|
| KW business card | Front of card, bottom edge |
| Dual-brand business card | Front of card, bottom edge of Cream strip |
| Pegasus-only business card | Not required (no KW affiliation present) |
| Email signature (KW account) | Below name and brokerage line |
| Email signature (Dual brand) | In compliance line below contact info |
| Email signature (Pegasus account) | Not required (Pegasus business, not KW solicitation) |
| KW yard sign | Bottom of sign, legible from sidewalk |
| Pegasus yard sign | Not required (Pegasus is principal buyer, not soliciting agent representation) |
| KW open house sign | Bottom of sign |
| KW listing flyer | Bottom of every page; or footer if multi-page |
| Apollo's KW agent web page | Header or footer of every page |
| LinkedIn (when listing Realtor® role) | In the role description for KW agent position |
| Instagram bio (if marketing as KW agent) | Required if the bio mentions Realtor® services |
| Pegasus Dreamscapes website | Required only on pages mentioning Apollo's Realtor® role; not required on general operating-company pages |
| Marketing emails to prospective KW clients | Footer disclosure block |

---

## Format

### Acceptable format strings
- `DRE License #01234567`
- `CalDRE #01234567`
- `DRE #01234567`
- `California Real Estate License #01234567`
- `License #01234567 (CalDRE)`

### Not acceptable
- License number alone with no agency reference (`#01234567`)
- License number embedded in unrelated copy without clear "DRE" or "CalDRE" identification
- License number obscured by graphic elements
- License number below 6pt type or otherwise illegible

---

## Minimum legibility

| Surface | Minimum size |
|---|---|
| Print business card | 6pt |
| Print signage (small, e.g., yard sign) | Sized to be readable from 5–10 feet |
| Print signage (large, e.g., property feature sign) | Sized to be readable at intended viewing distance |
| Digital marketing | 11px on standard screens; 9pt in PDFs |
| Email signature | Minimum 10pt |
| Web page footer | Minimum 12px (CSS) |

The DRE rule does not specify exact sizes — it specifies "easily readable." The values above are operational defaults that comply in practice.

---

## Color and contrast

The DRE number must have sufficient contrast against its background to be easily readable. Per WCAG accessibility standards:

- Minimum 4.5:1 contrast ratio against background
- Use Cream `#D4CFC4` or Midnight `#1A2332` (high-contrast brand colors), not Copper (which fails contrast at small sizes against most brand backgrounds)

Avoid placing the DRE number in:
- Decorative panels with low contrast
- Watermark-style backgrounds
- Color combinations that fail standard contrast checks

---

## When the DRE number changes (rare)

If Apollo's DRE license number ever changes (license renewal does not change the number; reactivation after lapse may; transfer between brokerages does not), every brand asset displaying the number must be:

1. Identified (use this document's surface inventory above)
2. Reprinted or re-rendered with the updated number
3. Old materials destroyed or marked as deprecated

This is an operational protocol, not a frequent event.

---

## What goes in the placeholder until the number is provided

For all draft assets in this vault, the placeholder is:

```
DRE License #[NUMBER]
```

This placeholder is unmistakable — vendors and team members cannot mistake it for a real license number. The brackets and word "NUMBER" make the omission obvious.

**No printed asset leaves the vault with the placeholder still in place.** Pre-print checklists in every business card, signage, and document spec require the DRE number to be inserted before production proceeds.

---

## Future state: team licensing

If Pegasus Dreamscapes hires additional licensed agents (or Apollo's father Moises operates under an additional license type), each licensee's number must appear on materials marketing their services. Multi-licensee compliance increases complexity; engage KW Market Center compliance contact early when this scales.

---

*End of DRE License Placement Guide v1.0. Operational guidance only. Not legal advice.*
