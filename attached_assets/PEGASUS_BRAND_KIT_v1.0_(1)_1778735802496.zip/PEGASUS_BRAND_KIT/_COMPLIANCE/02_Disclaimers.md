# Standard Disclaimers
**Pegasus Dreamscapes & Pegasus Systems**
Version 1.0 — Operational guidance, not legal advice

---

## How to use this document

Standard disclaimer language for common Pegasus contexts. **All language below is placeholder until reviewed and approved by counsel.** Disclaimers protect Pegasus and the recipient — but only if they are jurisdictionally accurate, current, and used correctly.

For each disclaimer category below:
- **Use case:** when this disclaimer applies
- **Where to place it:** which surfaces require it
- **Standard language:** placeholder text to be reviewed by counsel
- **Counsel review needed:** what specific aspects need legal sign-off

---

## 1. Investment / Capital-raise disclaimer

### Use case
Any document, deck, web page, or communication that:
- Describes investment opportunities
- States or implies returns
- Solicits capital from investors
- Markets a fund, SPV, or syndication

### Where to place it
- Investor decks (cover slide + appendix slide + footer of every numeric slide)
- Capital-raise emails (footer)
- Website pages discussing investment opportunities
- One-pagers describing investment products
- Verbal presentations (delivered orally at the start)

### Standard language (PLACEHOLDER — counsel must approve)
> This presentation is for informational purposes only and does not constitute an offer to sell or a solicitation of an offer to buy any securities. Any such offer or solicitation will be made only by means of a confidential Private Placement Memorandum and related documentation, and only to qualified investors. Past performance is not indicative of future results. Real estate investment involves significant risk, including the risk of loss of principal. Forward-looking statements involve known and unknown risks, uncertainties, and other factors that may cause actual results to differ materially.

### Counsel review needed
- Federal securities law compliance (Reg D 506(b) vs. 506(c) implications for general solicitation)
- State securities law (California Department of Financial Protection and Innovation registration thresholds)
- Investor accreditation verification protocol
- Specific language for fund structures vs. single-deal SPVs

---

## 2. Real estate marketing disclaimer

### Use case
Any KW-affiliated real estate advertising or solicitation. (See `01_KW_Compliance_Requirements.md` for full requirements.)

### Where to place it
- All KW-branded marketing materials
- Real estate listing presentations
- Property marketing flyers
- KW agent web pages

### Standard language
> Paolo Duran is a licensed California Real Estate Salesperson (DRE License #[NUMBER]) affiliated with Keller Williams Realty. Each Office Independently Owned and Operated. Equal Housing Opportunity. Information deemed reliable but not guaranteed; buyers and sellers should independently verify all material facts.

### Counsel review needed
- Current DRE language requirements
- Equal Housing language placement
- "Each Office Independently Owned and Operated" exact wording per KW Market Center

---

## 3. Pegasus as principal buyer disclaimer

### Use case
When Pegasus Dreamscapes (with Apollo as agent) is purchasing a property as principal — i.e., the buyer rather than representing a seller-client.

### Where to place it
- Acquisition offers to sellers
- Direct-to-seller marketing materials
- Pegasus "We Buy Houses" yard signs (in fine print on the back of any flyer attached)

### Standard language
> Pegasus Dreamscapes is a real estate operating company purchasing properties as principal. Paolo Duran, a licensed California Real Estate Salesperson (DRE License #[NUMBER]) affiliated with Keller Williams Realty, is a principal of Pegasus Dreamscapes Corp and may purchase properties as a principal buyer. This communication is not a solicitation for representation; it is an offer or expression of interest to purchase as principal.

### Counsel review needed
- California "agent as principal" disclosure requirements
- KW Market Center policies on principal purchasing by KW agents
- Whether additional disclosures are required when Apollo represents a buyer-client and Pegasus is also bidding on the same property (typically prohibited or requires extensive disclosure)

---

## 4. Construction / contractor disclaimer

### Use case
Marketing or descriptions of construction services Pegasus performs or coordinates. Apollo is pursuing a California contractor license but does not yet hold one; Moises Duran (Apollo's father) is a licensed general contractor.

### Where to place it
- Service proposals describing construction work
- Marketing materials offering construction services
- Web pages describing development services

### Standard language (during the period before Apollo holds his contractor license)
> Construction services are performed by licensed contractors engaged by Pegasus Dreamscapes. Pegasus Dreamscapes is an operating company; specific construction work is performed under the direction and license of Moises Duran, California-Licensed General Contractor (License #[NUMBER]) or other duly licensed contractors engaged for the project. Pegasus Dreamscapes does not directly provide contractor services without proper licensure.

### Counsel review needed
- California Contractors State License Board (CSLB) requirements for advertising construction services
- Whether Pegasus Dreamscapes Corp can advertise construction services without holding a contractor license itself, when work is performed by an engaged licensed contractor
- Update language once Apollo's contractor license is obtained

---

## 5. Pegasus Systems software / SaaS disclaimer

### Use case
Any Pegasus Systems product communication that:
- Describes product capabilities
- Implies financial, tax, or legal outcomes for users
- Markets Peggy (AI advisor) functionality
- Discusses data handling or security

### Where to place it
- `pegasussystems.com` footer
- Product Terms of Service
- Marketing emails describing product features
- Sales decks for Pegasus Systems

### Standard language
> Pegasus Systems is a software platform for real estate operators. Pegasus Systems does not provide legal, tax, financial, accounting, or investment advice. Customers are responsible for ensuring their use of the platform complies with applicable laws and regulations in their jurisdictions. Peggy, the AI advisor feature, provides recommendations only and does not act autonomously. All actions in the platform require explicit operator approval. Pegasus Systems is not a fiduciary to its customers. See Terms of Service for full terms.

### Counsel review needed
- SaaS Terms of Service drafted from scratch
- Privacy policy (CCPA, GDPR if international users)
- Data Processing Addendum for enterprise customers
- AI/ML disclosures for Peggy (rapidly evolving regulatory area)

---

## 6. Embedded finance disclaimer (CapStack future state)

### Use case
When CapStack evolves into payment processing, lending, or other embedded financial services, additional disclosures will be required.

### Where to place it (future)
- CapStack product surfaces
- Pegasus Systems pricing pages mentioning embedded finance
- Marketing copy describing the embedded finance roadmap

### Standard language (PLACEHOLDER — substantial counsel review needed)
> [Future-state language for payment processing, lending, or money services. Will require:
> - State money services business (MSB) licensing analysis
> - FinCEN registration requirements
> - State-by-state lending license analysis
> - Stripe Connect or equivalent platform partner agreements
> - Truth in Lending Act compliance
> - Equal Credit Opportunity Act compliance
> - Anti-money laundering (AML) program]

### Counsel review needed
- Specialized fintech / banking counsel required before any embedded finance feature launches
- This is not a "we'll add a disclaimer" situation; embedded finance requires substantial regulatory infrastructure
- Pegasus should engage fintech counsel 6+ months before launching any embedded finance feature

---

## 7. Forward-looking statements disclaimer

### Use case
Any document or presentation that makes statements about future plans, projected returns, anticipated milestones, or roadmap items.

### Where to place it
- Investor decks
- Strategic plans shared with partners
- Public-facing roadmap content
- Press releases

### Standard language
> This document contains forward-looking statements that involve known and unknown risks, uncertainties, and other factors. Words such as "expect," "anticipate," "intend," "plan," "believe," "estimate," and similar expressions identify forward-looking statements. Forward-looking statements are not guarantees of future performance. Actual results may differ materially. Pegasus Dreamscapes undertakes no obligation to update forward-looking statements except as required by law.

### Counsel review needed
- Specific language for capital-raise contexts (more stringent)
- Specific language for general business communications (less stringent)

---

## 8. "Not financial / legal / tax advice" disclaimer

### Use case
Any educational content (social posts, blog articles, podcast appearances, founder voice content) that discusses real estate strategies, investment approaches, or operating tactics.

### Where to place it
- Educational social posts
- Blog articles (when blog launches)
- Founder thought leadership content
- Podcast or media appearances

### Standard language
> This content is for informational and educational purposes only and does not constitute legal, financial, tax, accounting, or investment advice. Real estate investment involves risk. Consult qualified professionals before making decisions based on the information provided.

### Counsel review needed
- Whether explicit disclaimer is required on every educational post, or whether a single disclosure on a website "About" page or content policy is sufficient

---

## 9. Pegasus Dreamscapes general business disclaimer (footer)

### Use case
Footer of website, formal communications, and general marketing.

### Standard language
> © [Year] Pegasus Dreamscapes Corp. All rights reserved. Pegasus Dreamscapes Corp is a California S-Corporation. Information on this site is provided for general informational purposes and does not constitute an offer to buy or sell any product or service.

---

## Operational notes

### Disclaimer formatting
- Disclaimers in printed materials: Inter Regular, 8pt, Cream at 60% on dark / Midnight at 60% on light
- Disclaimers in decks: footer of every numeric slide + full appendix slide for capital decks
- Disclaimers in emails: below signature, separated by horizontal rule
- Disclaimers on website: footer

### Disclaimer language updates
- Review annually with counsel
- Update immediately upon any regulatory change Pegasus is notified of
- Maintain version history in this document (append-only)

### Who can approve new disclaimer language
- Any new disclaimer language requires counsel approval before use
- Modifications to existing language require counsel review
- Apollo can add disclaimers from this approved list to new contexts without re-review, provided the use case fits

---

*End of Standard Disclaimers v1.0. Operational guidance only. All language above is placeholder until reviewed by qualified counsel.*
