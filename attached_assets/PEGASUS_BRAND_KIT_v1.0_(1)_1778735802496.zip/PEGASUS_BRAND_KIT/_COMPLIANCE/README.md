# _COMPLIANCE

Legal, regulatory, and brokerage compliance requirements that affect Pegasus brand assets.

This folder is prefixed with an underscore (`_COMPLIANCE`) so it sorts to the top in alphabetical listings — compliance is a doctrine layer that touches every other section of the vault, not a category that lives among the others.

## Files

| File | Purpose |
|---|---|
| `01_KW_Compliance_Requirements.md` | Keller Williams agent advertising rules, DRE requirements, Equal Housing |
| `02_Disclaimers.md` | Standard disclaimer language for investment, financial, real estate, and Pegasus Systems contexts |
| `03_DRE_License_Placement_Guide.md` | Where the DRE license number must appear and at what minimum size |
| `04_Trademark_and_IP_Notes.md` | Pegasus IP posture, REALTOR® trademark usage, third-party logo usage |

## What this folder is not

- A substitute for legal counsel. Pegasus engages real estate, securities, and corporate counsel for material legal matters. This folder covers brand-level compliance only.
- A static document. Regulatory requirements change. Review this folder annually and after any major regulatory development.

## When to consult this folder

- Before printing any KW-affiliated material (cards, signs, marketing)
- Before publishing investment-related content (decks, web copy, social posts about deals or returns)
- Before using third-party logos (KW logo, Equal Housing, REALTOR® mark)
- Before signing any agreement that uses the Pegasus brand
- When a new team member or vendor is unfamiliar with the regulatory requirements

## Status

Compliance specs are drafted. **All compliance language must be reviewed by counsel before being treated as legally definitive.** This vault provides operational guidance; it is not legal advice.
