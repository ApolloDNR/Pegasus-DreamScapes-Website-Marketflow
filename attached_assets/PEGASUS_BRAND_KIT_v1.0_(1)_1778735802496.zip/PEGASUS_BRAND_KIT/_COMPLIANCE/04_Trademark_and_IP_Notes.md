# Trademark and IP Notes
**Pegasus Dreamscapes & Pegasus Systems**
Version 1.0 — Operational guidance, not legal advice

---

## Pegasus IP posture

Pegasus Dreamscapes Corp owns the brand assets in this vault. Specifically:

| Asset | Ownership | Protection status |
|---|---|---|
| "Pegasus Dreamscapes" name | Pegasus Dreamscapes Corp | Common-law trademark; federal registration recommended |
| "Pegasus Systems" name | Pegasus Dreamscapes Corp | Common-law trademark; federal registration recommended (potential conflict — see below) |
| Pegasus Dreamscapes logo (all variants) | Pegasus Dreamscapes Corp | Common-law trademark; copyright in artwork |
| Pegasus Systems logo (when designed) | Pegasus Dreamscapes Corp | Common-law trademark; copyright in artwork |
| Product names: Pegasus HQ, BuildForge, CapStack, MarketFlow, Peggy | Pegasus Dreamscapes Corp | Common-law trademark; federal registration recommended for primary product |
| "Dream it. Build it. Live it." tagline | Pegasus Dreamscapes Corp | Common-law trademark; federal registration recommended |
| Brand wordmark typography (Playfair + Inter set) | Open-licensed fonts; layout/setting is Pegasus Corp work product | Copyright in arrangement |

### Federal trademark registration recommendation

Engage trademark counsel to:
1. Conduct a clearance search for "Pegasus Dreamscapes" and "Pegasus Systems" — identify any existing registrations or pending applications that conflict
2. File USPTO trademark applications for the primary brand name + tagline + key product names
3. Register the logo as a design mark separately

**Critical pre-flight:** "Pegasus Systems" is a relatively common name pattern in tech. A clearance search may reveal conflicts that require either (a) a name change before scaling, or (b) a coexistence strategy with another entity. Do this research before significant marketing investment in the Pegasus Systems brand.

### Domain protection

Already-locked or to-lock domains (verify and acquire as needed):
- `pegasusdreamscapes.com` — primary
- `pegasussystems.com` — primary for software arm
- `pegasus-dreamscapes.com` — defensive (hyphenated typo variant) → 301 to canonical
- `pegasusdreamscapes.io`, `.co`, `.app` — defensive holds
- `pegasus.systems` — defensive consideration if available
- `peggy.ai` — likely taken; consider `peggy.pegasussystems.com` as the canonical Peggy URL instead of attempting to acquire `peggy.ai`

### Social handle protection

Lock all available `@pegasusdreamscapes` and `@pegasussystems` handles across:
- Instagram, LinkedIn, X/Twitter, YouTube, TikTok, Threads, Facebook, GitHub
- Even on platforms where Pegasus has no intention of being active — defensive holds prevent brand impersonation

---

## Third-party trademarks Pegasus uses

### REALTOR® mark
- Owned by the National Association of REALTORS®
- Apollo's right to use the mark depends on his current NAR membership
- Always include the ® symbol
- Always capitalize as REALTOR®
- Use as a designation or noun, never as a verb
- Do not modify the mark visually

### Keller Williams logo and brand
- Owned by Keller Williams Realty, Inc.
- Apollo's right to use the KW brand depends on his current agency relationship with KW
- Use only the KW-issued logo file (do not redraw)
- Follow KW Brand Standards (current version available through KW Market Center)
- Do not modify the KW logo, color palette, or wordmark
- Co-branded use (Pegasus + KW) requires KW Market Center pre-approval

### Equal Housing Opportunity logo
- The standard Equal Housing logo is in the public domain (U.S. Department of Housing and Urban Development)
- May be used freely on real estate marketing
- Standard sources: HUD website, NAR member resources, KW Command marketing library

### Other trademarks
- When using third-party software, service, or partner logos in Pegasus marketing (e.g., showing "Powered by Stripe" if CapStack uses Stripe Connect), follow each company's brand guidelines
- Get written permission for any non-standard use
- Do not imply endorsement that does not exist

---

## Pegasus IP that vendors and contractors create

When designers, developers, copywriters, or other contractors create work for Pegasus, the work product must be assigned to Pegasus Dreamscapes Corp:

### Recommended contract terms (counsel to draft)
- All work product is "work made for hire" under U.S. Copyright Act
- All intellectual property in the work is assigned to Pegasus Dreamscapes Corp
- Contractor waives moral rights to the extent permitted by law
- Contractor warrants that the work does not infringe third-party rights
- Contractor cannot use the work in their portfolio without Pegasus consent (or a defined limited use right)

This is not optional. Without explicit IP assignment, the contractor may retain rights to the work — which can become a serious issue when Pegasus tries to license, sublicense, or modify the work later.

### Already-engaged contractors
For any work already produced for Pegasus by contractors without an IP assignment in place:
1. Identify the work
2. Reach out to the contractor for retroactive IP assignment
3. Document the assignment in writing
4. Counsel-drafted assignment agreement preferred

---

## Pegasus Systems software IP

The Pegasus Systems codebase is a separate IP category from the brand assets. Specifically:

- All code is owned by Pegasus Dreamscapes Corp (or a subsidiary, if a separate Pegasus Systems entity is later formed)
- All contributions from contractors, employees, or contributors must be assigned via written agreement
- Open-source dependencies are tracked and license-compatible (avoid AGPL or GPL dependencies in proprietary product)
- Open-source contributions Pegasus makes back to the community are under permissive licenses (MIT, Apache 2.0)

This is a developer-relations operational matter, not a brand kit item — but it's flagged here because Pegasus Systems' value as a SaaS business depends on clean IP ownership of the codebase.

---

## Trademark enforcement

When (not if) someone uses "Pegasus Dreamscapes" or a confusingly similar mark without authorization:

1. Document the infringement with screenshots and dates
2. Send a cease-and-desist letter through trademark counsel
3. Escalate to USPTO opposition or federal court if infringement persists
4. Maintain a trademark enforcement log to demonstrate active brand protection (relevant if the mark is ever challenged)

Active enforcement is required to maintain trademark strength. Brands that don't enforce lose enforceability over time.

---

## When to consult trademark counsel

- Before federal trademark registration filings
- Before launching a new product name
- When a clearance search identifies a potential conflict
- When responding to a third-party cease-and-desist
- When co-branding with another company
- When evaluating an acquisition or licensing opportunity
- Annually for general portfolio review

---

*End of Trademark and IP Notes v1.0. Operational guidance only. Not legal advice.*
