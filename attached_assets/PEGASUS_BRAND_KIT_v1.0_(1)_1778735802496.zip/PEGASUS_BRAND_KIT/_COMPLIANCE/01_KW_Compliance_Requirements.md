# Keller Williams Compliance Requirements
**Pegasus Dreamscapes — KW Affiliated Marketing**
Version 1.0 — Operational guidance, not legal advice

---

## Overview

Apollo holds an active California real estate license through Keller Williams Realty. Any marketing material that:
- Uses the KW brand or logo
- References Apollo's Realtor® designation
- Solicits real estate transactions where Apollo would be the agent
- Uses the brokerage's resources or systems

…must comply with three overlapping rule sets:

1. **California Department of Real Estate (DRE) regulations** — state law
2. **National Association of Realtors® (NAR)** rules — for the REALTOR® trademark
3. **Keller Williams Brand Standards and Market Center policies** — brokerage rules

This document captures the operational requirements that affect Pegasus brand assets. **It is not a substitute for legal review or KW Market Center consultation.**

---

## Required elements on KW-affiliated marketing

Any business card, sign, advertisement, flyer, social post, email, or website page that markets Apollo as a Realtor® must include:

### 1. Brokerage name
**Keller Williams Realty** (full name; not "KW Realty," not "Keller Williams")

The brokerage name must appear in **equal or greater prominence** than the agent's name. This is a state requirement (DRE), not just a KW preference.

### 2. DRE License Number
California Business and Professions Code §10140.6 requires:
> Any solicitation materials intended to be the first point of contact with consumers… shall contain the licensee's name, license identification number, and the responsible broker's identity in a manner that is easily readable.

Format: `DRE License #[NUMBER]` or `CalDRE #[NUMBER]` or `DRE #[NUMBER]`

Apollo's DRE number must appear:
- On every business card
- On every yard sign and open-house sign
- On every flyer, brochure, and printed marketing piece
- In every email signature on KW correspondence
- On every web page and social profile that markets him as an agent
- In the footer of any digital advertisement

Minimum size: legible at standard reading distance. Do not bury in tiny type.

### 3. "Each Office Independently Owned and Operated"
This disclosure is required on KW marketing because each KW Market Center is a separately franchised business, not a corporately owned office.

Must appear: same surfaces as DRE number above.

### 4. Equal Housing Opportunity logo or statement
Federal Fair Housing Act compliance. Required on:
- Any advertisement for residential real estate
- Yard signs
- Listing flyers
- Web pages marketing properties

Format options:
- Equal Housing Opportunity logo (the standard house-with-equals-sign mark)
- Text: "Equal Housing Opportunity"
- Both is acceptable

### 5. REALTOR® designation (when used)
The REALTOR® mark belongs to NAR, not to KW or to individual agents. To use it:
- Must be a current NAR member in good standing (KW agents are typically NAR members through KW)
- The trademark symbol (®) must always appear
- Capitalize as "REALTOR®"
- Do not use as a verb ("realtoring") or pluralize informally ("realtors" — use "REALTORS®")

---

## Co-branding rules (Pegasus Dreamscapes + Keller Williams)

When the Pegasus Dreamscapes brand appears alongside the KW brand on the same marketing surface (e.g., the dual-brand business card):

1. **Visual separation:** The two brands must be visually separated, not merged into a single lockup. Use the vertical Copper rule pattern from `01_BRAND_GUIDE/05_Logo_Usage_Guide.md`.

2. **No misrepresentation:** Pegasus Dreamscapes must not appear to be a brokerage. Only KW (the actual brokerage) is the brokerage. Pegasus is a separate operating company.

3. **No commingling of services:** Real estate brokerage services (representation, MLS access, fiduciary representation in transactions) are KW services performed by Apollo as a KW agent. Development, investment, and software services are Pegasus services. The marketing must not blur these.

4. **KW Market Center pre-approval:** Some KW Market Centers require pre-approval for marketing materials that include the KW logo alongside another brand. **Confirm with the local KW Market Center before printing any dual-brand material.**

5. **All five required elements above must still be present** on co-branded materials. The Pegasus brand presence does not exempt the material from KW compliance.

---

## Specific application: business cards

| Card | Required compliance elements |
|---|---|
| Pegasus-only card | None of the above (no KW affiliation present; no DRE-licensed real estate marketing) |
| KW-only card | All five required elements |
| Dual-brand card | All five required elements |

---

## Specific application: signage

| Sign | Required compliance elements |
|---|---|
| KW yard sign (For Sale) | All five required elements; use KW-templated sign |
| KW open house sign | All five required elements; use KW-templated sign |
| Pegasus "We Buy Houses" yard sign | None (not KW affiliated; Pegasus is an operating company buyer, not an agent) |
| Pegasus jobsite sign | None (construction signage, not real estate brokerage marketing) |

---

## Specific application: digital marketing

| Surface | Required compliance elements |
|---|---|
| Apollo's KW agent website (if separate) | All five required elements |
| Apollo's LinkedIn (when listing Realtor® role) | DRE number visible in profile; brokerage clearly named |
| Pegasus Dreamscapes website | Compliance not required for the parent brand site; if Apollo's Realtor® role is mentioned anywhere on the site (e.g., founder bio), DRE number and brokerage must be present nearby |
| Pegasus social posts about real estate transactions | Compliance overlay required if the post is recruiting buyers/sellers; not required for general operating-company commentary |

---

## What constitutes "advertising" under DRE rules

DRE rules apply to "first contact" marketing materials and any solicitation. In practice:

- **Counts as advertising:** business cards, yard signs, flyers, mailers, websites, social media profiles, paid ads, email signatures on outbound prospecting
- **Does not count as advertising (typically):** internal team communications, Pegasus operating-company marketing that does not solicit real estate transactions, casual social posts that don't solicit business

When in doubt, treat it as advertising and apply the compliance overlay.

---

## Apollo's KW Market Center

[Placeholder — fill in:]
- KW Market Center name:
- Market Center address:
- Designated Broker name:
- Designated Broker license number:
- Apollo's KW agent ID:
- Apollo's DRE license number:
- KW Market Center compliance contact:

These details are required on many compliance overlays and should be available for quick reference.

---

## Disclosure requirements when Pegasus is the buyer

When Apollo (or Pegasus Dreamscapes) is acting as a principal buyer of a property — not as the seller's agent or representing a buyer-client — California real estate law requires disclosure of his agent status to the seller:

1. Disclose that Apollo holds an active California real estate license
2. Disclose that he is purchasing as a principal (not as an agent representing the seller or another buyer)
3. Provide the disclosure in writing as part of the offer

This is called the "agent as principal" disclosure. It is operationally important because Pegasus Dreamscapes' acquisition strategy (direct-to-seller distressed acquisition) puts Apollo in this position frequently.

This is not a brand asset compliance issue per se, but it is a regulatory issue that affects how Pegasus communicates with sellers. Operational templates for these disclosures should be developed in conjunction with real estate counsel.

---

## Annual review

Compliance requirements change. Review this document annually:

- Check DRE for updated advertising rules
- Check NAR for REALTOR® mark usage updates
- Check KW Market Center for updated brand standards
- Check California fair housing requirements for any updates

Update this document as needed; archive prior versions per the vault's append-only policy.

---

## When to escalate to counsel

- Any marketing copy that makes specific claims about returns, performance, or guarantees
- Any solicitation of investment capital
- Any compliance question where you're not 100% certain of the answer
- Any KW Market Center pushback on co-branded materials
- Any DRE inquiry or audit

Real estate compliance counsel and securities counsel are engaged separately from general corporate counsel. Pegasus should have established relationships with both before scaling marketing.

---

*End of KW Compliance Requirements v1.0. Operational guidance only. Not legal advice.*
