# Pegasus Dreamscapes — Logo Intake Checklist

When all boxes are checked, this logo set is **vault-complete**.

## Primary Stacked
- [ ] `pegasus-dreamscapes_primary-stacked_full-color-on-dark.svg`
- [ ] `pegasus-dreamscapes_primary-stacked_full-color-on-dark.pdf`
- [ ] `pegasus-dreamscapes_primary-stacked_full-color-on-dark_1024px.png`
- [ ] `pegasus-dreamscapes_primary-stacked_full-color-on-light.svg`
- [ ] `pegasus-dreamscapes_primary-stacked_full-color-on-light.pdf`
- [ ] `pegasus-dreamscapes_primary-stacked_full-color-on-light_1024px.png`
- [ ] `pegasus-dreamscapes_primary-stacked_one-color-cream.svg`
- [ ] `pegasus-dreamscapes_primary-stacked_one-color-midnight.svg`
- [ ] `pegasus-dreamscapes_primary-stacked_one-color-copper.svg`
- [ ] `pegasus-dreamscapes_primary-stacked_knockout.svg` (silhouette for sign-cutting)

## Horizontal
- [ ] `pegasus-dreamscapes_horizontal_full-color-on-dark.svg`
- [ ] `pegasus-dreamscapes_horizontal_full-color-on-dark.pdf`
- [ ] `pegasus-dreamscapes_horizontal_full-color-on-dark_1024px.png`
- [ ] `pegasus-dreamscapes_horizontal_full-color-on-light.svg`
- [ ] `pegasus-dreamscapes_horizontal_full-color-on-light.pdf`
- [ ] `pegasus-dreamscapes_horizontal_full-color-on-light_1024px.png`
- [ ] `pegasus-dreamscapes_horizontal_one-color-cream.svg`
- [ ] `pegasus-dreamscapes_horizontal_one-color-midnight.svg`
- [ ] `pegasus-dreamscapes_horizontal_one-color-copper.svg`

## Icon Only (winged horse + house)
- [ ] `pegasus-dreamscapes_icon_full-color-on-dark.svg`
- [ ] `pegasus-dreamscapes_icon_full-color-on-light.svg`
- [ ] `pegasus-dreamscapes_icon_one-color-cream.svg`
- [ ] `pegasus-dreamscapes_icon_one-color-midnight.svg`
- [ ] `pegasus-dreamscapes_icon_one-color-copper.svg`
- [ ] `pegasus-dreamscapes_icon_512px.png` (transparent)
- [ ] `pegasus-dreamscapes_icon_256px.png` (transparent)
- [ ] `pegasus-dreamscapes_icon_128px.png` (transparent)
- [ ] `pegasus-dreamscapes_icon_64px.png` (transparent)

## Wordmark Only (PEGASUS DREAMSCAPES typography)
- [ ] `pegasus-dreamscapes_wordmark_full-color-on-dark.svg`
- [ ] `pegasus-dreamscapes_wordmark_full-color-on-light.svg`
- [ ] `pegasus-dreamscapes_wordmark_one-color-cream.svg`
- [ ] `pegasus-dreamscapes_wordmark_one-color-midnight.svg`
- [ ] `pegasus-dreamscapes_wordmark_one-color-copper.svg`

## Web / OS specialty
- [ ] `favicon.ico` (multi-resolution: 16x16, 32x32, 48x48)
- [ ] `favicon-16x16.png`
- [ ] `favicon-32x32.png`
- [ ] `apple-touch-icon-180x180.png`
- [ ] `android-chrome-192x192.png`
- [ ] `android-chrome-512x512.png`
- [ ] `social-profile_1024x1024.png` (square, on Midnight, icon centered)
- [ ] `social-banner_1500x500.png` (Twitter / X header dimensions)
- [ ] `linkedin-banner_1584x396.png`

## Specialty production files
- [ ] Embroidery file: `pegasus-dreamscapes_embroidery_3in.dst` (or vendor-preferred format)
- [ ] Vinyl-cut file: `pegasus-dreamscapes_vinyl-cut.svg` (single solid color, optimized for blade-cut)

## Source files
- [ ] Adobe Illustrator master: `pegasus-dreamscapes_master.ai`
- [ ] Figma source link logged in `_SOURCES.md`

## Sign-off
- [ ] All files reviewed against `01_BRAND_GUIDE/05_Logo_Usage_Guide.md`
- [ ] Apollo approval logged with date
- [ ] Vault status updated in `02_LOGOS/README.md`
