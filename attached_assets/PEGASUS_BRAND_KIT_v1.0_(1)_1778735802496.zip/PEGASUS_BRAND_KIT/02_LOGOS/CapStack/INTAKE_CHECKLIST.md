# CapStack — Logo Intake Checklist

Product fleet logo. Lives under Pegasus Systems.

## Required files

### Wordmark + icon lockup (primary)
- [ ] `capstack_primary_full-color-on-dark.svg`
- [ ] `capstack_primary_full-color-on-light.svg`
- [ ] `capstack_primary_one-color-cream.svg`
- [ ] `capstack_primary_one-color-midnight.svg`

### Horizontal lockup
- [ ] `capstack_horizontal_full-color-on-dark.svg`
- [ ] `capstack_horizontal_full-color-on-light.svg`

### App icon (for in-app product switcher and OS-level installs)
- [ ] `capstack_icon_full-color-on-dark.svg`
- [ ] `capstack_icon_512px.png`
- [ ] `capstack_icon_256px.png`
- [ ] `capstack_icon_128px.png`
- [ ] `capstack_icon_64px.png`
- [ ] `capstack_icon_32px.png` (sidebar UI size)
- [ ] `capstack_icon_24px.png` (inline UI size)

### iOS / Android app icons (only if shipping native mobile apps)
- [ ] `capstack_app-icon_ios-1024.png`
- [ ] `capstack_app-icon_android-512.png`

### Source
- [ ] `capstack_master.ai`

## Design notes
- All product icons share visual DNA: a single bold glyph in Copper or Cream on Midnight. The glyph should communicate the product's role at a glance.
- Glyphs should be at least 70% solid color (not line-weight illustrations) so they remain legible at 24px sidebar size.
- Each icon must be visually distinct from the others when placed in a row (test all five side by side at 32px before locking).

## Sign-off
- [ ] Reviewed in product switcher mockup at actual sidebar size
- [ ] All five fleet icons reviewed together for visual differentiation
- [ ] Apollo approval logged
