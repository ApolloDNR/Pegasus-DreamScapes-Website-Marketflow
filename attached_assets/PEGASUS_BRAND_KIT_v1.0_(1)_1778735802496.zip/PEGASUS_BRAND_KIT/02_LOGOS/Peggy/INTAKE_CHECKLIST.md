# Peggy — Logo Intake Checklist

Product fleet logo. Lives under Pegasus Systems.

## Required files

### Wordmark + icon lockup (primary)
- [ ] `peggy_primary_full-color-on-dark.svg`
- [ ] `peggy_primary_full-color-on-light.svg`
- [ ] `peggy_primary_one-color-cream.svg`
- [ ] `peggy_primary_one-color-midnight.svg`

### Horizontal lockup
- [ ] `peggy_horizontal_full-color-on-dark.svg`
- [ ] `peggy_horizontal_full-color-on-light.svg`

### App icon (for in-app product switcher and OS-level installs)
- [ ] `peggy_icon_full-color-on-dark.svg`
- [ ] `peggy_icon_512px.png`
- [ ] `peggy_icon_256px.png`
- [ ] `peggy_icon_128px.png`
- [ ] `peggy_icon_64px.png`
- [ ] `peggy_icon_32px.png` (sidebar UI size)
- [ ] `peggy_icon_24px.png` (inline UI size)

### iOS / Android app icons (only if shipping native mobile apps)
- [ ] `peggy_app-icon_ios-1024.png`
- [ ] `peggy_app-icon_android-512.png`

### Source
- [ ] `peggy_master.ai`

## Design notes
- All product icons share visual DNA: a single bold glyph in Copper or Cream on Midnight. The glyph should communicate the product's role at a glance.
- Glyphs should be at least 70% solid color (not line-weight illustrations) so they remain legible at 24px sidebar size.
- Each icon must be visually distinct from the others when placed in a row (test all five side by side at 32px before locking).

## Sign-off
- [ ] Reviewed in product switcher mockup at actual sidebar size
- [ ] All five fleet icons reviewed together for visual differentiation
- [ ] Apollo approval logged
