# Pegasus HQ — Logo Intake Checklist

Product fleet logo. Lives under Pegasus Systems.

## Required files

### Wordmark + icon lockup (primary)
- [ ] `pegasus-hq_primary_full-color-on-dark.svg`
- [ ] `pegasus-hq_primary_full-color-on-light.svg`
- [ ] `pegasus-hq_primary_one-color-cream.svg`
- [ ] `pegasus-hq_primary_one-color-midnight.svg`

### Horizontal lockup
- [ ] `pegasus-hq_horizontal_full-color-on-dark.svg`
- [ ] `pegasus-hq_horizontal_full-color-on-light.svg`

### App icon (for in-app product switcher and OS-level installs)
- [ ] `pegasus-hq_icon_full-color-on-dark.svg`
- [ ] `pegasus-hq_icon_512px.png`
- [ ] `pegasus-hq_icon_256px.png`
- [ ] `pegasus-hq_icon_128px.png`
- [ ] `pegasus-hq_icon_64px.png`
- [ ] `pegasus-hq_icon_32px.png` (sidebar UI size)
- [ ] `pegasus-hq_icon_24px.png` (inline UI size)

### iOS / Android app icons (only if shipping native mobile apps)
- [ ] `pegasus-hq_app-icon_ios-1024.png`
- [ ] `pegasus-hq_app-icon_android-512.png`

### Source
- [ ] `pegasus-hq_master.ai`

## Design notes
- All product icons share visual DNA: a single bold glyph in Copper or Cream on Midnight. The glyph should communicate the product's role at a glance.
- Glyphs should be at least 70% solid color (not line-weight illustrations) so they remain legible at 24px sidebar size.
- Each icon must be visually distinct from the others when placed in a row (test all five side by side at 32px before locking).

## Sign-off
- [ ] Reviewed in product switcher mockup at actual sidebar size
- [ ] All five fleet icons reviewed together for visual differentiation
- [ ] Apollo approval logged
