# BuildForge — Logo Intake Checklist

Product fleet logo. Lives under Pegasus Systems.

## Required files

### Wordmark + icon lockup (primary)
- [ ] `buildforge_primary_full-color-on-dark.svg`
- [ ] `buildforge_primary_full-color-on-light.svg`
- [ ] `buildforge_primary_one-color-cream.svg`
- [ ] `buildforge_primary_one-color-midnight.svg`

### Horizontal lockup
- [ ] `buildforge_horizontal_full-color-on-dark.svg`
- [ ] `buildforge_horizontal_full-color-on-light.svg`

### App icon (for in-app product switcher and OS-level installs)
- [ ] `buildforge_icon_full-color-on-dark.svg`
- [ ] `buildforge_icon_512px.png`
- [ ] `buildforge_icon_256px.png`
- [ ] `buildforge_icon_128px.png`
- [ ] `buildforge_icon_64px.png`
- [ ] `buildforge_icon_32px.png` (sidebar UI size)
- [ ] `buildforge_icon_24px.png` (inline UI size)

### iOS / Android app icons (only if shipping native mobile apps)
- [ ] `buildforge_app-icon_ios-1024.png`
- [ ] `buildforge_app-icon_android-512.png`

### Source
- [ ] `buildforge_master.ai`

## Design notes
- All product icons share visual DNA: a single bold glyph in Copper or Cream on Midnight. The glyph should communicate the product's role at a glance.
- Glyphs should be at least 70% solid color (not line-weight illustrations) so they remain legible at 24px sidebar size.
- Each icon must be visually distinct from the others when placed in a row (test all five side by side at 32px before locking).

## Sign-off
- [ ] Reviewed in product switcher mockup at actual sidebar size
- [ ] All five fleet icons reviewed together for visual differentiation
- [ ] Apollo approval logged
