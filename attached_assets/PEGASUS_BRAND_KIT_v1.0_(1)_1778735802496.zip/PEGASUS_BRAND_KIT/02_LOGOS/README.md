# 02_LOGOS

Every logo file Pegasus Dreamscapes uses, organized by entity.

## Folder structure

```
02_LOGOS/
├── Pegasus_Dreamscapes/   ← parent brand, master logo system
├── Pegasus_Systems/       ← software arm sub-brand
├── Pegasus_HQ/            ← product fleet
├── BuildForge/            ← product fleet
├── CapStack/              ← product fleet
├── MarketFlow/            ← product fleet
└── Peggy/                 ← product fleet
```

## Required formats per logo

Every logo set ships in this exact format kit:

### Vector (production-grade)
- `.svg` — for web and digital
- `.pdf` — for print and design tools
- `.ai` — Adobe Illustrator source (when designer delivers)
- `.eps` — for legacy print vendors

### Raster (digital placement)
- `.png` at 1024px on the longest dimension (transparent background)
- `.png` at 512px (transparent)
- `.png` at 256px (transparent)
- `.png` at 128px (transparent)
- `.png` at 64px (transparent)
- `.jpg` at 1024px on Midnight background
- `.jpg` at 1024px on Cream background

### Specialty
- `.ico` — for browser favicons (Pegasus Dreamscapes only, multi-resolution)
- App icon set per OS spec (iOS, Android, macOS, Windows) when applicable

## Naming convention

```
{entity}_{variant}_{color-treatment}_{size-or-format}.{ext}

Examples:
pegasus-dreamscapes_primary-stacked_full-color-on-dark.svg
pegasus-dreamscapes_horizontal_one-color-cream_512px.png
pegasus-dreamscapes_icon_one-color-copper.svg
pegasus-systems_horizontal_full-color-on-dark.svg
pegasus-hq_app-icon_ios-1024.png
buildforge_app-icon_ios-1024.png
```

Lowercase. Hyphen-separated. No spaces. No camelCase. No version numbers in filenames (the vault is the version control).

## Status

| Logo set | Status | Next action |
|---|---|---|
| Pegasus Dreamscapes (parent) | Wordmark + winged-horse mark exists; needs full variant kit + format export | Designer to deliver full kit per intake checklist |
| Pegasus Systems | Sub-brand wordmark needs design | Phase 2 |
| Pegasus HQ | Concept exploration; needs locked design | Phase 2 (flagged: "needs better options") |
| BuildForge | Mostly locked | Phase 2 (export remaining formats) |
| CapStack | Mostly locked | Phase 2 (export remaining formats) |
| MarketFlow | Concept exploration; needs locked design | Phase 2 (flagged: "needs better options") |
| Peggy | Concept exploration; needs locked design | Phase 2 (flagged: "needs better options") |

## Intake checklists

Each logo subfolder contains an `INTAKE_CHECKLIST.md` listing every file required for that logo to be considered "vault-complete." A logo is not locked until its intake checklist is fully checked.
