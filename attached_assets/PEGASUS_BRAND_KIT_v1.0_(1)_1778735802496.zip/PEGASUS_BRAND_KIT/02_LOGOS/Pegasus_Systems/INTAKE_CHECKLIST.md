# Pegasus Systems — Logo Intake Checklist

The software arm sub-brand. Inherits the parent palette and typography but has its own wordmark.

**Status:** Design pending. This is a Phase 2 deliverable.

## Design brief for designer

- Wordmark: "PEGASUS SYSTEMS" set in Playfair Display Black (PEGASUS) + Inter Bold (SYSTEMS), or Playfair Display throughout if visually balanced. Test both.
- Visual mark: must clearly relate to the parent brand without copying the winged-horse-and-house exactly. Suggested direction: a stylized geometric simplification of the wing element (architectural, blueprint-grid feel) without the horse head, signaling "infrastructure" rather than "operating company."
- Color treatment: same palette. Cream + Copper on Midnight default.
- Tagline (descriptor, used selectively): "Operating infrastructure for disciplined real estate execution."

## Required files (full kit, same structure as parent)

### Primary stacked
- [ ] `pegasus-systems_primary-stacked_full-color-on-dark.svg`
- [ ] `pegasus-systems_primary-stacked_full-color-on-dark.pdf`
- [ ] `pegasus-systems_primary-stacked_full-color-on-light.svg`
- [ ] `pegasus-systems_primary-stacked_one-color-cream.svg`
- [ ] `pegasus-systems_primary-stacked_one-color-midnight.svg`

### Horizontal
- [ ] `pegasus-systems_horizontal_full-color-on-dark.svg`
- [ ] `pegasus-systems_horizontal_full-color-on-light.svg`
- [ ] `pegasus-systems_horizontal_one-color-cream.svg`
- [ ] `pegasus-systems_horizontal_one-color-midnight.svg`

### Icon only
- [ ] `pegasus-systems_icon_full-color-on-dark.svg`
- [ ] `pegasus-systems_icon_512px.png`
- [ ] `pegasus-systems_icon_256px.png`
- [ ] `pegasus-systems_icon_128px.png`

### Wordmark only
- [ ] `pegasus-systems_wordmark_full-color-on-dark.svg`
- [ ] `pegasus-systems_wordmark_one-color-cream.svg`

### Web specialty (separate from parent — Pegasus Systems will get its own product site)
- [ ] `favicon.ico`
- [ ] `apple-touch-icon-180x180.png`
- [ ] `social-profile_1024x1024.png`

### Source
- [ ] `pegasus-systems_master.ai`

## Sign-off
- [ ] Reviewed against `01_BRAND_GUIDE/06_Brand_Architecture.md` for endorsement strategy compliance
- [ ] Apollo approval logged
