# PEGASUS DREAMSCAPES — BRAND KIT VAULT

**Version:** v1.0 (Founding Lock)
**Owner:** Apollo Duran, Founder
**Status:** Active. Doctrine-bound.

---

## What this vault is

The single source of truth for every Pegasus Dreamscapes brand asset, specification, and production file. Vendors, designers, agencies, contractors, and internal team members work from this vault — never from screenshots, Slack messages, or memory.

If an asset is not in this vault, it does not exist as a brand asset.

## What this vault is not

- A scratchpad for explorations
- A dumping ground for designer drafts
- A folder of "options" awaiting decisions

Exploration happens elsewhere. **Only locked, approved assets enter this vault.**

---

## Vault structure

| Folder | Contents | Audience |
|---|---|---|
| `01_BRAND_GUIDE` | Brand bible, color, typography, voice, architecture | All internal + vendors |
| `02_LOGOS` | All logo files for Pegasus Dreamscapes + Pegasus Systems + product fleet | Designers, vendors, web |
| `03_MASCOT` | Field Commander E mascot system | Marketing, social, apparel |
| `04_BUSINESS_CARDS` | Three locked card systems (Pegasus, KW, Dual) | Print vendors |
| `05_DOCUMENTS` | Letterhead, one-pagers, decks, email signatures | Internal team |
| `06_WEBSITE` | Site copy, IA, hero assets | Web team |
| `07_SOCIAL_MEDIA` | Profile specs, caption banks, post templates | Social manager |
| `08_VEHICLE` | Truck branding, decals, wrap files | Wrap shops |
| `09_APPAREL` | Embroidery files, placement guides, apparel specs | Apparel vendors |
| `10_SIGNAGE` | Yard signs, jobsite, office | Sign printers |
| `11_PEGASUS_SYSTEMS` | Software arm positioning, fleet descriptions, app branding | Product team |
| `12_VENDOR_READY` | Production-grade exports, print specs, embroidery specs | All external vendors |
| `_COMPLIANCE` | KW compliance, DRE, disclaimers, Equal Housing | Legal/marketing review |

---

## Locked decisions (Doctrine — do not modify without version increment)

**Brand identity:**
- Company name: **Pegasus Dreamscapes Corp** (California S-Corp)
- Public-facing brand: **Pegasus Dreamscapes**
- Tagline: **Dream it. Build it. Live it.**
- Software division: **Pegasus Systems**

**Color palette (locked, four colors):**
- Midnight `#1A2332`
- Navy `#243044`
- Copper `#C87A3A`
- Cream `#D4CFC4`

**Typography (locked, two fonts):**
- Playfair Display — marketing/headlines only
- Inter — all UI, body, functional copy

**Copper rule:** ~20% max usage. Five distinct uses, no sixth. See `01_BRAND_GUIDE/02_Color_System.md`.

**Mode primacy:** Dark mode is primary across digital surfaces. Light mode permitted for scoped surfaces (printed contact strips, document body) but is never the default for app UI or marketing.

---

## How to add an asset to the vault

1. Asset is finalized and approved by Apollo
2. Asset is exported in all required production formats (see `12_VENDOR_READY/Vendor_Production_Specs.md`)
3. Asset is placed in the correct folder
4. Asset's intake checklist (in that folder's README) is updated
5. If the asset changes a locked spec, the vault version increments

## How to remove an asset from the vault

You don't. Append-only. Deprecated assets move to `_ARCHIVE/` (created when needed) with a deprecation note. Same doctrine as the financial ledger.

---

## Phase rollout

| Phase | Lock target | Status |
|---|---|---|
| 1 | Master identity (Pegasus Dreamscapes logo system, color, typography, brand bible) | ✓ Specs locked. Files pending designer. |
| 2 | Pegasus Systems + product fleet icons | ✓ Specs locked. BuildForge/CapStack mostly done. HQ/MarketFlow/Peggy need redesign. |
| 3 | Business cards, email signatures, letterhead, one-pager | ✓ Specs locked. Production pending vendor selection. |
| 4 | Website, social, vehicle, signage, apparel | ✓ Specs in vault. Production pending. |
| 5 | Master Brand Bible PDF, vendor pack | ⏳ Pending Phase 1–4 production completion. |

## Vault completion status

This v1.0 vault contains **54 specification documents** across 14 folders covering every brand surface from doctrine through vendor production. The specifications are complete; production assets (logo files, photography, mockups, embroidery files, vinyl) populate the vault as designers and vendors deliver.

**What's locked in v1.0:**
- All doctrine documents (brand bible, color, typography, voice, logo usage, architecture)
- All seven logo intake checklists (Pegasus Dreamscapes parent, Pegasus Systems sub-brand, five product fleet logos)
- The Field Commander E mascot brief
- All three business card specs (Pegasus / KW / Dual)
- All six document specs (letterhead, email signatures, one-pager, pitch deck, investor deck, proposal/invoice)
- Website sitemap, IA, and full copy deck
- Social media profile specs and caption bank
- Vehicle, apparel, and signage production specs
- Pegasus Systems positioning, product fleet descriptions, and app branding spec
- Universal vendor production specs (print / embroidery / vinyl + asset pack guide)
- Compliance: KW requirements, disclaimers, DRE placement, trademark/IP

**What's pending production:**
- Logo files in all required formats (designer deliverable)
- Pegasus Systems wordmark + visual mark (Phase 2 design)
- Pegasus HQ, MarketFlow, Peggy product icon redesigns (flagged)
- Field Commander E visual exploration (three directions)
- All physical production: cards, signage, apparel, vehicle decals
- Website build at `pegasusdreamscapes.com`
- DRE license number insertion across all KW-affiliated specs
- `apollo@pegasusdreamscapes.com` email account creation

---

## Open architectural items (flagged at vault creation)

1. **Field Commander E mascot** — new lock not previously in Blueprint. Brief in vault; full visual spec pending design exploration.
2. **`apollo@pegasusdreamscapes.com`** — domain email needs to be created and replace `apollosynd@gmail.com` everywhere before founder card prints.
3. **Pegasus Systems naming** — accepted as the public-facing name for the software division. Internal Blueprint naming (Storefront/Arena/Engine/Fleet/Brain layers) remains the engineering taxonomy.
4. **DRE license number** — placeholder in all KW-affiliated assets. Must be inserted before any KW card or signage prints.
5. **Equal Housing logo** — required on all KW-affiliated marketing per brokerage rules. Sourced and placed in `_COMPLIANCE/`.
