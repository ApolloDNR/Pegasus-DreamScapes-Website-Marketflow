# Field Commander E — Mascot Brief
**Pegasus Dreamscapes**
Version 0.1 — Brief (not yet locked)

---

## Concept

Field Commander E is the embodied operator presence of Pegasus Dreamscapes. He represents what every disciplined real estate operator aspires to be: experienced, calm under pressure, fluent in both blueprints and bid sheets, equally credible on a jobsite and in a capital meeting.

He is not a cartoon. He is not a parody. He is a stylized character drawn from the same classical-aesthetic doctrine as the rest of the brand.

---

## Role in the brand

Field Commander E is **the human face of operational discipline**. He shows up where the brand needs warmth and personality without abandoning its authority:

- Educational social posts ("How a War Room actually works")
- Onboarding flows in Pegasus HQ ("Welcome — let me walk you through your first deal")
- Investor-friendly explainers (cartoon-style infographics where a logo would feel cold)
- Apparel patches and limited-run merchandise
- Internal team morale assets

He does **not** appear on:
- Capital pitch decks (too informal for that audience)
- Distressed-seller communications (could read as patronizing)
- Legal documents
- Business cards
- Vehicle wraps (too much surface area; brand should lead, not character)
- Real client-facing transactional documents

---

## Personality

| Attribute | Direction |
|---|---|
| Age impression | Mid-40s. Experienced but not old. |
| Demeanor | Calm, attentive, slightly amused. The expert who's seen this before. |
| Posture | Upright, grounded, never slumping. Never hands-on-hips (cocky). |
| Common props | Clipboard with rolled blueprints; a tablet; a coffee mug; never a hammer (he's the operator, not the laborer) |
| Wardrobe | Pegasus brand jacket (Midnight base, copper accent at chest), Inter-set name patch, work-appropriate button-up beneath |
| Expression default | Slight knowing smile. Never grinning. Never grimacing. Never winking (winking reads as schtick). |

## Voice

When Field Commander E "speaks" (in social posts, in app onboarding, in captions), he uses the brand voice — but with one shift: he can use first-person "I" naturally. He's a character, so he can reflect.

> "I've seen a hundred operators try to run a flip out of a spreadsheet. The ones who succeeded all had one thing in common: a system they could trust. That's what we built."

He never uses:
- Slang
- Emoji
- Catchphrases (no "Field Commander says…")
- Self-references like "your trusty Field Commander" — that's mascot-speak, not character voice

---

## Visual direction (three to explore)

For the visual exploration phase, the designer should present three distinct directions:

### Direction A — Editorial Realist
Drawn in the style of a high-end illustrated magazine portrait (think *The New Yorker*, *Monocle*, *Bloomberg Businessweek* spot illustration). Detailed line work, restrained color palette pulled from brand colors, painterly shading. Pros: most "premium." Cons: hardest to extend into pose library; expensive to maintain.

### Direction B — Stylized Modern
Flat vector with structural line accents. Think Mailchimp's Freddie or Stripe's character illustrations: clean shapes, minimal facial detail, expressive through posture and prop. Pros: easy to extend, scales well, vendor-friendly. Cons: risks looking like SaaS-character-by-default; must be distinctive.

### Direction C — Architectural Geometric
Character constructed from architectural primitives — rectangles, triangles, blueprint linework. Reads as "operator drawn from a blueprint." Most ownable; most novel; highest risk if execution is off. Pros: doctrine-aligned, distinctive. Cons: hardest direction to make warm.

The exploration should produce **two poses per direction** (a portrait pose and an action pose) so the comparison is fair. Do not present partial directions.

---

## Pose library (eventual scope, post-direction-lock)

Once a direction is locked, build out:

1. **Portrait** — head and shoulders, neutral expression, brand-jacketed
2. **Standing full-body** — clipboard in hand, observing
3. **Walking forward** — purposeful stride, document in hand
4. **At a desk** — reviewing plans, considering
5. **Pointing / explaining** — gesturing toward a hypothetical "this is where it goes wrong"
6. **At a jobsite** — hard hat on (jobsite mode), but still in jacket, not laborer attire
7. **In a meeting** — seated, attentive, hands clasped or steepled
8. **Approving** — slight nod, hand on a tablet stylus checking off
9. **Cautioning** — palm raised gently, "wait" gesture, no alarm
10. **Handshake** — partial frame showing the handshake, head turned to acknowledge

All poses delivered with transparent background.

---

## Usage rules (preview — to be formalized post-lock)

### Always
- Use Field Commander E at the size where his face is recognizable (minimum 200px wide for any digital placement)
- Pair him with brand-voice copy
- Keep him on Midnight or Cream backgrounds; never bright color
- Use the pose that fits the message (don't reuse the "approving" pose for a "cautioning" message)

### Never
- Animate him with bouncy, playful motion (a slow nod or subtle blink is fine; arm-waving and exaggerated movement is not)
- Caption him with sass, snark, or hot takes
- Place him in scenarios outside the operator domain (no mascot-on-vacation, no birthday hat versions, no Halloween costume)
- Pair him with another mascot or character
- Resize him below the recognizable threshold (use the Pegasus icon instead)

---

## What "E" stands for

Open question. Options on the table:
- "Executive"
- "Engineer"
- "Estate" (as in real estate)
- "Excellence"
- A specific name (e.g., "Eduardo," "Elias," "Ezra") — adds character but commits to a specific cultural read

**Recommendation:** Lock "E" as a single initial without expanding it. The mystery is more memorable than any answer. Operators introduce themselves on a jobsite by surname or initial — "Field Commander E" reads true to that pattern.

If a name is required for legal/copyright purposes (mascot character registration), use a placeholder name internally and never publish it.

---

## Sign-off required before visual exploration begins

- [ ] Brief reviewed and approved by Apollo
- [ ] Personality direction confirmed
- [ ] Three-direction exploration scope confirmed (A, B, C above)
- [ ] Designer briefed on the doctrine constraints (especially "this is not a cartoon mascot")
- [ ] Budget and timeline for exploration phase confirmed

---

*This is a brief, not a spec. The mascot does not exist as a brand asset until visual direction is locked and pose library is delivered.*
