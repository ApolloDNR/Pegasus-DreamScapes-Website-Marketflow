# 03_MASCOT

The Pegasus Dreamscapes mascot system.

## Status

**Field Commander E** is a new lock that does not appear in the Master Blueprint. This folder contains only a brief; full visual specification is pending design exploration and Apollo sign-off.

## Files

| File | Status |
|---|---|
| `Field_Commander_E_Brief.md` | ✓ Drafted (this is the design brief; not the spec) |
| Visual asset library | Pending design |
| Mascot Usage Guide | Pending visual lock |

## Why a brief instead of full assets

A mascot is a high-leverage but high-risk brand element. Done right, it gives Pegasus Dreamscapes a recognizable, ownable character (think Geico Gecko, Mailchimp's Freddie). Done wrong, it cheapens an otherwise disciplined classical brand.

The risk is acute for Pegasus because:
- The brand voice is "founder who has nothing to prove." A goofy mascot undermines this.
- Classical aesthetics + cartoon character = doctrine collision unless the visual treatment is impeccable.
- Field Commander E specifically references "field commander" — military/operational language. The execution must respect that authority, not parody it.

So: brief first, exploration second, lock third. Do not produce mascot assets without an approved visual direction.

## Phase plan

1. **Brief lock** (this document) — define personality, role, audience, do/don't constraints
2. **Visual exploration** — three directions presented for selection (recommend: Editorial Realist / Stylized Modern / Architectural Geometric — same discipline as the UI direction exploration)
3. **Direction selection** — Apollo picks one; one is locked, two are killed
4. **Pose library generation** — full pose set built from the locked direction
5. **Usage guide** — when to deploy, when not to deploy, vendor rules
