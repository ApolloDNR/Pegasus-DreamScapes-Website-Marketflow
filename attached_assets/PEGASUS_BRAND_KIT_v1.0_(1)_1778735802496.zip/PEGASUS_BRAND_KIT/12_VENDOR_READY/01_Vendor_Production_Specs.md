# Vendor Production Specifications — Universal Brief
**Pegasus Dreamscapes & Pegasus Systems**
Version 1.0

---

## What this document is

A single brief that any vendor receives alongside the production files. Tells them what brand they're producing for, what specifications matter, and what proof process is required.

Print this PDF, attach it to every vendor email. No vendor produces Pegasus work without seeing this document first.

---

## About the brand

Pegasus Dreamscapes is a real estate operating company headquartered in the San Francisco Bay Area. Premium positioning. Classical aesthetic. Operator-grade execution.

The brand discipline matters. Mass-market vendors who default to "looks fine" outputs are not a fit. Vendors who ask clarifying questions, ship proofs, and protect color accuracy are the right fit.

---

## Color specifications

| Color | HEX | RGB | CMYK | Pantone |
|---|---|---|---|---|
| Midnight | `#1A2332` | 26, 35, 50 | 89, 79, 53, 65 | PMS 539 C |
| Navy | `#243044` | 36, 48, 68 | 87, 75, 47, 47 | PMS 5395 C |
| Copper | `#C87A3A` | 200, 122, 58 | 15, 60, 90, 5 | PMS 7572 C |
| Cream | `#D4CFC4` | 212, 207, 196 | 5, 5, 12, 5 | PMS Warm Gray 2 C |

### Critical color notes
- **Copper is the brand's most fragile color in production.** Process CMYK copper drifts toward orange or muddy brown depending on press. **Pantone 7572 C** is the spec; if budget allows, use the Pantone match. If process-only, request press proof and adjust before run.
- For premium tier: **copper foil stamp** for the wordmark accent is the brand's signature physical signal. Use foil whenever budget allows.
- For embroidery: **Madeira Polyneon 1623 (Copper)** is the locked thread reference.

### What's NOT in the palette
- Pure white `#FFFFFF` — use Cream `#D4CFC4` instead
- Silver, steel, gold, or any metallic outside Copper
- Gradients of any kind

---

## Typography specifications

Two fonts. No others.

| Font | Use |
|---|---|
| **Playfair Display** | Headlines, wordmarks, ceremonial type only |
| **Inter** | Body text, captions, UI, all functional copy |

Both are open-licensed (SIL Open Font License). If your design tool can't access them, request font files included in the asset pack.

For print-shop typography substitution:
- **Playfair Display** → fallback to **Georgia** (acceptable for one-off scenarios)
- **Inter** → fallback to **Arial** (acceptable for DOCX exports)

Never substitute to Helvetica, Times New Roman, or Comic Sans (yes, this gets specified explicitly because we've seen it).

---

## File format expectations

Pegasus delivers production files in:

| Format | When supplied |
|---|---|
| `.pdf` (vector, fonts outlined) | Print production — primary format |
| `.svg` | Web, signage, digital production |
| `.ai` (Adobe Illustrator) | Source files when requested |
| `.eps` | Legacy print vendors |
| `.png` (300 DPI) | Raster placement |
| `.dst` (Tajima embroidery) | Apparel embroidery |

If the vendor's preferred format isn't on this list, request it specifically — Pegasus will produce it. Do not redraw, retypeset, or re-export Pegasus brand assets in the vendor's tools.

---

## Proof process (required)

Every Pegasus production job — without exception — requires a proof before mass production:

1. **Digital proof (PDF):** sent within 24–48 hours of file receipt. Apollo or designated reviewer approves color, layout, and copy.
2. **Physical proof (when applicable):** for high-stakes production (business cards with foil, vehicle wraps, premium apparel, signage), one physical proof is produced and reviewed in person before the production run.
3. **Color proof (for color-critical work):** press proof or printed sample on the actual stock with the actual ink. Budgeted into the project from the start.

Vendors who skip the proof step are not used again. This is the operator-discipline doctrine applied to vendor relationships.

---

## Quality benchmarks

| Surface | Quality benchmark |
|---|---|
| Business cards | Soft-touch matte coating; foil registration within 0.5mm tolerance; no visible burrs on edge cuts |
| Letterhead and documents | Full-color rendering matches Pantone reference within tolerance; no banding in flat color fills |
| Signage | Color holds for minimum 5 years outdoor (cast vinyl); no visible pixel artifacts in printed photography |
| Vehicle wraps | Premium cast vinyl (3M IJ180Cv3 or equivalent); installer-warranted minimum 5 years |
| Embroidery | Even stitch density; no puckering on small logos; thread color matches sample within tolerance |
| Apparel | Garments wash-tested before mass run; no shrinkage beyond manufacturer spec |

---

## Communication protocol

- **Single point of contact:** Apollo Duran or designated brand manager
- **Email is the source of truth:** verbal commitments are confirmed in email
- **Proof approvals are explicit:** "approved" in writing; not "looks good" in conversation
- **Production schedule is documented:** start date, proof date, mass production date, delivery date — all confirmed in writing
- **Changes after approval:** documented as change orders with cost impact stated before work proceeds

This is not bureaucratic. This is the same discipline Pegasus applies to its real estate operations. Vendors who match this discipline become long-term partners; vendors who don't become one-time relationships.

---

## Payment terms

- Standard: 50% deposit, 50% on delivery
- Net 15 from invoice for repeat vendors with established relationship
- Wire transfer or ACH preferred; check or credit card acceptable
- Late fees per invoice terms

Pegasus pays on time. We expect production on time. Mutual reliability.

---

## Brand integrity requirements

These are non-negotiable:

1. **Do not modify the logo.** No recoloring, no rotation, no stretching, no cropping, no decorative additions.
2. **Do not retypeset the wordmark.** Use the supplied vector file.
3. **Do not substitute colors.** If you cannot match the spec, contact us. Do not silently substitute.
4. **Do not add elements** (badges, "made in USA" stamps, your shop's logo, decorative borders) without explicit approval.
5. **Do not produce additional copies** beyond the order quantity. Pegasus controls its brand inventory.

Violations of these requirements terminate the vendor relationship.

---

## What to include in your quote

When quoting a Pegasus job, include:

- Itemized cost breakdown
- Specifications you're producing to (so we can confirm alignment)
- Stock / material specifications you're using
- Color reproduction method (process vs. Pantone)
- Coating, finish, and binding specifications
- Proof timeline and process
- Production timeline from approval
- Delivery method and timeline
- Reorder pricing (we will reorder if the job goes well)

Quotes that omit these details receive a request for clarification, not an order.

---

## Contact

For all production matters:

**Apollo Duran, Founder**
Pegasus Dreamscapes Corp
925-948-6566
apollo@pegasusdreamscapes.com

For Pegasus Systems-specific production (separate brand assets):
hello@pegasussystems.com

---

*End of Vendor Production Specifications v1.0.*
