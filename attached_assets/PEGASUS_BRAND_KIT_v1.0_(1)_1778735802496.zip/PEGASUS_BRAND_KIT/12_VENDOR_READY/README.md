# 12_VENDOR_READY

Production-grade specifications and exports that any external vendor can work from without context. This folder is what gets sent to print shops, embroidery vendors, vinyl wrap installers, sign printers, and apparel manufacturers.

## Files

| File | Audience |
|---|---|
| `01_Vendor_Production_Specs.md` | Universal vendor brief — colors, fonts, file formats, expectations |
| `02_Print_Specs.md` | Print vendors (cards, signage, documents) |
| `03_Embroidery_Specs.md` | Apparel and patch vendors |
| `04_Vinyl_Wrap_Specs.md` | Vehicle wrap and signage vinyl vendors |
| `05_Vendor_Asset_Pack.md` | What to include when sending files to a vendor |

## Subfolders (production assets)

When designers deliver vendor-ready files, they go into this folder organized by category:

```
12_VENDOR_READY/
├── Print/
│   ├── Business_Cards/
│   ├── Letterhead/
│   ├── One_Pagers/
│   └── Signage/
├── Embroidery/
│   └── [.dst files per logo size]
├── Vinyl/
│   ├── Vehicle/
│   └── Signage/
└── Digital/
    └── [SVG, PDF for digital production]
```

These subfolders are populated as designers deliver. The vault is empty here at brand kit creation; it fills as production happens.

## Vendor selection discipline

Pegasus uses a small set of vetted vendors per category — not the cheapest available, not the largest available, but the ones who:
- Understand premium production (no first-time-screen-printing-kid jobs)
- Communicate clearly about timelines
- Ship proof samples before mass production
- Honor the brand's color and material specifications

Establishing this vendor stack is itself a brand investment. Locked vendors per category get logged in this folder's `05_Vendor_Asset_Pack.md` as preferred suppliers.
