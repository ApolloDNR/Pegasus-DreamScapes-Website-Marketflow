# Embroidery Production Specifications
**Pegasus Dreamscapes**
Version 1.0

---

## Scope

All embroidered Pegasus Dreamscapes assets — apparel, caps, patches, and any other stitched application of the brand mark.

For garment selection guidance, see `09_APPAREL/Apparel_Spec_Sheet.md`. This document covers the embroidery production process specifically.

---

## Thread color specifications

**Locked thread brand and color reference:** Madeira Polyneon

| Brand color | Madeira reference | Use |
|---|---|---|
| Copper `#C87A3A` | Madeira Polyneon **1623 (Copper)** | Authority accent on logos; all garments |
| Cream `#D4CFC4` | Madeira Polyneon **1949 (Light Beige)** or visual match | Primary logo color on dark garments |
| Midnight `#1A2332` | Madeira Polyneon **1701 (Black)** | Primary logo color on light garments |

### Thread match validation
Before mass production, request a physical thread sample from the vendor and compare against the Pantone references in `01_BRAND_GUIDE/02_Color_System.md`. Approve match in writing before production proceeds.

If Madeira Polyneon is unavailable, equivalent threads from Isacord (40-weight rayon) are acceptable substitutes — confirm color match by physical sample.

---

## Logo digitization (critical step)

A vector logo file is **not** an embroidery file. The vector must be converted to stitch paths through a process called digitization. Different sizes require different digitizations — resizing within an embroidery file degrades stitch quality.

### Required digitizations

For Pegasus Dreamscapes apparel, digitize separately:

| Logo variant | Size | Use case |
|---|---|---|
| Pegasus Dreamscapes horizontal | 3.0" wide | Jacket left chest, polo, hoodie |
| Pegasus Dreamscapes horizontal | 6.0" wide | Vest back yoke, optional t-shirt back |
| Pegasus icon only | 1.0" tall | Button-up shirt subtle chest mark |
| Pegasus icon only | 1.5" tall | T-shirt chest, jacket sleeve, beanie |
| Pegasus icon only | 2.5" wide | Cap front |
| Pegasus wordmark only | 2.0" wide | Cap back closure strap |

### Digitization specifications

| Spec | Value |
|---|---|
| Stitch type | Standard fill stitch + satin stitch outline |
| Stitch density | Medium-high (premium feel; balanced for fabric weight) |
| Underlay | Required (typically zigzag underlay) for logo durability |
| Backing | Tear-away or cut-away appropriate to garment weight |
| Pull compensation | Adjusted for fabric stretch |
| Trim count | Minimized (excessive trims weaken thread anchor points) |
| Stitch count budget | Logo-and-size-specific; vendor specifies before production |

### Digitization deliverable
Vendor produces digitized files in:
- `.dst` (Tajima format — most universally supported)
- `.emb` (Wilcom format — for vendors using Wilcom systems)

Both files are stored in `12_VENDOR_READY/Embroidery/` once produced.

### Digitization cost
Standard cost per digitization: $25–$75 depending on logo complexity and vendor. Each size is a separate digitization (not a resize). Budget for ~6 digitizations × $50 = ~$300 for the full Pegasus apparel set.

---

## Production proof requirements

Before any mass production:

1. **Sew-out sample on actual garment:** Vendor stitches the digitized logo on the actual garment fabric and color. Apollo reviews physical sample.
2. **Wash test:** Sample garment goes through standard wash cycle. Vendor confirms no puckering, no thread loss, no color bleed.
3. **Approval in writing:** Apollo signs off on sample before production.

This proof process is non-negotiable. Embroidery quality issues are nearly impossible to correct after mass production; catching issues at sample stage is the only protection.

---

## Garment-specific notes

### Caps
- Use a structured cap base (e.g., Richardson 112, New Era 9Forty A-Frame)
- Avoid floppy or unstructured caps — they distort embroidery
- Buckram backing on the cap front holds embroidery shape
- 3D puff embroidery is **not used** — too sport-bro for the brand register

### Polos and button-ups
- Premium polos and button-ups use lightweight stabilizer to prevent puckering on lighter fabrics
- Smaller logo sizes recommended on dress shirts (1.0" icon only) to avoid overpowering the garment
- Avoid over-stitching — small logos with high stitch counts pucker

### Jackets (Carhartt, Patagonia tier)
- Heavyweight fabric supports detailed digitization
- Outline stitching enhances logo legibility on textured fabrics
- Sleeve embroidery uses cut-away backing (more permanent for heavy use)

### Hoodies and sweatshirts
- Stretchy fabric requires pull compensation in digitization
- Avoid embroidery placement that crosses seams
- Inner facing on chest embroidery prevents thread irritation against skin

---

## Vendor selection criteria

Recommended vendor profile:
- Specializes in embroidery (not screen printing, not promotional products generalist)
- Works with premium garment brands (not just basic blanks)
- Has portfolio examples on similar tier garments
- Offers digitization in-house or has a trusted partnership
- Provides sew-out samples without resistance
- Communicates clearly about turnaround

Local Bay Area vendors preferred (Apollo can drop off and inspect proofs). Online vendors (e.g., Embroidme, Real Thread) are viable for repeat production once a relationship is established.

---

## Production timeline expectations

| Step | Standard timeline |
|---|---|
| Digitization | 3–5 business days per logo size |
| Sew-out sample | 5–7 business days from digitization approval |
| Sample review and approval | 2–5 business days (Apollo turnaround) |
| Mass production | 10–14 business days for orders under 50 garments |

Plan apparel production calendars at 4–6 weeks from initial vendor engagement to delivered apparel.

---

## Files needed in `12_VENDOR_READY/Embroidery/`

- [ ] `pegasus-dreamscapes_horizontal_3in.dst`
- [ ] `pegasus-dreamscapes_horizontal_6in.dst`
- [ ] `pegasus-dreamscapes_icon_1in.dst`
- [ ] `pegasus-dreamscapes_icon_1.5in.dst`
- [ ] `pegasus-dreamscapes_icon_2.5in.dst`
- [ ] `pegasus-dreamscapes_wordmark_2in.dst`
- [ ] Source vector files (`.svg`) for vendor reference
- [ ] Thread color reference card (Madeira swatches for Copper 1623, Cream/Light Beige 1949, Black 1701)

---

*End of Embroidery Production Specs v1.0.*
