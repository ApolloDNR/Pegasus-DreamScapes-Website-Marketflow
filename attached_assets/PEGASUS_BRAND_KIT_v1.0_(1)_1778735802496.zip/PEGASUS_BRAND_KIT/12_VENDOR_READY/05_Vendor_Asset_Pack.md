# Vendor Asset Pack — Hand-off Checklist
**Pegasus Dreamscapes & Pegasus Systems**
Version 1.0

---

## What to send a vendor

When engaging a vendor for any production work, send a single email with a single zip file that contains everything they need to produce — and nothing they don't.

The standard asset pack includes:

### 1. The cover letter (always)
A short email or PDF that includes:
- Project name
- Specifications summary (what's being produced)
- Quantity
- Timeline
- Single point of contact (Apollo + email + phone)
- Reference to the Vendor Production Specs

### 2. The Vendor Production Specs (always)
PDF of `01_Vendor_Production_Specs.md` — the universal brief.

### 3. The category-specific spec (always)
- Print job → `02_Print_Specs.md`
- Embroidery job → `03_Embroidery_Specs.md`
- Vinyl/wrap job → `04_Vinyl_Wrap_Specs.md`

### 4. The production files (always, job-specific)
Vector files (`.svg`, `.pdf`, `.ai`) and any raster files needed. **Do not send the entire brand vault.** Send only the variants and sizes the vendor needs.

### 5. The relevant brand guides (situational)
- For any job touching color: send `01_BRAND_GUIDE/02_Color_System.md`
- For any job touching typography (rare in vendor production): send `01_BRAND_GUIDE/03_Typography_System.md`
- For any job touching the logo: send `01_BRAND_GUIDE/05_Logo_Usage_Guide.md`

### 6. Reference samples (situational)
For premium production, include physical or digital reference samples of similar quality work the vendor should match.

### 7. The KW compliance overlay (KW-affiliated jobs only)
For any production touching the KW brand or DRE-licensed advertising: send `_COMPLIANCE/KW_Compliance_Requirements.md` and the Equal Housing logo file.

---

## Asset pack structure (zipped folder)

```
pegasus_vendor_pack_[vendor-name]_[date]/
├── 00_README.pdf  (cover letter + project brief)
├── 01_Production_Specs.pdf  (vendor brief)
├── 02_[Category]_Specs.pdf  (print/embroidery/vinyl)
├── 03_Brand_Color_System.pdf  (when color-relevant)
├── 04_Logo_Usage_Guide.pdf  (when logo-relevant)
├── 05_Files/  (production files only)
│   ├── pegasus-dreamscapes_[asset]_[variant].svg
│   ├── pegasus-dreamscapes_[asset]_[variant].pdf
│   └── ...
└── 06_References/  (optional reference samples)
    └── ...
```

---

## Per-category asset pack templates

### Business card production pack
```
00_README.pdf
01_Production_Specs.pdf
02_Print_Specs.pdf
03_Brand_Color_System.pdf
04_Logo_Usage_Guide.pdf
05_Files/
  ├── pegasus-dreamscapes_business-card_card1_print-ready.pdf
  ├── pegasus-dreamscapes_business-card_card2_print-ready.pdf
  └── pegasus-dreamscapes_business-card_layout-spec.pdf
```

### Embroidered apparel production pack
```
00_README.pdf
01_Production_Specs.pdf
02_Embroidery_Specs.pdf
03_Brand_Color_System.pdf
04_Logo_Usage_Guide.pdf
05_Files/
  ├── pegasus-dreamscapes_horizontal_3in.dst
  ├── pegasus-dreamscapes_horizontal_3in_reference.svg
  ├── pegasus-dreamscapes_icon_1.5in.dst
  └── pegasus-dreamscapes_icon_1.5in_reference.svg
06_References/
  └── thread_color_swatches.pdf
```

### Vehicle decal production pack
```
00_README.pdf
01_Production_Specs.pdf
02_Vinyl_Wrap_Specs.pdf
03_Brand_Color_System.pdf
04_Logo_Usage_Guide.pdf
05_Files/
  ├── pegasus-dreamscapes_vinyl_door-decal_14in.svg
  ├── pegasus-dreamscapes_vinyl_door-decal_14in_print-ready.pdf
  ├── pegasus-dreamscapes_vinyl_tailgate-decal_24in.svg
  ├── pegasus-dreamscapes_vinyl_tailgate-decal_24in_print-ready.pdf
  ├── pegasus-dreamscapes_vinyl_window-badge_5in.svg
  ├── pegasus-dreamscapes_vinyl_pinstripe.svg
  └── pegasus-dreamscapes_vehicle_mockup.pdf
```

### KW yard sign production pack
KW yard signs use KW-templated designs from KW Command. **Pegasus does not produce KW yard signs from this vault** — the vault tracks that the requirement exists, but the production goes through KW's approved sign vendors with KW-templated artwork.

---

## Vendor onboarding (first-time vendor)

For vendors Pegasus has not worked with before, the first asset pack also includes:

- A short "About Pegasus Dreamscapes" PDF (lifted from `01_BRAND_GUIDE/01_Master_Brand_Bible.md` Section 1)
- A request for the vendor to confirm receipt and any clarifying questions before starting work
- A request for the vendor to provide their proof process and timeline before quoting

This onboarding sets the discipline tone. Vendors who respond casually ("we'll figure it out as we go") are probably not the right vendors.

---

## After the production run

Post-production, update the vault:

1. Add the produced asset to the relevant folder (e.g., produced business cards photographed and added to `04_BUSINESS_CARDS/_PRODUCED/`)
2. Log the vendor name, production date, quantity, cost, and quality notes in this folder's `_VENDOR_LOG.md` (created when first vendor relationship is established)
3. Update the relevant intake checklist if the asset is part of a tracked set
4. If the vendor performed well, log them as a preferred vendor for that category

---

## Preferred vendor log (template)

To be populated as relationships are established:

| Vendor | Category | Contact | First worked | Quality | Recommend? |
|---|---|---|---|---|---|
| [Name] | [Print / Embroidery / Vinyl / Sign / Wrap] | [Email + phone] | [Date] | [1–5] | [Yes / No / Conditional] |

---

## What not to send vendors

- Internal Pegasus documents (Master Blueprint, Brand Bible) — they don't need them
- The full brand vault — confusing and includes assets the vendor doesn't produce
- Editable source files (`.fig`, `.indd`) — vendors should produce from print-ready exports, not source files
- Compliance documents unrelated to the job (e.g., KW compliance for a Pegasus-only print job)
- Personal information (Apollo's home address, personal email) — keep production correspondence on company email and addresses

---

*End of Vendor Asset Pack v1.0.*
