# Print Production Specifications
**Pegasus Dreamscapes & Pegasus Systems**
Version 1.0

---

## Print job categories covered

| Category | Spec section |
|---|---|
| Business cards | Section 1 |
| Letterhead | Section 2 |
| One-pagers and brochures | Section 3 |
| Signage (paper-printed; aluminum/coroplast in `04_Vinyl_Wrap_Specs.md`) | Section 4 |
| Promotional cards / postcards | Section 5 |

---

## Section 1 — Business Cards

### Specifications (all three card systems)

| Spec | Value |
|---|---|
| Dimensions | 3.5" × 2.0" (US standard) |
| Stock | 22pt soft-touch matte (Pegasus tier); 18pt for KW per template |
| Color mode | CMYK + spot color where applicable |
| Spot color | Pantone 7572 C for copper |
| Coating | Soft-touch matte both sides (Pegasus tier); matte (KW tier) |
| Foil (optional premium) | Copper foil stamp on logo wordmark accent |
| Edge | Square (no rounded corners) |
| Bleed | 0.125" full bleed |
| Safe area | 0.125" inset from trim line |
| Print method | Offset preferred; high-quality digital acceptable for runs under 500 |

### Vendor short list (recommend obtaining quotes from each)

- **Local Bay Area print shop** (preferred — Apollo can drop off and inspect)
- **Moo Premium** (online; supports luxe stocks; foil available on Luxe tier)
- **Vistaprint Premium** (online; budget tier; foil limited)
- **Specialty foil-stamping vendor** (required if foil is the lead spec)

### Pre-order checklist

- [ ] Final card design exported as print-ready PDF with embedded fonts and outlined paths
- [ ] Pantone 7572 C confirmed available (or process build approved if Pantone unavailable)
- [ ] DRE license number inserted (KW + Dual cards only)
- [ ] Vendor quotes obtained from minimum two sources
- [ ] Physical proof requested and approved before mass production

---

## Section 2 — Letterhead

### Specifications

| Spec | Value |
|---|---|
| Dimensions | 8.5" × 11" (US Letter) |
| Stock | 24lb premium text weight (substantial feel); 70lb opaque for ultra-premium |
| Color mode | CMYK |
| Spot color | Pantone 7572 C for copper rule (when budget allows) |
| Coating | None (uncoated for write-on capability) |
| Print method | Offset for runs over 500; digital for smaller |
| Pre-printed quantity | 500 sheets for first run; reorder when 25% remains |

### Pre-order checklist

- [ ] Final letterhead design exported as print-ready PDF
- [ ] Mailing address confirmed (PO Box recommended for founder-stage privacy)
- [ ] Email and website confirmed live
- [ ] Vendor confirms paper stock availability
- [ ] First-run proof approved

### Production note
For digital-only use, the letterhead PDF template is the source of truth and no print production is required. Print runs are for formal correspondence with audiences who value physical letterhead (capital partners, legal documents, formal proposals).

---

## Section 3 — One-pagers and brochures

### Specifications (one-pagers)

| Spec | Value |
|---|---|
| Dimensions | 8.5" × 11" |
| Stock | 100lb gloss cover (premium handout) or 80lb matte text (lighter) |
| Color mode | CMYK + Pantone 7572 C |
| Coating | Soft-touch matte (premium); aqueous (standard) |
| Sides | Single-sided default; double-sided for Investor variant |
| Bleed | 0.125" full bleed |
| Print method | Digital for short runs (under 100); offset for larger |

### Specifications (brochures — folded)

If a multi-panel brochure is produced (Phase 4+), use:
- 11" × 17" trifold format (folds to 8.5" × 11" finished panels)
- Same stock and color specifications as one-pager
- Score lines must be precisely placed; request a folded proof, not just a flat proof

### Pre-order checklist

- [ ] Variant determined (Investor / Partner / Operator)
- [ ] Numbers and metrics in proof band verified for accuracy at print date
- [ ] Vendor proof approved before mass run

---

## Section 4 — Paper-printed signage

For temporary or indoor signage on paper or cardstock (event signage, presentation handouts, project sale-flyer placements). For outdoor signage on aluminum, coroplast, or vinyl, see `04_Vinyl_Wrap_Specs.md`.

### Specifications

| Spec | Value |
|---|---|
| Dimensions | Variable (event-dependent) |
| Stock | 100lb cover for standees; 80lb text for handouts |
| Color mode | CMYK + Pantone 7572 C |
| Coating | UV-coated for repeated handling; matte for premium feel |
| Mounting (when applicable) | Foam-core mount, gator board, or rigid sign substrate |

---

## Section 5 — Promotional cards and postcards

For acquisition marketing direct mail, promotional invitations, and similar.

### Specifications

| Spec | Value |
|---|---|
| Dimensions | 5" × 7" (postcard) or 4" × 6" (smaller) |
| Stock | 16pt cover with UV coating for mail durability |
| Color mode | CMYK + Pantone 7572 C |
| Coating | UV gloss front, uncoated back (for write-on / stamp space if direct mail) |
| Postage zone | 4.25" × 2" clear zone in upper-right corner of back, no graphics |

### Direct mail compliance
- **USPS regulations:** Address block placement, postage zone, indicia requirements vary by mailing class. Confirm with mailing house before printing.
- **Acquisition marketing:** "Do Not Sell" registry compliance for any direct mail to property owners — verify list source compliance.

---

## File preparation requirements (for designers handing off to vendors)

Every print-ready PDF must include:

- [ ] Embedded fonts OR all text outlined to paths
- [ ] CMYK color mode (no RGB)
- [ ] Pantone spot color called out as Pantone 7572 C (where applicable)
- [ ] 0.125" bleed on all edges
- [ ] 0.125" safe-area margin inside trim line
- [ ] Trim marks and bleed marks visible
- [ ] Pages exported at correct trim dimensions
- [ ] Image resolution minimum 300 DPI at print size
- [ ] No transparency flattened ambiguities (flatten before export)
- [ ] File naming: `pegasus_[document]_[version]_print-ready.pdf`

---

## Color reproduction tolerance

Pegasus accepts ±3 Delta E from spec color reference for process print, ±2 Delta E for Pantone matches. Beyond that tolerance, the proof is rejected.

In plain language: copper that prints as orange is rejected. Copper that prints as muddy brown is rejected. Copper that prints as a slightly different shade of copper is accepted with notation.

---

## Production timeline expectations

| Job | Standard turnaround |
|---|---|
| Business cards (digital, no foil) | 5–7 business days |
| Business cards (offset with foil) | 10–14 business days |
| Letterhead | 5–10 business days |
| One-pager (digital) | 3–5 business days |
| One-pager (offset) | 7–14 business days |
| Signage (paper) | 3–7 business days |

These are vendor-side timelines. Add 1–3 days for proof review and approval. Plan production calendars accordingly.

---

*End of Print Production Specs v1.0.*
