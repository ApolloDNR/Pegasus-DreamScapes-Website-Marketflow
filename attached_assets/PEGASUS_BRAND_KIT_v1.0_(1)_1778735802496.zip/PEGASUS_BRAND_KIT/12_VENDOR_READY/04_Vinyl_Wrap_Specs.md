# Vinyl and Wrap Production Specifications
**Pegasus Dreamscapes**
Version 1.0

---

## Scope

All vinyl-cut and vinyl-printed Pegasus Dreamscapes assets:

- Vehicle decals (door, tailgate, window badge, pinstripe)
- Outdoor signage (yard signs, jobsite signs)
- Office wall signage (rigid sign substrate)
- Window decals (storefront, office, project marketing)
- Promotional vinyl (event banners, retractable banner stands)

---

## Vinyl material specifications

### Vehicle vinyl
- **Type:** Cast vinyl, premium grade
- **Brand:** 3M Controltac IJ180Cv3 or Avery MPI 1105 (industry-standard for vehicle wraps)
- **Finish:** Matte preferred; satin acceptable; gloss avoided (signals contractor-tier per `08_VEHICLE/Truck_Branding_Spec.md`)
- **Adhesive:** Removable (relevant for leased vehicles); permanent only when vehicle is owned and decommissioning is not anticipated
- **Warranty:** Vendor-warranted minimum 5 years against fade and lift on vertical surfaces; 3 years on horizontal surfaces

### Outdoor signage vinyl (banners, decals)
- **Type:** Calendared vinyl for short-term (under 1 year); cast vinyl for long-term (1–5 years)
- **Backing:** Permanent adhesive for fixed installations; removable for temporary installations
- **Outdoor durability:** Minimum 5 years for permanent installations; verify vendor warranty

### Window decals
- **Type:** Optically clear vinyl with white-ink underprint when applied to dark windows; standard adhesive vinyl for light windows
- **Mounting:** Inside-window or outside-window — specify per installation (impacts vinyl orientation and finish)
- **Removability:** Standard removable adhesive

---

## Color reproduction in vinyl

### Cut vinyl (single-color logo cuts)
- Solid color sheets cut to logo shape
- Pegasus Cream or Pegasus Copper sheets sourced from vendor stock
- Color match: visual approval against Pantone reference; Cream and Copper sheets vary slightly by vinyl manufacturer
- For copper vinyl: request Avery Supreme Wrapping Film "Matte Brushed Copper" or 3M 1080 "Matte Copper Metallic" — these provide the brand's authentic copper appearance, not a printed approximation

### Printed vinyl (full-color decals, photo-printed signage)
- Wide-format eco-solvent or latex print
- 720 DPI minimum for outdoor; 1440 DPI for close-viewing applications
- Pantone matching: vendor calibrates printer to Pantone reference; press proof required for color-critical work
- Lamination: matte UV-protective lamination required for outdoor printed vinyl (5+ year durability)

---

## Production specifications by application

### Vehicle door decals (12–14" wide)

| Spec | Value |
|---|---|
| Vinyl | 3M IJ180Cv3 cast vinyl, matte finish |
| Print method | Eco-solvent or latex print + matte lamination |
| Color | Cream + Copper logo on Midnight vehicle (or Midnight + Copper on Cream vehicle) |
| Application | Professional installer required (not DIY) |
| Surface prep | Vehicle washed and IPA-wiped 24 hours before installation |
| Installation | Heat-applied for compound curves; squeegee for flat surfaces |

### Vehicle tailgate decals (18–24" wide)

Same vinyl spec as door. Tailgate installation requires careful alignment to factory body lines for premium appearance.

### Vehicle window badge (4–5" tall)

| Spec | Value |
|---|---|
| Vinyl | Optically clear vinyl with cut Pegasus icon |
| Color | Single-color Cream or Copper |
| Position | Bottom-right corner of rear window |
| Removability | Removable adhesive |

### Vehicle pinstripe (1/8" wide, door-to-door)

| Spec | Value |
|---|---|
| Vinyl | Avery Supreme Wrapping Film "Matte Brushed Copper" or 3M equivalent |
| Application | Continuous strip following body crease line below door handles |
| Length | Custom per vehicle |

### Yard signs (24" × 18" or 24" × 24")

| Spec | Value |
|---|---|
| Substrate | Coroplast (corrugated plastic) for short-term; aluminum composite for long-term |
| Print | Single or double-sided eco-solvent print directly on substrate |
| Lamination | Matte UV-protective lamination |
| Mounting | H-frame wire stake (coroplast) or U-channel ground post (aluminum) |
| Quantity | 25 minimum first run for "We Buy Houses" acquisition marketing |

### Jobsite signs (24" × 18" or 36" × 24")

| Spec | Value |
|---|---|
| Substrate | Aluminum composite (Dibond, ACM) — weatherproof, durable for project duration |
| Print | Eco-solvent or UV-cure print, full-color |
| Lamination | Matte UV-protective lamination |
| Mounting | Plywood-backed; mounted to chain-link fence or temporary stake |
| Hardware | Stainless or galvanized fasteners (no rust streaking on the brand) |

### Office wall sign

| Spec | Value |
|---|---|
| Substrate | Brushed metal (copper, bronze) or premium acrylic with metallic finish |
| Construction | Layered acrylic with vinyl logo overlay, or routed metal |
| Mounting | Standoff mounting (raised 0.5–1.0" off wall) |
| Lighting | Optional uplight or backlighting for premium presentation |

---

## File preparation for vinyl production

### Cut vinyl (single-color cuts)
- Vector file only (`.svg`, `.ai`, or `.eps`)
- All paths converted from strokes to filled shapes
- No overlapping or self-intersecting paths
- Minimum line weight 0.05" (smaller weights tear during cutting)
- Mirror image included if installation is on inside of glass

### Printed vinyl
- Vector file with embedded raster elements as needed
- CMYK color mode + Pantone callouts
- 0.125" bleed all around
- 300 DPI minimum for any embedded photography
- Bleed and trim marks visible

### File naming
```
pegasus-dreamscapes_vinyl_[application]_[dimensions].svg
Example: pegasus-dreamscapes_vinyl_door-decal_14in.svg
```

---

## Installation specifications

Pegasus does not perform installations. Vendor or vendor-recommended installer handles installation. Required:

- Professional installer with portfolio of similar work
- Climate-controlled installation environment (vehicle wraps especially)
- Surface prep documented before installation
- Post-installation photos delivered to Pegasus for brand asset library
- Installation warranty in writing (typically 1 year against bubbling, lifting)

---

## Vendor selection criteria

| Tier | Vendor profile |
|---|---|
| Vehicle wraps | Specialty wrap shop (not generic sign printer) — must show vehicle wrap portfolio |
| Premium signage (office, project feature) | Architectural sign fabricator (not general print shop) |
| Yard / jobsite signage | Standard sign printer acceptable; bulk pricing matters at this tier |
| Window decals | Sign printer with cut-vinyl experience |
| Banners / event vinyl | Standard sign printer; lead time matters more than premium quality |

---

## Color match validation

Before any vinyl production:
1. Vendor produces a small printed test swatch on the actual vinyl with the actual ink
2. Apollo reviews physically and approves
3. Production proceeds

For critical brand surfaces (vehicle decals, office sign), this color test is non-negotiable. For lower-tier surfaces (temporary yard signs), digital proof approval is acceptable.

---

## Production timeline expectations

| Job | Standard timeline |
|---|---|
| Cut vinyl decals (small) | 3–5 business days |
| Printed vinyl decals (vehicle door set) | 5–7 business days from approval |
| Vehicle wrap installation | Schedule 1–2 weeks ahead; installation takes 1–2 days |
| Yard signs (bulk) | 7–10 business days |
| Jobsite signs | 5–7 business days |
| Office wall sign | 3–4 weeks (custom fabrication) |

---

## Files needed in `12_VENDOR_READY/Vinyl/`

### Vehicle subfolder
- [ ] `pegasus-dreamscapes_vinyl_door-decal_14in.svg`
- [ ] `pegasus-dreamscapes_vinyl_door-decal_14in_print-ready.pdf`
- [ ] `pegasus-dreamscapes_vinyl_tailgate-decal_24in.svg`
- [ ] `pegasus-dreamscapes_vinyl_window-badge_5in.svg`
- [ ] `pegasus-dreamscapes_vinyl_pinstripe.svg`
- [ ] Vehicle mockup PDF showing all five positions

### Signage subfolder
- [ ] `pegasus-dreamscapes_yard-sign_24x18_print-ready.pdf`
- [ ] `pegasus-dreamscapes_jobsite-sign_36x24_print-ready.pdf`
- [ ] `pegasus-dreamscapes_office-sign_template.svg` (vector outline for fabrication)

---

*End of Vinyl and Wrap Production Specs v1.0.*
