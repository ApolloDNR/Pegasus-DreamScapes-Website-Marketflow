# Website — Copy Deck
**Pegasus Dreamscapes** (`pegasusdreamscapes.com`)
Version 1.0 — Draft for review

---

All copy below uses the brand voice per `01_BRAND_GUIDE/04_Voice_and_Tone.md`. Every line should be readable aloud as something a disciplined founder would actually say.

---

## Home — `/`

### Hero
**Headline (Playfair Display Black, large):**
> A vertically integrated real estate operating company.

**Sub-headline (Inter Regular, 18pt):**
> We acquire, develop, and operate properties across the Bay Area and Sacramento — using software we built ourselves.

**Primary CTA:** Start a conversation → /contact
**Secondary CTA:** See our approach → /approach

### Section 2 — The three arms

**Section eyebrow:** WHAT WE DO

**Headline:** Three arms. One company. One standard.

| Arm | One-line description |
|---|---|
| **Development** | Ground-up construction and value-add renovation, executed with classical aesthetics and operator-grade discipline. |
| **Investments** | Capital deployed into BRRRR, fix-and-flip, wholesale, and held assets — all underwritten on the same proforma doctrine. |
| **Systems** | Pegasus Systems — the proprietary software arm building the operating infrastructure for disciplined real estate execution. |

CTA below: Explore our approach → /approach

### Section 3 — Featured projects

**Section eyebrow:** RECENT WORK

**Headline:** The work speaks first.

[Three project tiles. Each tile: photo + project name + location + key metric (e.g., "Concord BRRRR — Acquired $410K, ARV $640K").]

CTA below: See all projects → /projects

### Section 4 — Pegasus Systems teaser

**Section eyebrow:** OUR SOFTWARE

**Headline:** We don't rent our operating system. We built it.

**Body (one paragraph):**
> Pegasus Systems is the operating infrastructure that runs Pegasus Dreamscapes — and is being licensed to the broader operator market. Five products, one doctrine: HQ commands, the fleet proposes, the AI advises. Built by operators, for operators.

CTA: See Pegasus Systems → pegasussystems.com (external link styled)

### Section 5 — Founder note

**Section eyebrow:** A NOTE FROM APOLLO

**Body (first-person, founder voice):**
> I started Pegasus Dreamscapes because I refused to run a real estate company out of spreadsheets and sticky notes. Every operator I respect either built their own systems or outgrew their tools fighting them. I'm building Pegasus to be the company that owns its infrastructure end-to-end — and Pegasus Systems to be the platform that other operators can use to do the same.
>
> If that sounds like the kind of operator you want to work with, I'd like to hear from you.
>
> — Apollo Duran, Founder

CTA: Reach out → /contact

### Section 6 — Contact CTA

**Headline (Playfair):** Let's build something.

**Body:** Capital partner, property opportunity, vendor, or operator looking at our software — start the conversation.

**Primary CTA:** Contact us → /contact
**Secondary:** Direct line: 925-948-6566

---

## Approach — `/approach`

### Hero

**Headline:**
> Vertical integration is the only honest model.

**Sub-headline:**
> Real estate operators who outsource their critical functions cap their ceilings. Pegasus Dreamscapes was built on the opposite premise: own the layers that own the margin.

### Section — The model

**Body:**
> Pegasus operates across three arms: Development, Investments, and Systems. They are not separate businesses — they are interlocking functions of a single operating company. Development sources and executes the construction. Investments structures the capital. Systems builds the software that makes both run with discipline at scale.
>
> Most operators rent their systems and outsource their construction. We own both. The result is faster cycles, tighter margins, and a permanent record of every decision.

### Three sub-sections (one per arm)

Each arm gets a section that links to its detail page.

#### Development
**Headline:** Build it like it's going to last.
**Body:** Ground-up construction and substantial renovation across the Bay Area and Sacramento, executed with classical aesthetics and operator-grade discipline. Every project ships with a written scope, a milestone schedule, and on-time payment to the vendors who deliver.

CTA: Read more → /approach/development

#### Investments
**Headline:** Underwriting is the discipline.
**Body:** Capital deployed across BRRRR, fix-and-flip, wholesale, and long-term hold strategies. Every deal is underwritten on the same proforma doctrine — three scenarios, explicit assumptions, no narrative substituting for numbers.

CTA: Read more → /approach/investments

#### Systems
**Headline:** Operators who own their systems own their margins.
**Body:** Pegasus Systems is the proprietary software arm of Pegasus Dreamscapes. Five products, one doctrine, one mission: replace the spreadsheets, sticky notes, and email threads with a system worth running a real estate business on.

CTA: See Pegasus Systems → pegasussystems.com

---

## Approach Detail Pages

Drafted to the same template; per-arm copy follows. Headlines use Playfair, body Inter.

### `/approach/development`

**Hero headline:** Construction with classical authority.
**Sub-headline:** Ground-up and value-add development across the Bay Area and Sacramento.

**Three pillars:**
1. **Scope clarity.** Every project ships with a written scope and a milestone-based payment schedule. No surprises.
2. **Operator-led coordination.** Project management routes through Pegasus HQ — single source of truth, no "didn't get your email."
3. **Classical aesthetic execution.** Architecture and finish standards inspired by classical design. We are not building anonymous boxes.

### `/approach/investments`

**Hero headline:** Capital deployed with discipline.
**Sub-headline:** BRRRR, fix-and-flip, wholesale, and long-term hold strategies — underwritten to the same standard.

**Three pillars:**
1. **One proforma standard.** Every opportunity passes through the same underwriting template, with explicit assumptions in three scenarios.
2. **Geographic discipline.** We invest where we can drive to the inspection. Bay Area and Sacramento are our scope.
3. **Investor-grade reporting.** Capital partners receive structured updates on a defined cadence, not narrative emails on demand.

### `/approach/systems`

**Hero headline:** The operating system, by us, for operators.
**Sub-headline:** Pegasus Systems — five products, one doctrine.

**Three pillars:**
1. **Built dogfood-first.** Pegasus Dreamscapes runs on Pegasus Systems. Every feature has been pressure-tested in our own deals before it reaches an external operator.
2. **HQ commands. Fleet proposes. Peggy advises.** A single authority hierarchy across every product.
3. **Embedded finance roadmap.** From ledger to Stripe Connect to embedded lending — the capital infrastructure operators have been waiting for.

CTA: See Pegasus Systems → pegasussystems.com

---

## Projects — `/projects`

### Hero
**Headline:** The track record.
**Sub-headline:** Every Pegasus deal, documented as a permanent record.

### Filter UI labels
- "All projects"
- "Strategy: BRRRR / Flip / Wholesale / Development / Hold"
- "Status: Completed / In Progress / Recently Closed"
- "Location: Bay Area / Sacramento / Other"

### Empty state (when filters return zero)
> No projects match these filters yet. We're selective.

### Project tile copy template
- **Title:** [Project name or address]
- **Location:** [City, State]
- **Strategy:** [BRRRR / Flip / Wholesale / Development / Hold]
- **Status:** [Completed / In Progress]
- **Headline metric:** "Acquired $XXX. ARV $XXX." (or equivalent honest summary)

---

## About — `/about`

### Hero
**Headline:** Pegasus Dreamscapes is an operating company.
**Sub-headline:** Not a brokerage. Not a fund. Not a contractor. An operator that holds those functions inside one disciplined entity.

### Section — Mission, vision, values

**Mission:**
> To turn distressed properties into designed investments through disciplined operational systems and classical aesthetic execution.

**Vision:**
> A vertically integrated real estate operating company that develops communities ground-up, deploys generational capital, and operates the software infrastructure the rest of the industry will eventually run on.

**Values (six tiles):**
1. **Discipline** — Architecture before building. No shortcuts.
2. **Transparency** — Investor-grade documentation at every layer.
3. **Innovation** — Build the operating system. Don't rent it.
4. **Integrity** — The deal is the deal. The doctrine is the doctrine.
5. **Excellence** — Classical execution. Premium finish. No "good enough."
6. **Efficiency** — Templates are the doctrine. Repeatable systems beat heroic effort.

### Section — Brand architecture

[Visual diagram: parent → three arms → product fleet]

**Caption:**
> Pegasus Dreamscapes is the parent operating company. Development, Investments, and Systems are the operational arms. Pegasus Systems — the software arm — operates products that serve both Pegasus Dreamscapes and the broader operator market.

CTA: Meet the founder → /about/founder

---

## Founder — `/about/founder`

### Hero
- Apollo's photo (professional, restrained, not stock-portrait energy)
- **Headline:** Apollo Duran, Founder.
- **Sub-headline:** Operator. Realtor®. Building the operating company he wanted to work for.

### Bio (first-person, founder voice)

> I grew up around construction. My father is a licensed general contractor; my partner is an interior designer. I've been running businesses since high school — day trading, flooring coordination, project management — and I held a California real estate license through Keller Williams while building Pegasus Dreamscapes.
>
> Pegasus exists because every operator I respected was either fighting their tools or had built their own. I picked the second path. Pegasus Dreamscapes is the operating company. Pegasus Systems is the software that runs it. We're building both at the same time, on purpose, because the only way to build a software platform real operators will trust is to be one.
>
> I work with capital partners who want disciplined returns, contractors who deliver scope on time, and operators who are tired of running real estate businesses out of spreadsheets. If that's you, the contact form is live.

### Philosophy section
[Lift selected lines from `01_BRAND_GUIDE/01_Master_Brand_Bible.md` → "Section 4 — Brand Personality" and "Section 8 — Long-form Company Description," lightly adapted for narrative voice.]

### Press / appearances
[Empty until populated. Do not include placeholder logos. Either there's something here or there isn't.]

CTA: Reach out directly → /contact

---

## Contact — `/contact`

### Hero
**Headline:** Start the conversation.
**Sub-headline:** Capital, property, partnership, or platform — we read every inquiry.

### Form fields
- Name (required)
- Email (required)
- Phone (optional)
- Inquiry type (required, select):
  - "Capital partnership"
  - "Property opportunity (I want to sell)"
  - "Vendor or contractor relationship"
  - "Pegasus Systems product demo"
  - "Press / media"
  - "Other"
- Message (required, textarea)
- "How did you hear about us?" (optional)

### Form submit button: "Send"

### Direct contact (below form)
- Phone: 925-948-6566
- Email: apollo@pegasusdreamscapes.com
- Service area: Bay Area + Sacramento, California

### Confirmation (after submit)
> Got it — we'll be in touch within two business days.

If response time will exceed two days (vacation, capital-raise crunch), update this copy honestly. Operator-mature brands keep their promises about response time.

---

## 404 page

**Headline:** That page doesn't exist.
**Sub-headline:** Either we deleted it, or you typed it wrong. Either way, here are the pages that do exist.

[List of top-level pages with links.]

CTA: Back to home → /

---

## Microcopy

| Surface | Copy |
|---|---|
| Cookie banner (if used) | "We use minimal analytics to understand site traffic. No personal data is sold." |
| Newsletter (if added later) | "Operator-grade real estate insights, monthly. No fluff." |
| Form validation: required field | "Required" |
| Form validation: bad email | "That email looks off — double-check." |
| Form submission error | "Something went wrong. Email apollo@pegasusdreamscapes.com directly." |
| Loading state | "One moment." |

---

## Pre-lock checklist

- [ ] Apollo reviews and approves all founder-voice copy
- [ ] Legal review of any disclosure-adjacent copy (especially around Investments)
- [ ] Real project data populated for "Featured Projects" section before launch
- [ ] Domain `pegasusdreamscapes.com` confirmed and SSL configured
- [ ] All copy reviewed against `01_BRAND_GUIDE/04_Voice_and_Tone.md` (no AI-tells, no corporate-speak, no exclamation points)

---

*End of Website Copy Deck v1.0.*
