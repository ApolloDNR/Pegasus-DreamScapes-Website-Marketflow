# Website — Sitemap & Information Architecture
**Pegasus Dreamscapes** (`pegasusdreamscapes.com`)
Version 1.0

---

## Top-level navigation

```
PEGASUS DREAMSCAPES
├── Home
├── Approach
│   ├── Development
│   ├── Investments
│   └── Systems
├── Projects
│   └── [Individual project case studies]
├── Pegasus Systems  →  links to pegasussystems.com (external sub-brand site)
├── About
│   └── Founder
└── Contact
```

**Total top-level items in nav: 5** — Home / Approach / Projects / About / Contact.

Pegasus Systems lives under "Approach > Systems" on this site, with a prominent CTA on that page driving users to the standalone `pegasussystems.com` product site. This keeps the parent site focused on the operating company; Pegasus Systems gets its own unconstrained product surface.

---

## Page-by-page IA

### 1. Home (`/`)

**Purpose:** Establish the brand in 5 seconds. Drive scroll into the next page or contact form.

**Sections (top to bottom):**
1. Hero — Pegasus Dreamscapes positioning headline + tagline + primary CTA
2. The three arms — Development, Investments, Systems (visual + one-line per arm)
3. Featured projects — three latest projects with photos and key metrics
4. Pegasus Systems teaser — one-section explainer + CTA to `pegasussystems.com`
5. Founder note — short personal statement from Apollo + photo
6. Contact CTA — phone, email, calendar booking link

### 2. Approach (`/approach`)

**Purpose:** The "what we do" page. Detailed enough to satisfy a sophisticated visitor; concise enough that they can read it in 4 minutes.

**Sub-pages (also accessible via top nav):**
- `/approach/development` — Ground-up + value-add construction
- `/approach/investments` — BRRRR, fix-and-flip, wholesale, hold strategies
- `/approach/systems` — Pegasus Systems intro + outbound link to product site

Each sub-page follows the same structure:
1. Section hero with headline + visual
2. Three pillars with explanation
3. Recent project or product proof
4. CTA

### 3. Projects (`/projects`)

**Purpose:** Track record. The credibility layer.

**Listing page:** Grid of completed and in-progress projects, filterable by:
- Strategy (BRRRR / Flip / Wholesale / Development / Hold)
- Status (Completed / In Progress / Recently Closed)
- Location (Bay Area / Sacramento / Other)

**Individual project page (`/projects/[slug]`):**
1. Hero photo + project name + location
2. Key metrics: acquisition price, all-in basis, ARV/sale price, return, timeline
3. Before / after gallery
4. Strategy summary (one paragraph)
5. Team and partners on this deal
6. Lessons or operator notes (founder voice)

### 4. Pegasus Systems link

Top-level nav item, visually styled as an external link. Routes to `pegasussystems.com`. Opens in same tab (treat as a sister property, not a third-party link).

### 5. About (`/about`)

**Purpose:** The company beyond the work — values, vision, structure.

**Sections:**
1. Mission and vision
2. Brand architecture (the three-arm diagram from `01_BRAND_GUIDE/06_Brand_Architecture.md`, simplified)
3. Founder section (links to `/about/founder`)
4. Press / media (when there's something to put here)
5. Careers (when hiring)

### 6. Founder (`/about/founder`)

**Purpose:** The Apollo-specific page. Story, philosophy, contact.

**Sections:**
1. Short founder bio
2. The Pegasus story (how the company started)
3. Philosophy (from the Brand Bible, lightly adapted for narrative voice)
4. Press / appearances / podcasts (when applicable)
5. Direct contact

### 7. Contact (`/contact`)

**Purpose:** Make it easy to reach out. Reduce friction.

**Elements:**
- Contact form (Name / Email / Phone / Inquiry type / Message)
- Inquiry type select: "Capital partnership" / "Property opportunity (sell)" / "Vendor or contractor" / "Pegasus Systems demo" / "Other"
- Direct phone and email
- Calendar booking link (Apollo's calendar) — for vetted inquiries only; surface this contextually rather than as a top-level "book a call" element
- Office or service-area note (Bay Area + Sacramento focus)

---

## CTAs across the site

The site has **three CTA tiers**, used selectively:

| Tier | Visual treatment | Use case |
|---|---|---|
| Primary | Filled Copper button, Cream text | One per page maximum. The main action that page wants the user to take. |
| Secondary | Outlined Copper button, Copper text | Subordinate actions ("Explore Approach," "View Project") |
| Tertiary | Inline text link with Copper underline | Body-copy navigation |

**Per-page primary CTA recommendations:**
- Home: "Start a conversation" → /contact
- Approach: "See our projects" → /projects
- Project detail: "Discuss a similar deal" → /contact?type=property
- About: "Meet the founder" → /about/founder
- Founder: "Reach out directly" → mailto: or contact form
- Contact: form submit

---

## Footer (every page)

Three columns:

| Left | Center | Right |
|---|---|---|
| Pegasus Dreamscapes horizontal logo + tagline | Sitemap (Home / Approach / Projects / About / Contact / Pegasus Systems) | Contact: phone, email, optional address |

Below columns, full-width thin Copper rule, then small print:
```
© [Year] Pegasus Dreamscapes Corp. All rights reserved.
[Privacy Policy] [Terms of Use]
```

No social media icons in the footer unless Pegasus is actively maintaining those accounts. Dead social links signal abandonment.

---

## Page templates needed

| Template | Used by |
|---|---|
| `Home` | / |
| `Approach Hub` | /approach |
| `Approach Detail` | /approach/development, /approach/investments, /approach/systems |
| `Projects List` | /projects |
| `Project Detail` | /projects/[slug] |
| `About` | /about, /about/founder |
| `Contact` | /contact |
| `404` | catch-all |

Eight templates. Build all eight before launching any page in a sub-section, so structural consistency is preserved.

---

## SEO IA

Each page has a unique title, meta description, OG image, and structured data (where applicable). See `04_SEO_and_Metadata.md` (to be drafted in Phase 4 implementation).

Key URLs to claim and redirect:
- `pegasusdreamscapes.com` (canonical)
- `www.pegasusdreamscapes.com` → 301 to canonical
- `pegasus-dreamscapes.com` (hyphenated typo — purchase and 301)
- Any obvious typo variants worth defensive registration

---

## What's NOT on the site (intentional)

- Real-time deal listings (those live in Pegasus HQ / MarketFlow, not on the marketing site)
- Pricing pages (custom relationship pricing; not productized)
- Blog (until there's a strategic reason for one — empty blog with three posts from 2024 is worse than no blog)
- Testimonials carousel (when ready, integrate inline on Approach and Projects pages, not as a standalone "Testimonials" section)
- Newsletter signup form (until a newsletter exists)
- Live chat widget (operator-mature brand, not a SaaS widget)

---

*End of Sitemap & IA v1.0.*
