# 06_WEBSITE

The public-facing site for Pegasus Dreamscapes (parent brand). Pegasus Systems will eventually have its own product site at `pegasussystems.com`; that is tracked in `11_PEGASUS_SYSTEMS/`.

## Files

| File | Purpose |
|---|---|
| `01_Sitemap_and_IA.md` | Information architecture — every page, every link, every CTA |
| `02_Website_Copy_Deck.md` | Locked copy for every page and section |
| `03_Visual_Direction.md` | Hero treatments, photography direction, motion rules |
| `04_SEO_and_Metadata.md` | Page titles, meta descriptions, OG tags, structured data |

## Domain and tech (per Blueprint)

- **Domain:** `pegasusdreamscapes.com`
- **Tech stack:** Next.js + TypeScript (per Pegasus engineering standard)
- **Database:** Neon (per Blueprint — note this is a separate database from Pegasus HQ's Supabase)
- **Hosting:** Vercel (assumed; confirm)
- **Analytics:** TBD (recommend Plausible for privacy-friendly stack-fit)

## Open architectural item

Per Master Blueprint, the website (Neon DB) and Pegasus HQ (Supabase DB) are currently on separate stacks with separate auth systems. This means the website cannot yet log a visitor directly into Pegasus HQ. This is a known constraint flagged in the Blueprint; the Phase 1 brand kit treats them as separate properties and writes copy accordingly.

## Status

Phase 4 deliverable. Specs written; production pending.
