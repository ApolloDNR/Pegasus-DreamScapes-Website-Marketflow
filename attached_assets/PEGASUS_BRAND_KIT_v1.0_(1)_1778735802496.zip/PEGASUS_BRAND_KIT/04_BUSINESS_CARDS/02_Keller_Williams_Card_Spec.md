# Keller Williams Business Card — Specification
**Card:** Pure Agent (KW context only)
**Reference design:** Image 2 (KW templated dual-card layout)
**Status:** Locked design direction; copy and final files pending DRE confirmation

---

## Audience

Retail buyers and sellers. Listing presentations to traditional homeowners. KW office events. Agent-to-agent introductions at brokerages. First-time homebuyers at open houses.

Pegasus Dreamscapes does **not** appear on this card. That is intentional. In rooms where you are operating purely as a fiduciary agent, Pegasus is noise — it raises questions ("are you going to flip my house?") that distract from the transaction. The KW-only card protects the fiduciary relationship.

---

## Card front

### Layout
- **Background:** Cream `#D4CFC4` (warm, not pure white)
- **Top-left corner:** KW logo lockup ("kw" red mark + "KELLER WILLIAMS REALTY") per KW brand standards. **Use KW-issued lockup file. Do not retypeset.**
- **Right side, top-to-bottom angular accent:** KW black/red angled panel (per KW templated style — see Image 2 reference)
- **Center:**
  - **Name:** "PAOLO DURAN" in Playfair Display Bold, all caps, Midnight `#1A2332`, sized large (primary type element)
  - **Title:** "REALTOR®" in Inter Medium, all caps, tracking +20%, KW Red, smaller than name
  - Thin Copper rule beneath title block
  - **Brokerage line:** "KELLER WILLIAMS REALTY" in Inter Medium, all caps, Midnight
- **Lower block:**
  - Phone icon (KW Red, filled circle) + "Cell: 925-948-6566" in Inter Regular, Midnight
  - Email icon (KW Red, filled circle) + "Email: pduran@kw.com" in Inter Regular, Midnight

### Compliance copy (required, small)

Bottom edge of card front:
```
DRE License #_______ • Each Office Independently Owned and Operated
```

The DRE license number is a hard requirement under California Business and Professions Code §10140.6. **The card cannot print without it.**

---

## Card back

### Layout
- **Background:** Midnight `#1A2332` (the only dark element in the KW set — KW's official brand allows dark accents for premium tier)
- **Left side angular accent:** KW Red angled panel (mirroring the front layout)
- **Center top:** KW logo lockup ("kw" mark + "KELLER WILLIAMS REALTY") in white/cream + red, sized prominently
- **Below logo:** "PAOLO DURAN" in Playfair Display Bold, all caps, Cream
- **Tagline / mission line:** "Helping clients buy, sell, and invest with clarity and confidence." — Inter Italic, Cream at 80%
- Thin Copper rule beneath tagline
- **Bottom contact:**
  - Phone icon (KW Red) + "925-948-6566" in Inter Regular, Cream
  - Email icon (KW Red) + "pduran@kw.com" in Inter Regular, Cream
- **Bottom-right (small):** Equal Housing Opportunity logo (required — see `_COMPLIANCE/KW_Compliance_Requirements.md`)

---

## Copy lock

### Front
```
PAOLO DURAN
REALTOR®
KELLER WILLIAMS REALTY

Cell: 925-948-6566
Email: pduran@kw.com

DRE License #[NUMBER] • Each Office Independently Owned and Operated
```

### Back
```
PAOLO DURAN

Helping clients buy, sell, and invest
with clarity and confidence.

925-948-6566 | pduran@kw.com

[Equal Housing Logo]
```

---

## Contact information

| Field | Value | Notes |
|---|---|---|
| Name | Paolo Duran | Use legal name on KW card. KW compliance requires the license-registered name. |
| Title | REALTOR® | Trademark symbol required. Capitalize. |
| Brokerage | Keller Williams Realty | Per KW brand standards. Do not abbreviate to "KW Realty." |
| Phone | 925-948-6566 | Same number across all cards |
| Email | pduran@kw.com | KW-issued email is required for compliance on all agent communications. Do not use personal email here. |
| DRE License # | **PENDING — must insert before print** | Apollo to provide |

---

## Design constraints (KW compliance)

KW has formal brand and compliance rules for agent-issued business cards. The card spec above complies, but the print vendor must verify against current KW Brand Standards (these update periodically):

1. **KW logo:** Must be the official KW lockup. Cannot be modified, recolored, redrawn, or stylized.
2. **Realtor® designation:** Trademark symbol required (the REALTOR® mark belongs to NAR, not KW).
3. **DRE License Number:** Required on all California real estate business cards per state law. Must be legible (minimum 6pt).
4. **Brokerage disclosure:** "Keller Williams Realty" must appear in equal or greater prominence than the agent's name.
5. **Each Office Independently Owned and Operated:** Required disclosure on all KW-affiliated marketing.
6. **Equal Housing Opportunity:** Logo required on all real estate marketing materials.
7. **No co-branding without disclosure:** This card is single-brand (KW only). The Pegasus Dreamscapes brand explicitly does not appear, and that is the correct compliance posture.

---

## Print specifications

| Spec | Value |
|---|---|
| Dimensions | 3.5" × 2.0" |
| Stock | 18pt or 22pt premium matte |
| Color | CMYK (KW Red is process; check KW spec for exact CMYK build) |
| Coating | Matte both sides |
| Edge | Square |
| Bleed | 0.125" |
| Safe area | 0.125" inset |
| Quantity | 250 first run |

---

## Pre-print checklist

- [ ] DRE License Number obtained and inserted
- [ ] KW logo file confirmed against current KW Brand Standards
- [ ] KW Red CMYK values confirmed (per current KW spec sheet)
- [ ] Equal Housing logo placed
- [ ] "Each Office Independently Owned and Operated" copy present
- [ ] `pduran@kw.com` email confirmed active
- [ ] Vendor familiar with KW compliance (preferred: KW-approved vendor list)
- [ ] Physical proof reviewed before mass run

---

## Why Pegasus is absent from this card

Apollo is genuinely both a Pegasus founder and a KW agent. On the KW card, the absence of Pegasus is the operator move:

- **Fiduciary clarity:** A retail seller hiring a listing agent does not want to wonder if their agent is also planning to buy their house. This card removes that ambiguity.
- **KW office political safety:** KW agents who advertise outside ventures on KW materials sometimes face brokerage friction. The single-brand card is the safe baseline.
- **Compliance simplicity:** Single-brand cards have one set of disclosure requirements. Dual-brand introduces nuance.

For contexts where both identities are an asset (sophisticated investor-client overlap), use the Dual-Brand card (`03_Dual_Brand_Card_Spec.md`) — but never as a substitute for the pure KW card. Different rooms, different cards.

---

*End of Keller Williams Business Card Spec v1.0.*
