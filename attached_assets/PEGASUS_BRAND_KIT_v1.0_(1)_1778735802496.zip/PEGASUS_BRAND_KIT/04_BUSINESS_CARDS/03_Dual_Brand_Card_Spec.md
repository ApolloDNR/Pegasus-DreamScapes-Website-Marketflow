# Dual-Brand Business Card — Specification
**Card:** Pegasus Dreamscapes + Keller Williams (sophisticated overlap)
**Reference design:** Image 4 (preferred) or Image 3 / Option 2 (alternate)
**Status:** Locked design direction; copy and final files pending DRE confirmation

---

## Audience

The room where both identities are an asset, not a liability:

- Investor-clients who buy through MLS (they want a Realtor® who also operates)
- Agents who refer fix-and-flip leads (they want to know you have the operating muscle to close)
- Capital partners who appreciate that you also hold a license (regulatory comfort)
- KW office leadership when discussing your broader business
- Networking events where both real estate practice and operating company are relevant

This card is **not** a substitute for the pure KW card or the pure Pegasus card. It is the third tool. Different rooms, different cards.

---

## Hierarchy decision (locked)

**Pegasus dominant. KW affiliated.**

This reflects the truth: Apollo is a founder of an operating company who happens to also hold a license, not a KW agent with a side venture. The card's visual hierarchy must encode that reality.

- Pegasus Dreamscapes logo is sized 1.3–1.5x larger than the KW logo
- Pegasus Dreamscapes appears in the dominant visual position (right of center on the front, given the chevron flow)
- KW appears in the secondary position with full compliance treatment
- Apollo's title leads with "Founder, Pegasus Dreamscapes" before "Realtor®, Keller Williams"

This is the correct posture because:
1. The card's audience is sophisticated — they understand that owning a brokerage license while operating a development company is the higher-tier configuration
2. KW compliance allows agents to advertise their other professional roles as long as KW affiliation is correctly disclosed
3. The Pegasus brand is the brand Apollo controls; KW is the affiliation he holds

---

## Card front

### Layout (Image 4 reference)
- **Background:** Midnight `#1A2332` (top 70%) + Cream `#D4CFC4` strip (bottom 30%)
- **Top-left section (Midnight):** KW logo lockup ("kw" red mark + "KELLERWILLIAMS") in white/cream + red, sized to ~25% of card width
- **Vertical Copper rule** between KW and Pegasus sections (the brand-separation rule from Logo Usage Guide)
- **Top-right section (Midnight):** Pegasus Dreamscapes primary stacked logo, sized to ~40% of card width (visibly larger than KW per hierarchy lock)
- **Bottom strip (Cream):**
  - Left side: "PAOLO DURAN" in Playfair Display Bold, all caps, Midnight
  - Below name: "REALTOR® | FOUNDER" in Inter Medium, all caps, tracking +20%, Copper
  - Right side: Phone icon (Copper) + "925-948-6566" + Email icon (Copper) + "pduran@kw.com"

### Compliance copy (required, small, bottom edge of front in Cream strip)
```
DRE License #_______ • Each Office Independently Owned and Operated
```

---

## Card back

### Layout
- **Background:** Midnight `#1A2332` full bleed
- **Border:** Thin Copper rule, 0.05" inset from edge with notched corners
- **Center top:** Pegasus Dreamscapes primary stacked logo, sized to ~50% of card width
- **Below logo:** Tagline "DREAM IT. BUILD IT. LIVE IT." in Inter Medium, all caps, tracking +20%, Copper
- **Bottom-right corner (small):** Equal Housing Opportunity logo in Cream

The back is **Pegasus-only** — no KW elements. Reasoning: the back is the brand impression that lingers after the recipient pockets the card. Lead with Pegasus identity; KW is acknowledged on the front where compliance requires it.

---

## Copy lock

### Front
```
[KW Logo]  |  [Pegasus Dreamscapes Logo]

PAOLO DURAN
REALTOR® | FOUNDER

📞 925-948-6566   ✉️ pduran@kw.com

DRE License #[NUMBER] • Each Office Independently Owned and Operated
```

### Back
```
[Pegasus Dreamscapes Primary Stacked Logo]

DREAM IT. BUILD IT. LIVE IT.

[Equal Housing Logo]
```

---

## Contact information — the dual-email decision

**The dual card uses one email by design: `pduran@kw.com`.**

Rationale:
- All KW-related communications must route through the KW email per brokerage compliance
- Recipients of the dual card are most likely to want to engage Apollo on a transactional matter where the KW email is the correct routing
- A two-email card creates user friction ("which one do I use?") and dilutes the operator-confident voice
- For Pegasus-direct conversations (capital, contractor, principal-buyer), Apollo hands over the **Pegasus card**, not the dual card

If a dual card with both emails is ever needed (rare), use this format:
```
For real estate representation: pduran@kw.com
For Pegasus Dreamscapes: apollo@pegasusdreamscapes.com
```
But the default lock is single-email (KW), with the Pegasus card carrying the Pegasus email.

| Field | Value | Notes |
|---|---|---|
| Name | Paolo Duran | Legal name required for KW compliance |
| Title | Realtor® \| Founder | Realtor® first to satisfy KW prominence requirement; Founder second to anchor Pegasus identity |
| Companies | Keller Williams Realty (front-left) + Pegasus Dreamscapes (front-right + entire back) | Per hierarchy lock |
| Phone | 925-948-6566 | Same number across all cards |
| Email | pduran@kw.com | Single email per "the dual-email decision" above |
| DRE License # | **PENDING — must insert before print** | Apollo to provide |

---

## Compliance posture

The dual-brand card is the most regulatory-sensitive of the three because it puts both identities on the same surface. Required:

1. **KW compliance basics:** DRE license number, "Each Office Independently Owned and Operated," REALTOR® designation, KW-issued email, KW logo per brand standards
2. **Equal Housing logo:** Required (real estate marketing material)
3. **No misrepresentation:** Pegasus Dreamscapes must not appear to be a brokerage. The card cannot read as if Pegasus and KW are the same entity. The vertical Copper rule between the two logos is the visual separator that prevents this confusion.
4. **No commingling of services:** The card cannot offer Pegasus services as if they are KW services, or vice versa. Title structure ("Realtor® | Founder") implies separate roles, which is correct.
5. **KW office approval (optional but recommended):** Some KW market centers require pre-approval for any marketing material that includes the KW logo alongside another brand. Confirm with the local KW market center before printing.

---

## Print specifications

| Spec | Value |
|---|---|
| Dimensions | 3.5" × 2.0" |
| Stock | 22pt premium matte |
| Color | CMYK + Pantone 7572 C (copper) |
| Foil | Optional copper foil on the Pegasus wordmark (back) for premium tier |
| Coating | Soft-touch matte on Midnight; uncoated on Cream strip (for write-on capability) |
| Edge | Square |
| Bleed | 0.125" |
| Safe area | 0.125" inset |
| Quantity | 250 first run |

---

## Pre-print checklist

- [ ] DRE License Number obtained and inserted
- [ ] KW market center confirms approval (recommended)
- [ ] KW logo file confirmed against current KW Brand Standards
- [ ] Pegasus Dreamscapes logo file from `02_LOGOS/Pegasus_Dreamscapes/` (locked variant)
- [ ] Equal Housing logo placed on back
- [ ] Vertical Copper rule between KW and Pegasus logos correctly rendered (separation, not lockup)
- [ ] Pegasus logo confirmed visually larger than KW logo (hierarchy lock)
- [ ] `pduran@kw.com` email confirmed active
- [ ] Physical proof reviewed before mass run

---

*End of Dual-Brand Business Card Spec v1.0.*
