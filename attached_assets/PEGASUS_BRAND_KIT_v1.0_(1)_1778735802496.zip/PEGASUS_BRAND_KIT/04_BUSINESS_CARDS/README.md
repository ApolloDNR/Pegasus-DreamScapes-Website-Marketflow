# 04_BUSINESS_CARDS

Three card systems. Each one serves a distinct audience. Apollo carries all three.

## The doctrine

Different rooms get different cards. This is not a design preference — it is operator behavior. Trying to make one card serve all audiences dilutes every audience.

| Card | Audience | Reference design |
|---|---|---|
| Pegasus Dreamscapes (founder/principal) | Capital partners, contractors, distressed sellers, networking as developer | Image 1 from card exploration |
| Keller Williams (pure agent) | Retail buyers/sellers, KW office events, listing presentations, agent-to-agent at brokerages | Image 2 from card exploration |
| Dual-brand (sophisticated overlap) | Investor-clients buying through MLS, agents who refer fix-and-flip leads, contexts where both identities are assets | Image 4 / Image 3 (option 2) from card exploration |

## Files in this folder

| File | Purpose |
|---|---|
| `01_Pegasus_Dreamscapes_Card_Spec.md` | Front + back layout, copy, contact info, print specs |
| `02_Keller_Williams_Card_Spec.md` | KW-compliant layout, broker affiliation, DRE placeholder, Equal Housing requirement |
| `03_Dual_Brand_Card_Spec.md` | Hierarchy rules, dual-email approach, compliance disclaimer |

## Production targets

- Stock: 18pt or 22pt thick cardstock, soft-touch matte finish
- Premium spec: copper foil stamp on the wordmark accent (Pegasus card only)
- Edge treatment: square edges (Pegasus card); square edges (KW card per KW templates); square edges (Dual card)
- Print spec: CMYK + Pantone 7572 C for copper; vendor must show physical proof before mass run
- Quantity per first run: 250 of each (3 boxes total)

## Hand-off vendor

Local Bay Area print vendor preferred (Apollo can drop off and inspect). Backup: Moo or Vistaprint Premium for non-foil orders. Foil orders must go through a specialty vendor — request three quotes before locking.
