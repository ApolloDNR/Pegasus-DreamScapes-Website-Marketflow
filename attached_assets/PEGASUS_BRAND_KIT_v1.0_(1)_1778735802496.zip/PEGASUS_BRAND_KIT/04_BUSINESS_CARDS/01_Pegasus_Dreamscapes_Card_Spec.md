# Pegasus Dreamscapes Business Card — Specification
**Card:** Founder / Principal
**Reference design:** Image 1 (two-card set: ceremonial front + functional contact back)
**Status:** Locked design direction; copy and final files pending

---

## Audience

Capital partners. Contractors. Distressed sellers. Real estate operators. Founders. Anyone who needs to know that Apollo is the principal at Pegasus Dreamscapes — not an agent, not a broker, not a salesperson.

KW does **not** appear on this card. That is intentional. In rooms where the Pegasus identity matters, KW affiliation is irrelevant noise.

---

## Card 1 (Ceremonial / Brand)

### Layout
- **Background:** Midnight `#1A2332`
- **Border:** Thin Copper rule, 0.05" inset from card edge, with notched corners (architectural detail — see reference image)
- **Center mark:** Pegasus Dreamscapes primary stacked logo, centered both axes, sized to ~60% of card width
- **Below logo:** Descriptor line "REAL ESTATE DEVELOPMENT" in Inter Medium, all caps, tracking +20%, Cream `#D4CFC4`
- **Bottom-center accent:** Small copper diamond (the standard brand accent)
- **No text other than the wordmark and descriptor**

### Print spec
- Copper foil stamp on the "DREAMSCAPES" line and the bottom diamond — premium tier
- Soft-touch matte coating on the Midnight surface
- Optional embossed wordmark for ultra-premium tier

---

## Card 2 (Functional / Contact)

### Layout
- **Background:** Midnight `#1A2332`
- **Left chevron accent:** Subtle navy chevron pointing right (echoes the wing motif geometrically — see reference image)
- **Left side (within chevron):** Pegasus Dreamscapes icon-only logo, sized to ~40% of card height, vertically centered
- **Vertical divider:** Thin Copper rule between left chevron section and right contact section
- **Right side, top block:**
  - **Name:** "APOLLO DURAN" in Playfair Display Bold, all caps, Cream `#D4CFC4`, sized large (primary type element)
  - **Title:** "FOUNDER" in Inter Medium, all caps, tracking +20%, Copper `#C87A3A`, smaller than name
- **Thin copper rule beneath title block**
- **Right side, middle block:**
  - "PEGASUS DREAMSCAPES" in Inter Bold, all caps, Cream
  - "DEVELOPMENT & INVESTMENTS" in Inter Regular, all caps, tracking +15%, Cream at 80%
- **Right side, lower block:**
  - Tagline: "DREAM IT. BUILD IT. LIVE IT." in Inter Medium, all caps, tracking +20%, Copper, sized small
  - Phone icon (copper, outlined) + phone number in Inter Medium, Cream

### Copy lock

```
APOLLO DURAN
FOUNDER

PEGASUS DREAMSCAPES
DEVELOPMENT & INVESTMENTS

DREAM IT. BUILD IT. LIVE IT.
☎ 925-948-6566
```

### Contact information

| Field | Value | Notes |
|---|---|---|
| Name | Apollo Duran | Use Apollo (preferred) on Pegasus card; legal "Paolo" reserved for legal/contractual surfaces |
| Title | Founder | Not "Founder & CEO." Not "Founder, Visionary, Operator." Founder. |
| Phone | 925-948-6566 | Lock confirmed |
| Email | `apollo@pegasusdreamscapes.com` | **Pending domain creation. Do not print until live.** Do not fall back to apollosynd@gmail.com. |
| Website | `pegasusdreamscapes.com` | Pending lock; print without URL until website lives at brand domain |

### Optional QR code

Bottom-right corner, small (0.4" square), one-color Copper on Midnight. Links to `pegasusdreamscapes.com/apollo` (founder vCard download). Add only when the website is live and the vCard endpoint is built.

---

## Print specifications

| Spec | Value |
|---|---|
| Dimensions | 3.5" × 2.0" (US standard) |
| Stock | 22pt soft-touch matte |
| Color | CMYK + Pantone 7572 C (copper) |
| Foil | Copper foil stamp on "DREAMSCAPES" line (Card 1) and on Apollo's name (Card 2) for premium tier; printed copper acceptable for first run |
| Coating | Soft-touch matte on Midnight |
| Edge | Square (no rounded corners) |
| Bleed | 0.125" full bleed |
| Safe area | 0.125" inset from trim line |
| Quantity | 250 first run |

---

## Pre-print checklist

- [ ] `apollo@pegasusdreamscapes.com` email domain is live and tested
- [ ] Website URL decided (print without URL if not live)
- [ ] Designer delivers print-ready PDF with embedded fonts and outlined paths
- [ ] Vendor confirms Pantone 7572 C availability
- [ ] Physical proof reviewed and approved by Apollo before mass run
- [ ] Backup plain-print version (no foil) on file in case foil vendor falls through

---

## Wallet protocol

Card 1 (ceremonial) and Card 2 (functional) are produced as **two separate cards**, not as front/back of one card. Apollo carries both — leads with Card 1 in introductions ("Apollo with Pegasus Dreamscapes"), follows with Card 2 when contact details are exchanged. This is the operator move: separate the brand presentation from the contact handoff.

This is unconventional. Most cards merge the two functions. The doctrine choice here is to elevate the brand presentation above standard business-card behavior — appropriate for a founder operating in capital and operator rooms.

If a single-card variant is needed (constraint, cost, simplicity), use Card 2 only. Card 1 is the upgrade tier.

---

*End of Pegasus Dreamscapes Business Card Spec v1.0.*
