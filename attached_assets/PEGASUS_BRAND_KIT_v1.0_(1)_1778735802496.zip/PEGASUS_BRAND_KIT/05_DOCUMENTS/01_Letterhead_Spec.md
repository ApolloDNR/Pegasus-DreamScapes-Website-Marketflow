# Letterhead — Specification
**Pegasus Dreamscapes**
Version 1.0

---

## Use case

Formal company correspondence: contracts, offer letters, capital-raise memos, partnership agreements, formal proposals, board communications.

Letterhead is **not** for routine email (use email signature). Letterhead is for documents that print or render as standalone PDFs.

---

## Page specifications

- **Size:** US Letter (8.5" × 11")
- **Margins:** 1.0" top, 1.0" bottom, 0.875" left, 0.875" right
- **Background:** Cream `#D4CFC4` for top header band (1.25" tall) + white body for content
- **Body font:** Inter Regular, 11pt, line height 1.5

---

## Header zone (top of page)

- **Background band:** Cream `#D4CFC4`, full-bleed, 1.25" tall
- **Left side:** Pegasus Dreamscapes horizontal logo, sized to ~1" tall, vertically centered in the band, with 0.75" left margin
- **Right side (vertically centered, right-aligned):** Three-line block in Inter Regular 9pt, Midnight `#1A2332`:
  ```
  Pegasus Dreamscapes Corp
  [Mailing Address Line 1]
  [Mailing Address Line 2 / City, State Zip]
  ```
- **Below header band:** Thin Copper rule (0.5pt) full-width

---

## Body zone

- White background
- Standard letter content: date, recipient address block, salutation, body, signature block, closing
- Body type: Inter Regular 11pt, Midnight, line height 1.5
- Paragraph indent: none (block-style paragraphs with 12pt space after)
- Headings (if used): Inter Bold 13pt, Midnight, all caps, tracking +10%

---

## Signature block

```
[3 line breaks for handwritten signature]

Apollo Duran
Founder
Pegasus Dreamscapes Corp
```

If the letter is signed by another team member, follow the same pattern with their name and title.

---

## Footer zone (bottom of page)

- **Thin Copper rule** (0.5pt) full-width, 0.5" above bottom edge
- **Below rule:** Three-column footer in Inter Regular 8pt, Midnight at 70%:

| Left column | Center column | Right column |
|---|---|---|
| Phone: 925-948-6566 | apollo@pegasusdreamscapes.com | pegasusdreamscapes.com |

- **Below footer columns (small, centered, 7pt):**
  ```
  Pegasus Dreamscapes Corp • California S-Corporation
  ```

---

## Variant: KW-affiliated letterhead

For letters Apollo writes in his Realtor® capacity (offer letters to sellers, listing presentations, KW-routed correspondence), use a **separate KW letterhead** that follows KW Brand Standards. Do **not** modify the Pegasus letterhead to add KW elements — that creates compliance ambiguity.

The KW letterhead specification is sourced from KW Market Center directly (KW provides agent letterhead templates). This vault tracks that the spec exists; the file itself is owned by KW.

---

## Variant: Pegasus Systems letterhead

When Pegasus Systems sends formal correspondence (SaaS contracts, enterprise customer agreements), use a **separate letterhead** with the Pegasus Systems horizontal logo in place of the Pegasus Dreamscapes logo, and update the footer:

```
hello@pegasussystems.com  •  pegasussystems.com
Pegasus Systems is an operating company of Pegasus Dreamscapes
```

Pending Pegasus Systems wordmark lock (Phase 2).

---

## File outputs

Locked design produces:
- `pegasus-dreamscapes_letterhead_master.indd` (or .fig)
- `pegasus-dreamscapes_letterhead.docx` (editable team template)
- `pegasus-dreamscapes_letterhead.pdf` (blank letterhead PDF for use in PDF editors)
- `pegasus-dreamscapes_letterhead_print-ready.pdf` (with crops + bleed for print vendors)

---

## Pre-lock checklist

- [ ] Mailing address confirmed (PO Box vs. street address — recommend PO Box for founder-stage privacy)
- [ ] `apollo@pegasusdreamscapes.com` domain live
- [ ] Website live or omit URL until live
- [ ] DOCX template tested across Word (Win/Mac), Google Docs, and Pages

---

*End of Letterhead Spec v1.0.*
