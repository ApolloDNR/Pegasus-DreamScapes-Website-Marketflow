# Company One-Pager — Specification
**Pegasus Dreamscapes**
Version 1.0

---

## Use case

The single document Apollo hands a new contact at the end of a meeting when they ask "what does Pegasus actually do?" One page. Both sides if needed. Designed to be skimmed in 60 seconds and re-read in 4 minutes.

Three audiences, three variants:
- **Investor variant** — for capital partners, lenders, family offices
- **Partner variant** — for contractors, vendors, agents, brokerages, referral sources
- **Operator variant** — for sophisticated real estate operators evaluating Pegasus Systems

The visual template is shared. The copy varies per audience.

---

## Page specifications

- **Size:** US Letter (8.5" × 11"), portrait
- **Sides:** Single-sided (front-only) is the default. Two-sided for the Investor variant when financial detail justifies it.
- **Margins:** 0.5" all sides (tight; the page is a poster, not a letter)
- **Background:** Midnight `#1A2332` full bleed (this is a marketing surface; dark mode doctrine applies)

---

## Layout zones

```
┌───────────────────────────────────────────┐
│  [Logo + Tagline]                         │  ← Hero band (1.5" tall)
│                                           │
├───────────────────────────────────────────┤
│  HEADLINE (Playfair, large)               │  ← Headline band (1.0" tall)
│  Sub-headline (Inter, smaller)            │
├───────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐         │  ← Two-column body (5.0" tall)
│  │ Pillar 1    │  │ Pillar 2    │         │
│  │ - Body copy │  │ - Body copy │         │
│  │             │  │             │         │
│  └─────────────┘  └─────────────┘         │
│  ┌─────────────┐  ┌─────────────┐         │
│  │ Pillar 3    │  │ Pillar 4    │         │
│  │ - Body copy │  │ - Body copy │         │
│  └─────────────┘  └─────────────┘         │
├───────────────────────────────────────────┤
│  PROOF / TRACTION / NUMBERS               │  ← Proof band (1.5" tall)
├───────────────────────────────────────────┤
│  Contact + CTA                            │  ← Footer band (1.0" tall)
└───────────────────────────────────────────┘
```

---

## Hero band

- Pegasus Dreamscapes horizontal logo, left-aligned, 0.75" tall
- Tagline right-aligned: "DREAM IT. BUILD IT. LIVE IT." in Inter Medium, all caps, tracking +20%, Copper

---

## Headline band

- **Headline** (Playfair Display Black, 32pt, Cream): one sentence that defines the company. Variant-specific.
- **Sub-headline** (Inter Regular, 14pt, Cream at 80%, italic): one sentence that defines the audience-specific value.

### Variant copy

**Investor variant:**
> A vertically integrated real estate operator building generational wealth through disciplined acquisition, development, and software-powered execution.
>
> *For capital partners seeking risk-adjusted returns from an operator that owns its operating system.*

**Partner variant:**
> A vertically integrated real estate operating company building communities ground-up across the Bay Area, Sacramento, and beyond.
>
> *For contractors, vendors, agents, and referral partners who value scope clarity, on-time payment, and repeat business.*

**Operator variant:**
> The operating infrastructure for disciplined real estate execution — built by operators, for operators.
>
> *For real estate principals who refuse to run their business out of spreadsheets, sticky notes, and email threads.*

---

## Body — Four pillars

Each pillar is a 2"×2.5" content block. Headline (Playfair Display Bold, 16pt, Cream) + 3–4 line description (Inter Regular, 11pt, Cream at 80%).

### Investor variant pillars

1. **Vertical Integration**
   We acquire, develop, and operate. No middlemen between vision and execution. Margins are captured, not surrendered.

2. **Proprietary Software**
   Pegasus Systems — our operating infrastructure — runs every deal end-to-end. Operators who own their systems own their margins.

3. **Disciplined Doctrine**
   Every deal is documented as a permanent record. Every strategy is approved before execution. Every dollar is reconciled to a ledger.

4. **Bay Area + Sacramento Focus**
   We operate where we can drive the inspection, walk the jobsite, and close the deal in person. Geography is a discipline, not a constraint.

### Partner variant pillars

1. **Scope Clarity**
   Every project ships with a written scope, a payment schedule, and a defined inspection trigger. No surprises.

2. **On-Time Payment**
   Milestone payments release within 48 hours of inspection pass. Our reputation is the cash flow we hold ourselves to.

3. **Repeat Volume**
   We're building a deal pipeline, not running one-offs. Partners who deliver get the next project.

4. **Operator-Grade Communication**
   Project updates routed through Pegasus HQ. Single source of truth. No "didn't see your email" excuses.

### Operator variant pillars

1. **Pegasus HQ — The Command Core**
   Every deal becomes a War Room from day 1. Strategy approval generates tasks, documents, milestones, and department activation atomically.

2. **BuildForge — Construction Execution**
   Project workflows, milestone tracking, contractor coordination — designed by an operator, not an agency.

3. **CapStack — Capital Structure with Clarity**
   From ledger to Stripe Connect to embedded lending. The capital infrastructure operators have been waiting for.

4. **Peggy — Intelligence at Every Step**
   AI advisor inside the operating system. Recommends. Flags. Never writes without approval.

---

## Proof band

A horizontal band with three "proof tiles" — operational metrics that demonstrate traction. Each tile: large number (Playfair Display Black, 36pt, Copper) + label below (Inter Medium, 11pt, all caps, Cream at 80%).

### Investor variant proof
- "$1.4M+" Deployed Capital (or current actual)
- "2" Completed Deals
- "14% Target IRR" Project Returns

(Numbers must be true. Update before each printing.)

### Partner variant proof
- "100%" On-Time Payment Rate
- "Bay Area + Sacramento" Active Markets
- "Zero" Open Disputes

### Operator variant proof
- "Live" Pegasus HQ Status
- "5 Products" Pegasus Systems Fleet
- "Operator-Built" Founding Customer

---

## Footer band

- **Left:** "Apollo Duran, Founder" + phone + email (Inter Regular, 11pt, Cream)
- **Right:** Single CTA in a Copper-outlined button shape (Playfair Display Bold, 14pt, Cream): variant-specific
  - Investor: "Request the deck"
  - Partner: "Open a project"
  - Operator: "See Pegasus HQ"
- **Below CTA (small):** `pegasusdreamscapes.com` in Inter Regular, 10pt, Copper

---

## Print specifications

| Spec | Value |
|---|---|
| Dimensions | 8.5" × 11" |
| Stock | 100lb gloss cover (premium feel) or 80lb matte text (lighter handout) |
| Color | CMYK + Pantone 7572 C (copper) |
| Coating | Soft-touch matte recommended |
| Bleed | 0.125" full bleed |
| Quantity | 100 of each variant for first run |

For digital distribution: PDF export with embedded fonts at 300 DPI for printable quality, plus a 144 DPI version for screen.

---

## Pre-lock checklist

- [ ] All three variants drafted with current accurate numbers
- [ ] Apollo approval per variant
- [ ] Brand fonts embedded in PDF export
- [ ] Print proof reviewed
- [ ] Numbers update protocol established (quarterly review of "proof band" stats)

---

*End of One-Pager Spec v1.0.*
