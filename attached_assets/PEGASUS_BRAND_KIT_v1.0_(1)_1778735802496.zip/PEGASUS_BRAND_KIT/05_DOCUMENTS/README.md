# 05_DOCUMENTS

The internal and external document templates that carry the brand into business operations.

## Files

| File | Purpose |
|---|---|
| `01_Letterhead_Spec.md` | Letterhead layout, copy zones, print + digital |
| `02_Email_Signatures.md` | Three signature variants (Pegasus / KW / Dual) |
| `03_One_Pager_Spec.md` | Company overview one-pager — investor and partner version |
| `04_Pitch_Deck_Outline.md` | Generic pitch deck structure for capital and partnership conversations |
| `05_Investor_Deck_Outline.md` | Capital-raise specific deck structure |
| `06_Proposal_and_Invoice_Spec.md` | Service proposal, scope of work, invoice templates |

## Production format

All documents are designed once in **Figma or InDesign** as locked templates, then exported to:
- **DOCX** (editable team templates)
- **PDF** (vendor- and client-facing)
- **Google Docs** (collaborative editing)

The locked design in Figma/InDesign is the source of truth. Editable formats are downstream artifacts.

## Default fonts in templates

Per `01_BRAND_GUIDE/03_Typography_System.md`:
- Marketing-grade documents (one-pagers, decks): Playfair Display (headlines) + Inter (body)
- Operational documents (letterhead, proposals, invoices): Inter throughout (functional context)

DOCX fallback (for vendor compatibility): **Arial body** (Blueprint preference for reliable rendering); replace Playfair with Georgia for headings if Playfair embedding fails.

## Compliance overlay

Documents that touch real estate transactions (proposals to sellers, listing materials, anything passing through KW) require additional compliance treatment. See `_COMPLIANCE/KW_Compliance_Requirements.md` and add the appropriate footer copy.
