# Email Signatures — Specification
**Pegasus Dreamscapes**
Version 1.0

---

## The three signature variants

| Variant | Email account | When to use |
|---|---|---|
| **Pegasus** | `apollo@pegasusdreamscapes.com` | All Pegasus Dreamscapes business — investor relations, contractors, vendors, partners, principal-buyer outreach, Pegasus Systems |
| **KW** | `pduran@kw.com` | All Realtor® work — buyer/seller representation, listing presentations, KW office communications, MLS-routed conversations |
| **Dual** | `pduran@kw.com` (KW account, dual-brand signature) | Sophisticated overlap conversations where both identities are an asset — same audience as the dual-brand business card |

Use the email account that matches the conversation's compliance routing. The signature follows the account, not the topic.

---

## Variant 1: Pegasus signature

```
Apollo Duran
Founder, Pegasus Dreamscapes

925-948-6566
apollo@pegasusdreamscapes.com
pegasusdreamscapes.com
```

### Visual treatment (HTML)
- Name: Inter Bold 14px, Midnight `#1A2332`
- Title line: Inter Regular 13px, Midnight at 80%
- One blank line gap
- Phone, email, website: Inter Regular 12px, Midnight at 70%
- Email and website are hyperlinks, color Copper `#C87A3A`, no underline
- **Optional:** Pegasus Dreamscapes horizontal logo at 32px tall, above the name. Use logo only if it's a critical first impression (initial outreach to a capital partner). For routine threads, text-only is cleaner.

### What's not in this signature
- No quote
- No "Sent from my iPhone"
- No social media icons (LinkedIn, Instagram, etc.)
- No mailing address (founder-stage privacy)
- No emoji
- No tagline ("Dream it. Build it. Live it." is for marketing, not signatures)
- No legal disclaimer (this is operator correspondence, not a law firm)

---

## Variant 2: KW signature

KW provides templated agent signatures via KW Command. **Use the KW-templated signature for all KW correspondence.** Do not improvise. KW signatures include required compliance elements (DRE number, Equal Housing logo, brokerage disclosure) that the templated version handles automatically.

If templating from scratch, the required elements:

```
Paolo Duran, REALTOR®
Keller Williams Realty
DRE #[NUMBER]

925-948-6566
pduran@kw.com

[KW Logo]  [Equal Housing Logo]
Each Office Independently Owned and Operated
```

### Visual treatment
- Per KW Brand Standards (do not modify)
- KW Red on white background
- Times or Arial typography (per KW templates) — does **not** use Pegasus brand fonts
- KW logo and Equal Housing logo at 32px

---

## Variant 3: Dual signature

For the rare context where both identities should appear in a single signature (most overlap is handled by using the right card and the right email account; the dual signature is for ongoing email threads with sophisticated audiences who already know both identities).

```
Paolo Duran
Realtor® at Keller Williams Realty | Founder of Pegasus Dreamscapes

925-948-6566
pduran@kw.com  •  apollo@pegasusdreamscapes.com

DRE #[NUMBER] • Each Office Independently Owned and Operated
```

### Visual treatment
- Name: Inter Bold 14px, Midnight
- Title line: Inter Regular 13px, Midnight at 80%, with " | " separator (vertical bar)
- Compliance line: Inter Regular 10px, Midnight at 60% (small but present)
- Both emails listed; recipient picks the appropriate channel for their request
- No logos (visual complexity in a signature undermines the operator-mature voice; dual logos in a signature read as overdoing it)

### Compliance note
The dual signature must include the DRE number and "Each Office Independently Owned and Operated" because it includes the KW affiliation. Without those, the signature violates KW compliance.

---

## Implementation

### Gmail / Google Workspace
- Apollo creates each signature in his email account settings
- Pegasus signature is the default for `apollo@pegasusdreamscapes.com`
- KW signature is the default for `pduran@kw.com`
- Dual signature is created in `pduran@kw.com` and selected manually for relevant threads

### Apple Mail / Outlook
- Same approach — multiple signatures per account, default plus manual selection

### Mobile
- Mobile email apps support signatures but typically lose HTML formatting. Configure mobile signatures as **plain text version** of each signature above (no logos, no styled hyperlinks).

---

## Signature for team members (future)

When Pegasus Dreamscapes hires team members, each team member gets the Pegasus signature template with their name and title substituted. Title format follows the same discipline:

- "Project Manager" not "Project Management Lead"
- "Construction Coordinator" not "VP of Construction Operations"
- "Capital Operations" not "Director of Capital Operations & Investor Relations"

Inflated titles signal startup vanity. Operator-mature titles signal the discipline of the brand.

When Pegasus Systems hires (separate brand), they receive Pegasus Systems signatures with `@pegasussystems.com` emails.

---

## Pre-lock checklist

- [ ] `apollo@pegasusdreamscapes.com` account live and configured
- [ ] HTML signature tested in Gmail, Outlook, Apple Mail (rendering varies)
- [ ] Mobile plain-text version configured
- [ ] KW signature uses the KW-issued template (not improvised)
- [ ] DRE number obtained and inserted in KW + Dual signatures
- [ ] All signatures rendered and screenshotted to vault before deployment

---

*End of Email Signatures Spec v1.0.*
