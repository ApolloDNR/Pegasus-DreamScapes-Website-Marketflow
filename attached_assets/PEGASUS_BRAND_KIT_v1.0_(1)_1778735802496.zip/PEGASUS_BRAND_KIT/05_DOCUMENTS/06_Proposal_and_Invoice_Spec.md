# Proposals, Scopes of Work, and Invoices — Specification
**Pegasus Dreamscapes**
Version 1.0

---

## Documents covered

| Document | Issued to | Purpose |
|---|---|---|
| Service Proposal | Sellers, partners, prospects | Pre-engagement: what Pegasus is offering, what it will cost, what happens next |
| Scope of Work (SOW) | Contractors, vendors | Pre-execution: exact scope, payment milestones, timeline, change-order process |
| Invoice | Customers, contractors (received) | Post-delivery: what was delivered, what is owed, payment terms |
| Estimate | Prospective customers | Quick pre-proposal: rough numbers for early conversations |
| Receipt | Anyone | Post-payment: confirmation of payment received |

All documents share the same letterhead and footer (per `01_Letterhead_Spec.md`) but vary in body structure.

---

## Document 1 — Service Proposal

### Use case
Pegasus is offering a service — buying a property direct, managing a renovation, providing development services. The proposal is the formal handshake before the contract.

### Structure

**Page 1 — Cover**
- Letterhead header
- "PROPOSAL" in Playfair Display Bold, 28pt, Copper, all caps
- Recipient name + property/project reference
- Date prepared and proposal validity period (e.g., "Valid through November 15, 2025")
- Pegasus contact (Apollo + email + phone)

**Page 2 — Executive summary**
- One paragraph: what is being proposed, the headline number, the timeline
- Designed so the recipient knows the entire deal after reading this page

**Page 3 — Scope**
- Numbered list of every service or deliverable included
- Numbered list of explicit exclusions (what is NOT included — equally important)
- Assumptions stated plainly

**Page 4 — Pricing**
- Pricing table with line items and totals
- Payment schedule (deposit, milestones, final)
- Payment methods accepted

**Page 5 — Timeline**
- Calendar or milestone table showing the project's progression
- Key inspection or approval points

**Page 6 — Terms and next steps**
- Acceptance language ("Signed acceptance below constitutes engagement")
- Signature line for both parties
- Next-step instructions

### Format
- US Letter portrait, white body with Cream accent strips and Copper rule separators
- Body in Inter Regular 11pt
- Headings in Playfair Display Bold 16pt for major sections, Inter Bold 13pt all-caps for sub-sections
- Page numbers bottom-right ("Page X of Y")

---

## Document 2 — Scope of Work (SOW)

### Use case
Pegasus is hiring a contractor or vendor for a defined scope. The SOW is the operational contract: what will be built, when, for how much, and what triggers payment release.

### Structure

**Section 1 — Project header**
- Project name + property address
- Vendor name + contact
- Pegasus project lead + contact
- SOW version + date

**Section 2 — Scope (the most important section)**
- Numbered itemized list of every task included
- Materials specifications (where Pegasus is providing materials vs. vendor sourcing)
- Quality standards / finish standards referenced
- Inclusions/exclusions stated explicitly

**Section 3 — Schedule**
- Start date, completion date
- Intermediate milestones (when applicable)
- Liquidated damages clause (when applicable)

**Section 4 — Payment milestones**
- Each milestone: description, dollar amount, inspection trigger, release timeline
- Standard release: payment released within 48 hours of inspection pass
- Total contract amount stated clearly at the top of the section

**Section 5 — Change order process**
- All scope changes must be in writing
- All change orders priced before work begins
- Signed change-order form attached as exhibit

**Section 6 — Required documentation**
- Insurance certificates required
- Lien releases required at each payment milestone
- Final lien release required for retention release

**Section 7 — Signatures**
- Two-signature block (Pegasus + Vendor) with date

### Format
- US Letter portrait
- Functional design — fewer marketing flourishes than a Proposal, more emphasis on legibility and reference clarity
- Tables for milestones and pricing
- Page numbers required

---

## Document 3 — Invoice

### Use case
Pegasus has delivered work and is collecting payment. Invoice is the formal request for payment.

### Structure

**Header zone**
- Letterhead
- "INVOICE" in Playfair Display Bold, 24pt, Copper
- Invoice number (sequential — see numbering protocol below)
- Invoice date + payment due date
- "Bill to" recipient block

**Body zone**
- Line items: description, quantity, unit price, line total
- Subtotal
- Tax (if applicable)
- Total due in large, prominent type (Playfair Display Bold, 28pt, Midnight)
- Payment instructions: bank wire details, ACH, check payable to, online payment link

**Footer zone**
- Payment terms: "Net 15" or "Due upon receipt" or as agreed in proposal
- Late fee policy
- Contact for billing questions
- Letterhead-standard footer

### Invoice numbering protocol

Format: `INV-[YYYY]-[####]`
- Year: four-digit year
- Sequence: four-digit sequential per year, starting at 0001
- Example: `INV-2025-0014`

Sequential numbering is a legal requirement in many jurisdictions and a basic operator discipline. No skipped numbers; if an invoice is voided, the void is documented and the number stays retired.

---

## Document 4 — Estimate

### Use case
Pre-proposal: a rough number Pegasus shares with a prospect early in the conversation, before a formal Proposal is justified.

### Structure
- One page
- Letterhead
- "ESTIMATE" in Playfair Display Bold, 24pt, Copper
- Property/project reference
- Range or single number with clear "this is a rough estimate" disclaimer
- "This estimate is non-binding. Final pricing provided in formal Proposal." disclaimer
- Validity period (typically 30 days)
- Contact for next step

Estimates are intentionally light. They are conversation tools, not contracts.

---

## Document 5 — Receipt

### Use case
Pegasus has received payment and is confirming receipt.

### Structure
- One page or half-page
- Letterhead
- "PAYMENT RECEIPT" in Playfair Display Bold, 24pt, Copper
- Receipt number (separate sequence: `RCT-YYYY-####`)
- Date received
- Payer name
- Amount received
- Payment method
- Reference (invoice number being paid)
- Balance remaining (if any)
- Signature or "auto-generated by Pegasus HQ" footer

---

## Production notes

All five documents should eventually be **generated automatically by Pegasus HQ** (per Blueprint — strategy approval generates documents atomically). The vault templates are the manual fallback and the design source for the automated generation.

Until HQ document generation is live, Apollo or team members fill in the Word/Google Docs templates manually.

---

## File outputs

- `proposal_template.docx`
- `proposal_template.pdf` (blank)
- `sow_template.docx`
- `invoice_template.docx`
- `estimate_template.docx`
- `receipt_template.docx`

Each also exists as a Figma source file for design updates.

---

## Pre-lock checklist

- [ ] All five document templates designed
- [ ] Invoice numbering protocol established and documented in Pegasus HQ schema
- [ ] Tabular figures (`tnum`) enabled on all financial tables
- [ ] DOCX templates tested in Word and Google Docs
- [ ] Legal review of SOW boilerplate (especially change-order and payment-release language)
- [ ] Apollo approval on Proposal Page 1 + Pricing layouts (highest-impact pages)

---

*End of Proposals, SOWs, and Invoices Spec v1.0.*
