# Pitch Deck — Outline & Structure
**Pegasus Dreamscapes**
Version 1.0

---

## Use case

The deck Apollo presents in a 30-minute meeting to investors, partners, or strategic prospects when a one-pager is insufficient. Maximum **15 slides**. If the conversation needs more than 15, the conversation should be a working session, not a pitch.

For capital-specific decks (asks for specific deal capital), use `05_Investor_Deck_Outline.md` instead.

---

## Format

- **Aspect ratio:** 16:9 (presentation standard)
- **Background:** Midnight `#1A2332` default; one Cream slide permitted for visual breath
- **Typography:** Per `01_BRAND_GUIDE/03_Typography_System.md` marketing hierarchy
- **Logo placement:** Pegasus Dreamscapes horizontal logo top-left of every slide except cover (which uses primary stacked, large, centered)
- **Slide numbers:** Bottom-right, Inter Regular 10pt, Copper

---

## Slide structure (15-slide spine)

### Slide 1 — Cover
- Pegasus Dreamscapes primary stacked logo, centered
- Below logo: "DREAM IT. BUILD IT. LIVE IT." tagline, Inter Medium, Copper
- Bottom-right: presentation date + audience name (e.g., "October 2025 — Smith Family Office")
- Bottom-left: "Confidential" in Inter Regular, 10pt, Cream at 60%

### Slide 2 — The thesis
- One-sentence headline (Playfair, 40pt): the company in one sentence
- Three supporting bullets (Inter, 18pt): what the company does, who it does it for, why now
- This slide alone should make the case to keep listening

### Slide 3 — The problem
- Headline: the operator pain Pegasus solves
- Three numbered points (specific, data-backed where possible)
- Avoid hyperbole ("the industry is broken"); use specifics ("fix-and-flip operators lose 14% to coordination overhead")

### Slide 4 — Our approach
- The Pegasus model: vertical integration + proprietary software
- Visual: simple diagram (the three-arm architecture from `01_BRAND_GUIDE/06_Brand_Architecture.md`)
- Three or four short captions explaining the layers

### Slide 5 — Market
- TAM / SAM / SOM if relevant
- Geographic focus map (Bay Area + Sacramento; Guadalajara as legacy/long-term)
- Source citations at bottom in Inter Regular 9pt

### Slide 6 — Traction
- Current operational metrics: deals closed, capital deployed, projects in progress
- One headline number (Playfair, 60pt, Copper) + supporting context
- Honesty discipline: small numbers stated honestly beat large numbers stated vaguely

### Slide 7 — Case study #1
- A specific completed deal: address, acquisition price, all-in basis, ARV / sale price, return
- Before / after photo (when available)
- Three-line narrative of how the deal happened

### Slide 8 — Case study #2 (optional, depends on deal volume)
- Same structure as Slide 7
- If only one completed deal exists, replace this slide with a "Pipeline" slide showing under-LOI deals

### Slide 9 — Pegasus Systems (the software arm)
- The system that runs Pegasus Dreamscapes also runs the broader operator market
- Visual: the five-product fleet
- One sentence per product

### Slide 10 — The team
- Apollo + named contributors (father Moises Duran as licensed GC; partner as interior designer)
- Each person: photo, name, role, one-line credibility statement
- Honest about team size; do not invent advisors

### Slide 11 — Why now
- The market timing argument: distressed inventory cycles, interest rate environment, software-enabled operator advantage
- Three concise points; resist the urge to write essays

### Slide 12 — The ask
- What Apollo is asking for in this conversation
- Variant per audience: capital partnership, project partnership, vendor relationship, etc.
- Specific number when applicable (e.g., "$500K LP commitment in Q4 SFR fund")

### Slide 13 — Risks
- Three real risks Pegasus faces and how they are mitigated
- This slide builds credibility; investors trust founders who acknowledge risk
- Keep it to risks Pegasus actually faces, not generic platitudes

### Slide 14 — The vision
- Where Pegasus Dreamscapes is going in 3 years and 10 years
- One paragraph each, Playfair display
- The Guadalajara legacy project lives here

### Slide 15 — Contact / next step
- Apollo Duran + contact info
- Suggested next step: "Diligence package on request" or "Schedule a property tour" or "Pegasus HQ demo"
- Pegasus Dreamscapes primary stacked logo, centered, smaller than cover

---

## Slide design rules

1. **One idea per slide.** If a slide has two ideas, it's two slides.
2. **No more than 30 words per slide.** Operator-mature decks are read fast and discussed in person.
3. **No bullet point lists deeper than one level.** No nested sub-bullets.
4. **Visuals are restrained.** No stock photography. No icon farms. No clipart. Photography is project-specific (real Pegasus deals) or restrained brand graphics.
5. **Animations: none.** Slides do not animate. Slide transitions are cuts. Anyone who builds in flying-text or zoom-in transitions is correcting away from operator discipline.
6. **Charts and numbers are tabular-figure aligned.** Use Inter with `tnum` enabled for all financial slides.

---

## Anti-patterns (do not include)

- A "We are passionate about real estate" slide
- A "Our values" slide (values are demonstrated, not declared)
- A "Why us" slide that lists adjectives instead of evidence
- A team slide with placeholder advisors who haven't actually committed
- A "Roadmap" slide with a 36-month timeline that no one believes
- A stock photo of a handshake
- A stock photo of a city skyline
- An "Imagine if…" slide

---

## File outputs

- `pegasus-deck_template_master.fig` (Figma source)
- `pegasus-deck_template.pptx` (PowerPoint editable)
- `pegasus-deck_template.key` (Keynote, optional)
- `pegasus-deck_master-export.pdf` (filled-in master, current snapshot)

---

## Pre-lock checklist

- [ ] All 15 slide layouts designed in master template
- [ ] All copy zones marked with placeholder copy (so future edits stay in-bounds)
- [ ] Brand fonts embedded
- [ ] Page numbering, headers, footers set as master elements (not per slide)
- [ ] Test export to PDF; verify no font substitution
- [ ] Apollo approval on cover, Slide 2 (thesis), and Slide 12 (ask) layouts — these are the highest-stakes slides

---

*End of Pitch Deck Outline v1.0.*
