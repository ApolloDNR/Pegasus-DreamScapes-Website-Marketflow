# Investor Deck — Outline & Structure
**Pegasus Dreamscapes**
Version 1.0

---

## Use case

The deck used in capital-raise conversations: LP commitments to a fund, equity investment in a deal, or formal partnership for a specific project. **Higher specificity, more numbers, fewer adjectives** than the generic pitch deck.

This deck is delivered alongside a separate written **Private Placement Memorandum (PPM)** or **Deal Memo** — the deck does not replace those documents. It opens the conversation; the written documents close it.

---

## Format

- 16:9 aspect ratio
- 18–22 slide spine (more than the generic deck because investors require more substantiation)
- Default Midnight background; structured proforma slides may use Cream for legibility
- Tabular figures (`tnum`) required on every numeric slide
- Footer on every interior slide: "CONFIDENTIAL — Pegasus Dreamscapes" in Inter Regular 9pt, Cream at 50%

---

## Slide spine

### Section 1 — Setup (Slides 1–3)

**Slide 1 — Cover**
- Logo, tagline, audience name, date
- "CONFIDENTIAL" stamp

**Slide 2 — Executive summary**
- Five bullets that contain the entire deck:
  - The opportunity (one line)
  - The ask (specific dollar amount + structure)
  - The use of funds (one line)
  - The projected return (one line, with disclosure footnote)
  - The exit timeline (one line)
- A sophisticated investor decides whether to keep listening on this slide

**Slide 3 — The team**
- Apollo + Moises (licensed GC) + key team
- License numbers and credentials called out
- Track record: deals closed, capital deployed, on-time/on-budget rate

### Section 2 — The opportunity (Slides 4–8)

**Slide 4 — Market thesis**
- Why this geography, why this asset class, why this strategy, why now
- Three bullets, each backed by a data point and a citation

**Slide 5 — The deal (or the fund)**
- If single deal: address, photos, basis, ARV, plan
- If fund: investment criteria, target deal count, average deal economics, geographic scope

**Slide 6 — Comparables / underwriting**
- 3–5 comp transactions with addresses, sale prices, dates, sources
- Underwriting assumptions stated explicitly

**Slide 7 — The proforma**
- One full-page table: acquisition, construction, holding costs, exit assumptions, return scenarios
- Three scenarios: Conservative / Base / Upside
- IRR, equity multiple, cash-on-cash for each

**Slide 8 — Risk analysis**
- Real risks (market, construction, financing, execution) with specific mitigations
- Operators who hide risk lose deals; operators who own risk close them

### Section 3 — The operator (Slides 9–13)

**Slide 9 — Why Pegasus Dreamscapes**
- Vertical integration thesis
- Software-powered execution
- Operator-mature documentation discipline
- This is the slide where the operating company's edge is made concrete

**Slide 10 — Pegasus Systems (the moat)**
- The software arm
- Five products diagrammed
- The argument: operators who own their infrastructure own their margins
- Pegasus Dreamscapes is the founding dogfood customer of its own software

**Slide 11 — Track record**
- Completed deals with addresses, basis, exit prices, returns
- Photos
- Honest about scale: a small but well-executed track record beats a large but vague one

**Slide 12 — Reference operators / partners**
- Named contractors, lenders, brokers Pegasus has worked with
- Names that the investor can call to verify

**Slide 13 — Process and reporting**
- How investors receive updates: cadence, format, content
- Pegasus Systems shows up here too — investor portal as a product feature

### Section 4 — The ask (Slides 14–18)

**Slide 14 — The structure**
- Investment vehicle: LP interest in fund, preferred equity in SPV, JV, etc.
- Capital structure: senior debt / mezzanine / equity stack
- Voting and governance terms

**Slide 15 — Use of funds**
- Pie chart or table: where every dollar goes
- Acquisition / construction / soft costs / reserves / fees

**Slide 16 — Returns and waterfall**
- Pref rate, sponsor catch-up, promote splits
- Hypothetical investor return at base and upside scenarios
- All disclosures footnoted

**Slide 17 — The ask**
- Specific dollar amount being raised
- Minimum check size
- Closing target date
- "Subject to definitive documentation" disclosure

**Slide 18 — Next steps**
- Diligence package contents
- Suggested call cadence
- Apollo's contact and direct calendar link

### Section 5 — Appendix (Slides 19–22, optional)

**Slide 19 — Detailed market data**
**Slide 20 — Architectural plans / concept renderings (development deals only)**
**Slide 21 — Legal entity structure diagram**
**Slide 22 — Disclosures and disclaimers (full page)**

---

## Disclosure requirements

Investor decks raising capital from non-friends-and-family must include securities-law disclosures. **This is legal territory; engage securities counsel before distributing the deck broadly.**

Standard disclosure copy (placeholder — counsel must approve actual language):

```
This presentation is for informational purposes only and does not constitute an offer to sell or
a solicitation of an offer to buy any securities. Any such offer or solicitation will be made only
by means of a confidential Private Placement Memorandum and related documentation, and only to
qualified investors. Past performance is not indicative of future results. Real estate investment
involves significant risk, including risk of loss of principal. Forward-looking statements involve
known and unknown risks, uncertainties, and other factors.
```

This copy goes on:
- Slide 22 (full appendix slide)
- Footer of every numeric slide (small)
- Cover slide (small)

---

## File outputs

- `pegasus-investor-deck_template_master.fig`
- `pegasus-investor-deck_template.pptx`
- `pegasus-investor-deck_master-export.pdf` (current filled snapshot)
- Per-deal versions saved as: `pegasus-investor-deck_[deal-name]_[date].pdf`

---

## Pre-lock checklist

- [ ] All slide layouts designed in master template
- [ ] Disclosure copy reviewed by securities counsel before first investor distribution
- [ ] Tabular figures verified on all numeric slides
- [ ] PDF export tested — no font substitution
- [ ] Per-deal customization protocol documented (which slides update per deal vs. stay static)
- [ ] Apollo approval on Slides 2, 7, 14, 16, 17 (the high-stakes financial slides)

---

*End of Investor Deck Outline v1.0.*
