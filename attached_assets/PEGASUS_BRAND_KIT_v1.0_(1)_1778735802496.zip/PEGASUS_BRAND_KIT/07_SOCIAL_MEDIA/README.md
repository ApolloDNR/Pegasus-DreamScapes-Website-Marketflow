# 07_SOCIAL_MEDIA

The social presence is **selective**. Pegasus does not need a presence on every platform — it needs a credible presence on the platforms where its audiences actually live.

## Active platforms (recommended)

| Platform | Audience | Posting cadence |
|---|---|---|
| **LinkedIn** | Capital partners, operators, B2B audiences, Pegasus Systems prospects | 2–3x per week |
| **Instagram** | Project documentation, founder narrative, retail/community audiences, design enthusiasts | 3–5x per week |
| **YouTube** (long-term) | Operator education, project case studies, behind-the-scenes | Monthly when active |

## Deferred / inactive platforms

| Platform | Status | Rationale |
|---|---|---|
| TikTok | Not recommended at founder stage | Volume cadence required is incompatible with operator focus; brand voice does not fit platform format |
| X / Twitter | Optional | Low ROI for Pegasus's audiences; reserve handle defensively |
| Facebook | Defensive only | Reserve page for SEO and Meta ad infrastructure; no organic posting |
| Threads | Not recommended | Same as Twitter |

A presence on LinkedIn + Instagram + (eventually) YouTube is sufficient for the brand stage. **A dead account on a platform is worse than no account.**

## Files

| File | Purpose |
|---|---|
| `01_Profile_Specs.md` | Per-platform profile dimensions, copy, image specs |
| `02_Caption_Bank.md` | Caption templates by post category, with examples |
| `03_Post_Templates_Spec.md` | Visual post templates for each platform |
| `04_Hashtag_Strategy.md` | Per-platform hashtag strategy |

## Doctrine notes

1. **Voice consistency.** Social copy follows the same voice rules as the website and one-pager. Investor-grade tone, even on Instagram. (See `01_BRAND_GUIDE/04_Voice_and_Tone.md`.)
2. **No emoji.** As stated in the voice guide. The brand's discipline is the brand's voice.
3. **No engagement-bait.** No "Comment 'Pegasus' to learn more." No "Tag a friend who needs to see this." The brand earns engagement through substance.
4. **Project-specific photography only.** No stock photos, ever. If there is no real photo, there is no post.
5. **Copy disagrees with platform norms when necessary.** The brand voice does not bend to "what does well on Instagram." Pegasus's audience finds Pegasus because Pegasus is consistently itself.
