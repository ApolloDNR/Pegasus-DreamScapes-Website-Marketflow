# Social Media — Profile Specifications
**Pegasus Dreamscapes**
Version 1.0

---

## LinkedIn — Company Page

### Handle
`linkedin.com/company/pegasus-dreamscapes`

### Profile image (logo)
- **Spec:** 400×400px PNG, transparent background
- **Asset:** `pegasus-dreamscapes_icon_full-color-on-dark.png` from `02_LOGOS/Pegasus_Dreamscapes/`
- **Note:** LinkedIn crops to circle for some surfaces — verify icon centers within a circular safe area

### Banner image
- **Spec:** 1128×191px (LinkedIn cover dimensions)
- **Design:** Midnight `#1A2332` background. Pegasus Dreamscapes horizontal logo centered-left. Tagline "DREAM IT. BUILD IT. LIVE IT." in Inter Medium centered-right, Copper. Thin Copper rule along bottom edge.
- **Asset to produce:** `linkedin-company-banner.png`

### Tagline (LinkedIn "About" tagline, ~120 char limit)
> Vertically integrated real estate operating company. We acquire, develop, and operate — using software we built ourselves.

### About section (full)
> Pegasus Dreamscapes is a vertically integrated real estate operating company headquartered in the San Francisco Bay Area. We operate across three arms: Development (ground-up and value-add construction), Investments (capital deployment across BRRRR, fix-and-flip, wholesale, and held assets), and Systems (Pegasus Systems — the proprietary software arm building the operating infrastructure for disciplined real estate execution).
>
> We don't rent our operating system. We built it.
>
> Bay Area + Sacramento focus. Long-term legacy development project in Guadalajara, Jalisco.
>
> For capital partnerships, property opportunities, vendor relationships, or Pegasus Systems product inquiries: pegasusdreamscapes.com

### Industry: Real Estate
### Company size: 2–10 employees
### Headquarters: San Francisco Bay Area, California
### Founded: [Year]
### Specialties: Real Estate Development, Real Estate Investment, Construction Management, Real Estate Software, BRRRR Strategy, Fix-and-Flip, Property Renovation

---

## LinkedIn — Apollo Personal Profile

Apollo's personal LinkedIn is treated as a brand asset because founder profiles drive disproportionate B2B engagement.

### Profile photo
- Professional headshot — restrained, eye contact, slight smile
- Background: neutral or a subtle Pegasus brand element (Midnight wall) but not the logo

### Banner
- Same dimensions as LinkedIn Company banner (1584×396px for personal vs. 1128×191 for company — verify current spec)
- Design: Midnight background, Apollo's name and title in Cream + Copper, optional Pegasus logo bottom-right

### Headline (under name, ~220 char limit)
> Founder, Pegasus Dreamscapes • Vertically integrated real estate operator + Pegasus Systems (operating software for real estate)

### About section
First-person narrative pulled from `06_WEBSITE/02_Website_Copy_Deck.md` → Founder bio. Adapted for LinkedIn's longer-form expectation (3–4 paragraphs).

### Experience entries
- **Founder, Pegasus Dreamscapes** (current) — multi-paragraph description of role, scope, achievements
- **Founder, Pegasus Systems** (current, if listed separately for SEO) — software arm description
- **Realtor, Keller Williams Realty** — current, with DRE license disclosure
- Prior business ventures (selectively included)

### Featured section
Pinned posts that showcase project case studies, founder thought leadership, Pegasus Systems product announcements

---

## Instagram — Pegasus Dreamscapes

### Handle
`@pegasusdreamscapes` (or `@pegasus.dreamscapes` if primary handle is unavailable — verify and lock)

### Profile image
- **Spec:** 320×320px PNG, will be cropped to circle
- **Asset:** `pegasus-dreamscapes_icon_full-color-on-dark.png`
- **Verify:** Icon centers cleanly within Instagram's circular crop

### Bio (150 char limit)
> Vertically integrated real estate operating company.
> Bay Area + Sacramento.
> Dream it. Build it. Live it.
> ↓ pegasusdreamscapes.com

### Link in bio
`pegasusdreamscapes.com` (single link; if a Linktree-style aggregator is needed later, build a Pegasus-branded redirect page at `pegasusdreamscapes.com/links` rather than using a third-party service — keeps the brand on-domain)

### Story highlights
Five highlights, each with custom Pegasus-branded covers:

| Highlight | Cover icon | Contents |
|---|---|---|
| Projects | Roofline icon, Copper on Midnight | Project documentation, before/after, finished spaces |
| Process | Blueprint grid icon | Behind-the-scenes, jobsite documentation |
| Founder | Apollo silhouette icon | Personal narrative, founder updates |
| Systems | Stack icon | Pegasus Systems updates, product features |
| Press | Star icon | Media mentions, podcast appearances |

Highlight cover spec: 1080×1920px Story format, simple icon centered on Midnight, Cream icon outline.

---

## Instagram — Apollo Personal (optional)

If Apollo wants a separate personal Instagram, the recommendation is **don't, at the founder stage.** Pegasus is the brand; Apollo is the founder of the brand. A separate personal account dilutes attention without adding leverage. Use the Pegasus Dreamscapes account and let Apollo's voice come through there.

If a personal account is created later (e.g., for Guadalajara legacy project content or family/lifestyle that doesn't fit Pegasus), keep it tightly separated from Pegasus business content.

---

## YouTube — Pegasus Dreamscapes

### Handle
`youtube.com/@pegasusdreamscapes`

### Profile image
- **Spec:** 800×800px PNG (YouTube minimum)
- **Asset:** `pegasus-dreamscapes_icon_full-color-on-dark.png` upscaled appropriately

### Channel banner
- **Spec:** 2560×1440px (with safe area considerations for cross-device rendering)
- **Design:** Midnight background. Pegasus horizontal logo centered. Tagline below. Copper accent line. Mindful of YouTube's TV/mobile/desktop crop areas.

### Channel description
> Pegasus Dreamscapes is a vertically integrated real estate operating company. This channel documents our projects, shares our operating playbook, and showcases the software we build to run the company — Pegasus Systems.
>
> For business: pegasusdreamscapes.com

### Channel sections (when content exists)
- Featured video: latest project case study or Pegasus Systems demo
- Project case studies (playlist)
- Pegasus Systems demos (playlist)
- Founder talks (playlist)

YouTube is a Phase 5+ deliverable. Reserve the handle, build the visual assets, but do not publish until content cadence can sustain it.

---

## Cross-platform rules

1. **Handle consistency.** Use `@pegasusdreamscapes` everywhere it's available. Lock variations defensively.
2. **Profile image consistency.** Same Pegasus icon on every platform. Recognition is built through repetition.
3. **Bio copy consistency.** Each platform has its own length constraint, but the substance is the same: who we are, what we do, where to find us.
4. **Link consistency.** Drive every platform's link to `pegasusdreamscapes.com` (or a sub-path). Do not split traffic across multiple destinations.
5. **No platform-native frills.** No Instagram Reels with trending audio that doesn't fit the brand. No LinkedIn polls about generic real estate trivia. The brand voice does not bend to platform formats — the platforms get adapted *to* the brand voice.

---

## Pre-launch checklist

- [ ] All handles claimed and locked across LinkedIn, Instagram, YouTube, plus defensive holds on Twitter/X, Facebook, TikTok, Threads
- [ ] Profile images and banners produced for active platforms
- [ ] Bios and About sections finalized and approved
- [ ] Story Highlights set up on Instagram with custom covers
- [ ] Verification badges pursued where eligible (LinkedIn Company verification, Meta Verified, etc.)
- [ ] Instagram and LinkedIn posting calendar drafted for first 30 days
- [ ] Apollo's personal LinkedIn updated to new branding

---

*End of Profile Specs v1.0.*
