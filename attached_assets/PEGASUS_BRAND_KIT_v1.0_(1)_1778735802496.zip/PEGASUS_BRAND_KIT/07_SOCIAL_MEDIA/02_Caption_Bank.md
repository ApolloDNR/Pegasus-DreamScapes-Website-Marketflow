# Social Media — Caption Bank
**Pegasus Dreamscapes**
Version 1.0

---

## How to use this document

These are working caption templates organized by post category. Each category includes the structural template and 2–3 worked examples.

**Caption discipline:**
- Every caption follows `01_BRAND_GUIDE/04_Voice_and_Tone.md`
- No emojis
- No "🚨 BIG NEWS 🚨" — operator-mature voice doesn't shout
- No engagement-bait ("Comment your thoughts!" / "Tag a friend!")
- Maximum five hashtags, placed at the end as a separate paragraph
- LinkedIn captions: longer is fine (LinkedIn rewards substance)
- Instagram captions: tighter is better (most won't read past the first line)

---

## Category 1 — Project announcement (closing a deal)

### Template
```
[Property type + location] is closed.

[One-sentence summary of the deal: strategy, basis, plan]

[One-sentence operator note: what made this deal interesting, what we learned, what comes next]

[Hashtag block]
```

### Example A — LinkedIn
> Concord SFR is closed.
>
> Acquired at $410K, all-in basis projecting $560K, ARV at $640K. BRRRR strategy with a 90-day rehab window before refinance. The deal came through a probate referral — third one this quarter, which is starting to look like a pattern worth investing in.
>
> Construction starts Monday. Updates as we go.
>
> #BayAreaRealEstate #BRRRR #RealEstateInvesting #PegasusDreamscapes

### Example B — Instagram (tighter)
> Concord SFR — closed.
>
> $410K acquisition, $640K ARV, 90-day rehab window. BRRRR play. Construction starts Monday.
>
> #BayAreaRealEstate #BRRRR #PegasusDreamscapes

---

## Category 2 — Before/after / project documentation

### Template
```
[Project name] — [phase: demo / framing / finish / completed]

[One-sentence description of what the photo/video shows]

[Optional: one operator detail — material choice, timeline insight, scope decision]

[Hashtag block]
```

### Example A
> 1234 Elm — kitchen demo, day 3.
>
> The original galley wall came out clean — no mechanical surprises behind it. Plumbing rough-in starts Wednesday.
>
> #RenovationInProgress #BayAreaRealEstate #PegasusDreamscapes

### Example B
> Walnut Creek BRRRR — finished kitchen.
>
> Honed quartz counters, walnut cabinetry, brass hardware. Designed by [partner's name], built by Moises Duran. From acquisition to refinance: 94 days.
>
> #RenovationComplete #InteriorDesign #BayAreaRealEstate #PegasusDreamscapes

---

## Category 3 — Founder voice / philosophy

### Template
```
[Concise observation or principle — one or two sentences]

[Brief expansion or context — one paragraph]

[Tie back to operating principle, current work, or invitation]

— Apollo
```

### Example A — LinkedIn
> Most operators rent their systems. We built ours.
>
> Spent the first year of Pegasus running deals out of Notion, Google Sheets, and email threads — the same stack every other operator uses. Then I watched our team lose three days reconciling a single deal because four people had four versions of the truth.
>
> So we built Pegasus HQ. Every deal is one record. Every approval is one event. Every dollar is one ledger entry. Then we made it good enough that other operators could use it too. That's Pegasus Systems.
>
> The operators who own their infrastructure end up owning their margins.
>
> — Apollo
>
> #RealEstate #OperatorMindset #PegasusDreamscapes #PegasusSystems

### Example B — Instagram
> Architecture before building.
>
> The most expensive mistakes happen when you start swinging hammers before you finish thinking. We lock our scope before we touch a wall. Our deals close on time because the decisions were already made.
>
> — Apollo
>
> #RealEstate #PegasusDreamscapes

---

## Category 4 — Educational / market commentary

### Template
```
[Headline observation — concise, specific]

[Three numbered or bulleted points unpacking it]

[Optional: brief operator-specific takeaway]

[Hashtag block]
```

### Example A — LinkedIn
> Three things that quietly determine whether a fix-and-flip survives:
>
> 1. Whether your contractor was paid on time on the last project. (Operator reputation compounds.)
> 2. Whether your scope was written, not described. (Verbal scope = scope creep.)
> 3. Whether your exit comp was a comp, or a comp-with-an-asterisk. (One mis-comp eats your margin.)
>
> Most failed flips fail on these three before they ever fail on the renovation.
>
> #RealEstate #FixAndFlip #BRRRR #PegasusDreamscapes

### Example B — Instagram
> The proforma you don't trust is the proforma that wasn't underwritten.
>
> If your numbers depend on a comp from 2022, you don't have numbers — you have hope.
>
> #BayAreaRealEstate #PegasusDreamscapes

---

## Category 5 — Pegasus Systems / product update

### Template
```
[Product name + what shipped or is shipping]

[One paragraph explaining what it does and why it matters operationally]

[CTA: see the product, request demo, etc.]

[Hashtag block]
```

### Example A — LinkedIn
> CapStack alpha is live for the first three external operators.
>
> CapStack is the capital management product in the Pegasus Systems fleet — investor tracking, distribution waterfalls, equity rollforward, and the start of our embedded-finance roadmap. It's been running Pegasus Dreamscapes' capital stack for six months. We're now opening it to operators we've been talking to since last year.
>
> If you're running a capital stack out of spreadsheets and you're tired, let's talk.
>
> pegasussystems.com/capstack
>
> #RealEstateTech #ProptechSaaS #PegasusSystems

### Example B — Instagram
> Pegasus HQ — the War Room view.
>
> Every deal lives here from day 1. Strategy approval is the ignition event: tasks generate, documents generate, milestones generate, departments activate. One transaction, one record, one source of truth.
>
> See it: pegasussystems.com/hq
>
> #PegasusSystems #RealEstateTech

---

## Category 6 — Recognition / partner spotlight

### Template
```
[Partner name + what they did]

[One paragraph: how they delivered, why it mattered, what's next]

[Optional: tag/mention if they have a Pegasus-relevant social presence]

[Hashtag block]
```

### Example
> Moises Duran (general contractor, founding partner, dad) wrapped framing on the 1234 Elm BRRRR three days early.
>
> Three days isn't a marginal win — it's the buffer that keeps the rest of the schedule intact when something downstream slips. That's the difference between operator-grade contractors and everyone else.
>
> Onto plumbing rough-in.
>
> #RealEstate #Construction #PegasusDreamscapes

---

## Category 7 — Hire / team announcement

### Template
```
[Welcome name to role.]

[One paragraph: their background, what they own at Pegasus, why this matters to the company]

[Welcome line]

[Hashtag block]
```

### Example
> Welcome [Name] to Pegasus Dreamscapes as our [Role].
>
> [Name] joins us from [previous company / context], where they [specific achievement]. At Pegasus, they own [specific function or arm]. Their first project: [specific opening assignment].
>
> Glad to have them.
>
> #PegasusDreamscapes

---

## Category 8 — Testimonial / capital partner story

### Template
```
"[Quote from partner — 2-3 lines max]"
— [Partner name, role, optional company]

[One sentence of context: what relationship, what was delivered]

[Hashtag block]
```

Use sparingly. Testimonials lose force when overused.

---

## Hashtag strategy

Maximum five hashtags per post. Placed at the end as a separate paragraph (not woven into copy). Mix of brand, category, and audience tags.

### Brand tags (always include 1)
- `#PegasusDreamscapes`
- `#PegasusSystems` (when post is about software)

### Category tags (include 1–2)
- `#RealEstate`
- `#RealEstateInvesting`
- `#BRRRR`
- `#FixAndFlip`
- `#RealEstateDevelopment`
- `#PropTech`
- `#RealEstateTech`

### Geography tags (include 1)
- `#BayAreaRealEstate`
- `#SacramentoRealEstate`
- `#CaliforniaRealEstate`

### Audience tags (include 1, situational)
- `#OperatorMindset`
- `#RealEstateOperator`
- `#InteriorDesign` (for design-heavy project posts)
- `#Renovation`

**Avoid:**
- Trend hashtags (#MondayMotivation, #ThrowbackThursday) — generic and off-brand
- Engagement-farm tags (#Follow4Follow, etc.)
- Hashtag stuffing (more than five reads as spam)
- Branded hashtags that are too specific to gain volume (`#PegasusDreamscapesBRRRRDeals` — never)

---

## Posting cadence (recommended starting point)

### LinkedIn
- 2–3 posts per week
- Mix: 1 founder voice / 1 project documentation / 1 educational or product

### Instagram
- 3–5 posts per week (mix of feed posts and Stories)
- Stories: project documentation, behind-the-scenes, day-in-the-life
- Feed posts: project announcements, finished work, founder voice

### Quality > quantity
A week with two excellent posts beats a week with seven mediocre posts. Operator-mature brands are remembered for what they *don't* post as much as for what they do.

---

## Pre-launch checklist

- [ ] Apollo reviews and approves caption bank
- [ ] First 10 posts drafted and queued before any platform launches publicly
- [ ] Photography assets (real project photos) sourced for first 10 posts
- [ ] Hashtag set finalized
- [ ] Posting schedule (which days, which times) agreed
- [ ] Response protocol for DMs and comments documented (who responds, in what voice, how fast)

---

*End of Caption Bank v1.0.*
