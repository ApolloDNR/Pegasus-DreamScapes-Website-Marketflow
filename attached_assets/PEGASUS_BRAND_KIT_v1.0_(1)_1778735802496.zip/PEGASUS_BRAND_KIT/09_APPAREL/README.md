# 09_APPAREL

Operator wardrobe specifications. See `Apparel_Spec_Sheet.md`.

## Files

| File | Status |
|---|---|
| `Apparel_Spec_Sheet.md` | ✓ Specification locked |
| Embroidery files (.dst) | Pending digitization |
| Garment-on-body photos | Pending production |

## Production phasing

**Phase 1 (founder priority):** Jacket + Polo + Cap — three garments, Apollo's working wardrobe + 1–2 sample sizes per garment for partner gifting

**Phase 2 (team expansion):** Add T-shirt, Button-up, Hoodie when team grows

**Phase 3 (specialty):** Vest, beanie, and other situational garments
