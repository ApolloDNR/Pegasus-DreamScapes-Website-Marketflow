# 09_APPAREL — Specification
**Pegasus Dreamscapes**
Version 1.0

---

## Doctrine: operator wardrobe, not merch line

Pegasus apparel is not merchandise for fans. It is the operating wardrobe — what Apollo and the team wear on jobsites, in client meetings, and in social documentation. Every piece is a brand surface.

The objective: a small, premium, coherent set of garments that all fit the brand. Not 14 t-shirt designs.

---

## Recommended garment set (Phase 1)

A founder-stage operating company needs five core pieces. Add others only when there's a real reason.

| Garment | Use case | Priority |
|---|---|---|
| **Quilted/puffer brand jacket** | Cold-weather operator wear, jobsites, brand photos | 1 |
| **Collared polo (premium tier)** | Client meetings, capital meetings, business casual | 1 |
| **Button-up shirt** | Capital meetings, formal client meetings, photo ops | 2 |
| **T-shirt (premium tier)** | Casual operator wear, off-jobsite, founder content | 2 |
| **Cap (low-profile)** | Jobsites, sun protection, social documentation | 1 |
| Hoodie (mid-weight) | Cool-weather casual, founder content | 3 |
| Construction vest (high-vis) | Active jobsite safety wear | 3 |
| Beanie | Cold-weather jobsite | 3 |

Phase 1 produces priorities 1–2 (five garments). Priority 3 added as needed.

---

## Garment selection (premium tier sources)

**Tier:** premium-private-label. Avoid generic Hanes/Gildan blanks. They wash poorly and signal mid-tier merch.

Recommended sources:
- **Comfort Colors** (premium tee blanks, washed garment dye)
- **Carhartt** (jackets, vests — operator-credible, durable)
- **Patagonia** (jackets, polos — premium operator wear)
- **Charles Tyrwhitt** or **Faherty** (button-ups)
- **Richardson** or **The H&L Co.** (caps — premium structured caps, not generic 5-panels)
- **Embroidme** or local Bay Area embroidery shops (production)

Apparel selection is itself a brand decision. The Carhartt jacket says "operator who works." The Patagonia jacket says "operator who's also at the capital meeting." Both are correct in different contexts; pick deliberately.

---

## Logo placement (locked)

| Garment | Position | Logo variant | Size |
|---|---|---|---|
| Jacket | Left chest | Pegasus Dreamscapes horizontal | 3.0–3.5" wide |
| Jacket | Right sleeve (optional) | Pegasus icon only | 1.5" tall |
| Polo | Left chest | Pegasus Dreamscapes horizontal | 2.5–3.0" wide |
| Button-up shirt | Left chest | Pegasus icon only (subtler for shirt context) | 1.0" tall |
| T-shirt | Left chest | Pegasus icon only | 1.5–2.0" tall |
| T-shirt | Optional back | Pegasus Dreamscapes horizontal | 6–8" wide (centered, upper back) |
| Hoodie | Left chest | Pegasus Dreamscapes horizontal | 3.0" wide |
| Hoodie | Optional sleeve | Pegasus icon only | 1.5" tall |
| Cap | Front center | Pegasus icon only | 2.5" wide |
| Cap | Back closure strap (optional) | Pegasus wordmark only | 2.0" wide |
| Cap | Side panel (optional) | Tagline "DREAM IT. BUILD IT. LIVE IT." | Stitched in copper, small |
| Vest | Left chest + back yoke | Pegasus horizontal (chest) + Pegasus stacked (back) | 3.0" / 6.0" |
| Beanie | Front cuff | Pegasus icon only | 2.0" tall |

**Rule:** Logo placement maximum is two positions per garment (chest + sleeve, or chest + back). Three or more positions reads as merch, not operator wardrobe.

---

## Color and thread specifications

### Garment colors (approved)
- Midnight (black or near-black) — primary
- Cream (off-white / natural) — secondary
- Charcoal grey — acceptable
- Navy — acceptable

**Not approved as garment colors:** any saturated brand color outside the palette (no copper-colored shirts, no navy-on-navy that reduces logo contrast).

### Embroidery thread colors
- **Copper:** Madeira Polyneon 1623 (Copper) — confirm against physical thread sample
- **Cream:** Madeira Polyneon 1949 (Light Beige) or equivalent — match the brand Cream `#D4CFC4`
- **Midnight:** Madeira Polyneon 1701 (Black) — for use on light garments

### Thread treatment rules
- **Logo on Midnight garment:** Cream + Copper thread (matches brand colors)
- **Logo on Cream garment:** Midnight + Copper thread
- **Logo on Charcoal/Navy garment:** Cream + Copper (test contrast first)
- **One-color application** (cost-saving tier): Cream thread on dark garments, Midnight thread on light garments — Copper accent dropped

---

## Embroidery file requirements

For embroidery vendors:
- File format: `.dst` (Tajima — most universally supported) and `.emb` (Wilcom)
- Stitch count: optimized per logo size; avoid over-stitching small logos (creates puckering)
- Backing: tear-away or cut-away appropriate to garment weight (vendor's call)
- Underlay: required for logo durability through wash cycles

**Embroidery digitizing is a specialty skill.** The vector logo file alone is not an embroidery file. A digitizer must convert the artwork to stitch paths for each size and garment type. Budget for this conversion as a separate line item per logo variant.

Standard digitizing scope per size:
- Pegasus Dreamscapes horizontal at 3.0" — single digitization
- Pegasus icon at 1.5" — single digitization
- Pegasus icon at 2.5" — separate digitization (resizing within an embroidery file degrades stitch quality)
- Wordmark only at 2.0" — separate digitization

---

## Sizing strategy

### For the team
- Apollo's wardrobe: 3 of each (rotation)
- Field/construction team: 2 of each per person
- Special events / capital meetings: extras of polos and button-ups

### For partners / vendors / capital partners (gifting)
- Premium polo or jacket as occasional founder gift
- Branded cap for jobsite visitors
- **Not:** cheap t-shirts handed out as swag — off-brand

### Size range
Premium garments often have inconsistent sizing across brands. Order one of each size before committing to a production run; field-test for fit and shrinkage after washing.

---

## Production specifications

| Spec | Value |
|---|---|
| Embroidery technique | Standard fill stitch + satin stitch outline |
| Stitch density | Medium-high (premium feel) |
| Wash test | Vendor must run pre-production wash test on sample garment |
| Tag treatment | Manufacturer tag retained; no Pegasus inner-tag printing (premium garments do not need additional tagging) |
| Packaging (for gifted items) | Tissue paper + Pegasus-branded paper sleeve or simple kraft box; no plastic |

---

## Files needed in `12_VENDOR_READY/`

- [ ] `pegasus-dreamscapes_embroidery_horizontal_3in.dst`
- [ ] `pegasus-dreamscapes_embroidery_icon_1in.dst`
- [ ] `pegasus-dreamscapes_embroidery_icon_1.5in.dst`
- [ ] `pegasus-dreamscapes_embroidery_icon_2.5in.dst`
- [ ] `pegasus-dreamscapes_embroidery_wordmark_2in.dst`
- [ ] Production spec sheet with thread color callouts, placement diagrams, garment recommendations

---

## Pre-production checklist

- [ ] Garment samples ordered and fit-tested
- [ ] Embroidery files digitized and approved
- [ ] Thread colors confirmed against physical samples
- [ ] Vendor sample garment produced and approved before mass run
- [ ] Wash test conducted on sample
- [ ] Apollo approval on each garment + logo combination

---

*End of Apparel Spec v1.0.*
