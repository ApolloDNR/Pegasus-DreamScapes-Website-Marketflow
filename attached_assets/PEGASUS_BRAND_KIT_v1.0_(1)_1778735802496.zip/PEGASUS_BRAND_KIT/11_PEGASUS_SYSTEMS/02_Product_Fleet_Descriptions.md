# Product Fleet — Descriptions
**Pegasus Systems**
Version 1.0

---

## The fleet at a glance

| Product | Role | Authority | Tagline |
|---|---|---|---|
| **Pegasus HQ** | Command core / source of truth / deal execution OS | Commands | Command core for real estate execution. |
| **BuildForge** | Construction execution / development workflows | Proposes | Construction execution, built with discipline. |
| **CapStack** | Capital management / investor tracking / funding structure | Proposes | Capital structure with clarity. |
| **MarketFlow** | Deal distribution / listings / market pipeline | Proposes | Move opportunities through the market. |
| **Peggy** | AI advisor / intelligence layer | Advises | Intelligence at every step. |

Five products. One doctrine. **HQ commands. Fleet proposes. Peggy advises.**

---

## 1. Pegasus HQ

### One-line
The command core for disciplined real estate operations.

### Two-line
The single source of truth for every deal a real estate operator runs. Strategy approval is the ignition event that generates the tasks, documents, milestones, and department activations the deal needs to actually execute — atomically, in a single transaction.

### Marketing paragraph
Real estate operators run their businesses across spreadsheets, sticky notes, email threads, and a dozen disconnected tools. Pegasus HQ replaces all of it with one record per deal. Every lead is a deal from day one. Every deal opens a War Room immediately. Strategy approval triggers an atomic transaction that generates all tasks, documents, milestones, and department activations — the moment that turns intent into operational reality. From there, the operator commands; the rest of the Pegasus Systems fleet executes; Peggy advises along the way.

### Pitch deck slide copy
> The command core. Every deal lives here from day one. Strategy approval is the ignition event — one atomic transaction generates everything the deal needs to execute. The single source of truth.

### Audience
Every Pegasus Systems customer. Pegasus HQ is the entry point; the rest of the fleet integrates through HQ.

### Authority position
**Commands.** All operational truth originates in HQ. Every other product writes back to HQ as the source of record.

### Key concepts (locked vocabulary)
- **War Room** — the per-deal workspace; opens immediately on deal creation
- **Strategy Approval** — the atomic ignition event; generates tasks, documents, milestones, and department activations
- **Pegasus Stamp** — evidence-of-completion artifact attached to milestones (per Blueprint Stamp evidence schema)
- **Authority Hierarchy** — HQ commands → Fleet proposes → Peggy advises
- **Append-only ledger** — financial records are never overwritten; corrections are journaled
- **Department activation** — strategy approval activates the relevant operational departments (acquisitions, construction, capital, marketing, etc.)

### Tagline
**Command core for real estate execution.**

### Domain / surface
Lives at `app.pegasussystems.com/hq` (or `hq.pegasussystems.com` — to be confirmed).

---

## 2. BuildForge

### One-line
Construction execution for real estate operators — built with discipline, not as an afterthought.

### Two-line
The Pegasus Systems product for managing construction inside the operator's full deal lifecycle. Project workflows, milestone tracking, contractor coordination, scope-and-payment integrity — all routed through Pegasus HQ as the source of truth.

### Marketing paragraph
Most "construction software" is built for general contractors. BuildForge is built for the operator who is paying the GC. It tracks scopes against contracts, releases milestone payments against inspection triggers, and flags scope creep before it eats the proforma. Every BuildForge action is recorded in the deal's Pegasus HQ War Room — so when the operator looks at the deal, they see one truth, not three reconciled exports. BuildForge proposes; HQ commands.

### Audience
Operators running ground-up development, substantial renovation, BRRRR construction, or multi-phase value-add. Operators who run construction occasionally as part of broader deal flow benefit; full-time GCs are not the primary audience (Procore serves that segment).

### Authority position
**Proposes.** BuildForge generates change orders, payment release proposals, scope adjustment requests — all of which require HQ-level approval before execution.

### Key concepts
- **Scope of Work (SOW)** — the contractual unit BuildForge tracks
- **Milestone payment** — released against inspection trigger; standard 48-hour release window
- **Change order** — written, priced, and approved before work begins (no verbal change orders)
- **Inspection trigger** — the event that releases the next payment milestone
- **Lien release tracking** — required at each milestone; BuildForge holds payments until received

### Tagline
**Construction execution, built with discipline.**

---

## 3. CapStack

### One-line
The capital management product for real estate operators — built on the append-only ledger doctrine.

### Two-line
CapStack manages the capital structure, investor relationships, and distribution waterfalls for real estate operators. From founder-stage simple capital tracking to multi-investor SPV waterfalls, CapStack scales without forcing operators to switch tools.

### Marketing paragraph
Operators outgrow their capital tracking three times before they admit it. The first time, the spreadsheet works. The second time, the spreadsheet starts to lie. The third time, an investor asks a question and nobody on the team can answer it confidently. CapStack is the capital infrastructure built to handle all three stages without a re-platform. Append-only ledger architecture — every entry is a record, never overwritten. Distribution waterfalls codified, not narrated. Investor portals that operators can hand to LPs without embarrassment. The embedded finance roadmap moves CapStack from ledger to Stripe Connect to embedded lending, the way Toast and Shopify built embedded finance into their categories.

### Audience
Operators raising or deploying capital — from founder-stage friends-and-family rounds through SPV-per-deal structures and eventually small fund management.

### Authority position
**Proposes.** CapStack generates distribution proposals, capital call notices, investor reports — all approved through HQ before execution.

### Key concepts
- **Append-only ledger** — financial records are never overwritten; corrections are journaled with reason codes
- **Distribution waterfall** — codified equity, debt, and promote splits enforced in software
- **Capital call** — formal request to investors for committed capital, generated and tracked in CapStack
- **Investor portal** — read-only investor view of their position, distributions, and reports
- **Embedded finance** — long-term roadmap: payment processing (Stripe Connect) → embedded lending → embedded banking

### Tagline
**Capital structure with clarity.**

### Note on the deprecated FundBase reference
*FundBase* is dead. It has been permanently merged into CapStack. Do not reference FundBase in any Pegasus Systems marketing, documentation, or product surface. The decision has been made; the consolidation is locked.

---

## 4. MarketFlow

### One-line
The deal distribution product — move opportunities through the market with discipline.

### Two-line
MarketFlow manages the outbound deal flow that operators run — listings, off-market dispositions, JV pitches, capital partner outreach. Every opportunity is tracked, every touchpoint is logged, every response is structured.

### Marketing paragraph
Real estate operators distribute opportunities constantly: listings to buyers, off-market deals to fellow operators, JV pitches to partners, capital opportunities to LPs. Most operators run this distribution out of email and a vague memory of who they pitched what. MarketFlow turns it into structured outbound: opportunity records with lifecycle states, response tracking, follow-up cadences, and engagement analytics. When an operator says "we showed this to twelve operators and three came back with offers," MarketFlow is what makes that statement true.

### Audience
Operators with consistent outbound deal flow — wholesalers, capital partners, JV operators, and developers running disposition processes.

### Authority position
**Proposes.** MarketFlow generates outreach proposals, follow-up cadences, response routing — all subject to HQ approval before sending.

### Key concepts
- **Opportunity** — a deal being distributed; has lifecycle states (Drafted → Distributed → Engaged → Decided)
- **Distribution list** — the curated set of recipients for an opportunity; built and maintained inside MarketFlow
- **Response routing** — engagement responses routed back to the originating War Room in HQ
- **Cadence** — structured follow-up timing; default templates per opportunity type
- **Engagement analytics** — open rates, response rates, conversion rates per recipient and per opportunity type

### Tagline
**Move opportunities through the market.**

---

## 5. Peggy

### One-line
The AI advisor inside Pegasus Systems. Recommends. Flags. Never writes without approval.

### Two-line
Peggy is the intelligence layer across Pegasus HQ and the fleet. She reads everything in the operator's deals, surfaces patterns, recommends actions, and flags risks — but per Doctrine 9, she never writes to the system without explicit operator approval.

### Marketing paragraph
Most AI in PropTech promises autonomous action and quietly delivers either nothing or chaos. Peggy is the disciplined alternative. She watches every War Room, every proforma, every contractor interaction, every capital event — and she advises. She'll tell you that this contractor's last three projects ran 11% over budget. She'll flag that this proforma's exit comp is from before the last rate move. She'll recommend that this distressed seller probably needs to hear about a 7-day close, not a 30-day close. But she will not act on any of this. Every Peggy recommendation surfaces in the relevant War Room with a clear "Approve / Reject / Edit" interface — operator-approved before it touches anything in the system. **HQ commands. Fleet proposes. Peggy advises.** Inviolable.

### Audience
Every Pegasus Systems customer. Peggy is bundled into Pegasus HQ; she's not a separate purchase.

### Authority position
**Advises.** Per Doctrine 9, Peggy never writes without explicit operator approval. This is the inviolable constraint.

### Tier structure (per Blueprint architecture)
- **Tier 1** — In-context suggestions and flag-only behaviors (basic Peggy)
- **Tier 2** — Multi-step recommendations across products (Pro Peggy)
- **Tier 3** — Strategic-level advisory across the operator's full portfolio (Enterprise Peggy, with documented boundary structures)

### Key concepts
- **Recommendation** — Peggy's proposed action, surfaced in the relevant War Room
- **Flag** — Peggy's risk signal; surfaced as alert with severity and reasoning
- **Approval boundary** — every Peggy action requires explicit operator approval before it writes; this boundary is structural, not configurable
- **Reasoning trace** — every Peggy recommendation comes with the data and logic that produced it; operators can audit Peggy's thinking, not just her outputs

### Tagline
**Intelligence at every step.**

### Note on Peggy pre-authorization governance
Per Master Blueprint, Peggy pre-authorization governance (allowing Peggy to act on operator-pre-approved patterns without per-instance approval) is batched for v1.1. Until that governance ships, Peggy operates strictly in advise-only mode. Marketing must not promise autonomous action.

---

## Cross-product copy patterns

### When introducing the fleet (in marketing or in-app)
> Five products. One doctrine. HQ commands. Fleet proposes. Peggy advises.

### When introducing the authority hierarchy (in onboarding or sales)
> Pegasus HQ is your command core. The fleet — BuildForge, CapStack, MarketFlow — handles operational specialties. Peggy advises across all of them. Nothing happens without your approval.

### When describing dogfood credibility
> Pegasus Dreamscapes — an active real estate operating company — runs on Pegasus Systems. Every feature ships through real deals before it reaches you.

### When describing the embedded finance roadmap (CapStack)
> CapStack starts as a ledger. It evolves into payment processing (Stripe Connect). It becomes embedded lending. The capital infrastructure operators have been waiting for.

---

## Vocabulary not to use

- "Solutions" — say "products"
- "Synergies" — never
- "Best-in-class" — never
- "AI-powered" — say what Peggy does, not that she "uses AI"
- "Autonomous" — Peggy is not autonomous; she advises
- "Smart" (as in "smart workflows") — describe what the workflow does
- "Seamless" — overused; describe the actual user experience
- "Game-changing" — never

---

## Pre-launch checklist

- [ ] All five product descriptions reviewed and approved by Apollo
- [ ] Authority hierarchy callouts present in every product description
- [ ] Pegasus Stamp, Strategy Approval, War Room vocabulary used consistently
- [ ] Embedded finance roadmap language reviewed for compliance posture (lending claims may require licensing disclosures)
- [ ] Peggy descriptions reviewed for AI honesty (no implicit autonomy promises)
- [ ] Cross-references to Master Blueprint verified (Doctrine 9, append-only ledger, ignition event)

---

*End of Product Fleet Descriptions v1.0.*
