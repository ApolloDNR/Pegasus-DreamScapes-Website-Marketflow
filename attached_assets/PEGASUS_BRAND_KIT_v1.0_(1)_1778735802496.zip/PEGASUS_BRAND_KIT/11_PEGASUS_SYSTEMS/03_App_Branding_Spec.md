# App Branding — Specification
**Pegasus Systems — Application UI Brand System**
Version 1.0

---

## Scope

The brand surface inside the Pegasus Systems product applications: chrome, navigation, icons, splash, login, empty states, loading, notifications, in-product communications.

This is **not** the marketing site spec (`pegasussystems.com` content lives in `04_Product_Site_Copy_Deck.md`). This is what users see when they're inside the product.

---

## Application chrome (locked surface specifications)

Per Master Blueprint:

| Surface | Spec |
|---|---|
| Left Sidebar | 240px expanded; six locked sections; Copper 4px left-edge bar on active item |
| War Room | Eight base tabs per v1.0.1; sticky 96px header; per-tab content layouts |
| Right Sidebar (Intelligence Rail) | Four collapsible panels (Pulse, Notes, Activity, Peggy) + fixed Toolbelt strip |
| Background | Midnight `#1A2332` (default); Navy `#243044` for panels and cards |
| Body text | Cream `#D4CFC4` (90%) on dark surfaces |
| Active state | Copper `#C87A3A` (per Five Uses Rule — sidebar 4px bar, active tab underline) |

These dimensions are doctrine, not preference. Width changes, tab count changes, or panel structure changes require Blueprint version increment.

---

## Login screen

### Layout
- Full-screen Midnight background
- Centered card: Navy `#243044` panel, ~480px wide, generous padding
- Pegasus Systems primary stacked logo at top of card (~160px wide)
- Below logo: "Sign in to Pegasus" — Inter Medium 18px, Cream
- Email field, password field (or SSO buttons), "Sign In" CTA
- Below CTA: "Forgot password" + "Sign up" links in Copper

### Copy lock
- Welcome line: "Sign in to Pegasus"
- Email label: "Email"
- Password label: "Password"
- CTA: "Sign In" (not "Log In")
- Error states: specific, calm — "Email or password didn't match" not "Invalid credentials"

---

## Splash / loading screens

### Splash (app boot)
- Midnight full-screen
- Pegasus Systems icon centered
- Subtle copper pulse animation (slow, 2-second cycle, 70%–100% opacity)
- No copy
- Maximum splash duration: 2 seconds; if app isn't ready by then, transition to a content-aware loading state

### Loading state (in-app)
- Use a skeleton-loading pattern (gray Navy-tinted blocks where content will appear), not spinners
- Spinners only for actions taking >2 seconds where progress is genuinely unknown
- Spinner color: Copper, 24px diameter, 1.5px stroke
- Loading copy when needed: short and specific — "Generating War Room…" not "Loading…"

---

## Empty states

Empty states are critical brand surfaces because they are often the user's first impression of an unused part of the product.

### Pattern
- Centered illustration or icon (use the relevant product icon at 64–96px)
- Below: short Playfair Display headline (24px, Cream)
- Below: Inter Regular paragraph (14px, Cream at 70%) — explains what this surface is for
- Below: Primary CTA button to take the next action

### Copy examples

**Empty War Room list (Pegasus HQ):**
> No War Rooms yet.
>
> A War Room opens automatically every time you create a deal. Start one now to see how the system runs.
>
> [Create your first deal]

**Empty SOW list (BuildForge):**
> No active scopes.
>
> BuildForge tracks construction scopes against contracts and releases payments against inspection triggers. Add a scope to begin.
>
> [Add a scope of work]

**Empty Capital Stack (CapStack):**
> No capital structure yet.
>
> Configure your stack — debt, equity, promote splits — and CapStack will enforce the waterfall on every distribution.
>
> [Configure capital structure]

**Empty Distribution List (MarketFlow):**
> No opportunities distributed.
>
> When you push a deal out for capital, JV, or wholesale, MarketFlow tracks every recipient and response.
>
> [Distribute an opportunity]

**Empty Peggy state:**
> Peggy hasn't surfaced anything yet.
>
> She'll show up here when she has a recommendation for you. She watches everything. She acts on nothing without your approval.
>
> [Configure Peggy preferences]

### Anti-patterns for empty states
- "Looks like there's nothing here yet!" — too casual
- Cartoon mascots or illustrations of "lonely" UI elements — wrong tier
- Aggressive upsell ("Upgrade to Pro to see this!") — wrong tone
- Generic stock illustrations — never

---

## Notifications

### In-app notification panel
Right sidebar panel (per Intelligence Rail spec) shows notifications with:
- **Severity dot** (left edge): Cream (info), Copper (action required), red (urgent — used sparingly)
- **Timestamp** (right): Inter Regular 11px, Cream at 60%, relative format ("3m ago," "2h ago")
- **Body**: Inter Regular 13px, Cream
- **Optional CTA**: inline copper text link

### Email notifications
Brand-consistent email templates with:
- Pegasus Systems horizontal logo at top
- Midnight header band
- Cream body content
- Copper CTAs
- Footer with "Sent by Pegasus Systems" + unsubscribe link

Email subject line patterns:
- Status updates: "[Deal Name] — Status update" (specific, no marketing fluff)
- Approval requests: "Approval needed: [Action] for [Deal Name]"
- Peggy recommendations: "Peggy: [Recommendation summary]"

No subject-line marketing tactics: no emoji, no "🚨", no excessive caps.

---

## In-product copy patterns

### Buttons (action verbs only)
- "Approve Strategy" not "Click here to approve"
- "Generate War Room" not "Get Started"
- "Submit Bid" not "Click to Submit"
- "Save Changes" not "Update"
- "Cancel" not "Nevermind"

### Confirmation dialogs
Pattern: question + clear button labels.

> **Approve this strategy?**
>
> This will generate the deal's tasks, documents, and milestones. This action cannot be undone.
>
> [Cancel] [Approve Strategy]

The destructive or irreversible action goes on the right. Cancel is always present. Confirmation copy is specific about what will happen.

### Toast messages (post-action confirmations)
Short. Specific. Disappear after 4 seconds.

- "Strategy approved. War Room generating."
- "Bid submitted. Awaiting response."
- "Distribution sent to 12 recipients."

### Errors
Specific, calm, actionable.

- "Couldn't save. Check your connection and try again."
- "This SOW already has a payment milestone with that name. Choose another."
- "Peggy can't generate a recommendation without at least one comparable property."

Error tone is matter-of-fact, not apologetic. Operators want to know what happened and what to do, not be soothed.

---

## In-product Peggy surface

Per Doctrine 9, Peggy never writes without approval. The UI must enforce this visibly.

### Peggy recommendation card
- Pegasus Systems-styled card (Navy panel)
- "Peggy" header with the Peggy icon (small, 16px, top-left)
- Recommendation body in Inter Regular
- Reasoning trace (collapsible) — what data Peggy considered
- Three actions: **Approve** (Copper button) / **Edit** (outlined button) / **Reject** (text link)

### What Peggy never shows
- No "Peggy is automatically doing X" messages
- No "Peggy decided" language
- No autonomous-action implications
- No autoplay, auto-execute, or background-write states

If Peggy's behavior in the UI ever appears to violate Doctrine 9, that is a bug, not a feature.

---

## Iconography

### In-product icon set
- Style: outlined icons (1.5px stroke), Cream at 80% default, Copper when active
- Source: Lucide, Phosphor, or custom Pegasus icon set (Phase 2 deliverable)
- Sidebar navigation icons: 20px
- Inline icons: 16px
- Action icons (toolbelt, header): 18px

### Required icon types
| Category | Icons needed |
|---|---|
| Product fleet | HQ, BuildForge, CapStack, MarketFlow, Peggy |
| Navigation | Dashboard, deals, calendar, capital, marketing, settings |
| Actions | Approve, reject, edit, save, send, generate, archive |
| Status / stage | Draft, in progress, approved, completed, paused |
| War Room sections | Strategy, tasks, documents, milestones, ledger, notes |
| Money / ledger | Currency, transaction, payment, distribution, lien |
| Compliance | Stamp (Pegasus Stamp), shield, check, flag |

Icon set delivered as `12_VENDOR_READY/Pegasus_Systems_Icon_Set.svg` (single SVG sprite or per-icon files).

---

## Accessibility in-app

- All text passes WCAG AAA (per `01_BRAND_GUIDE/02_Color_System.md` contrast table)
- All interactive elements have visible focus states (Copper outline, 2px)
- All icons have aria-labels
- Keyboard navigation supported across every primary surface
- Color is never the sole differentiator (status uses both color and label)

---

## Files needed in `12_VENDOR_READY/`

- [ ] `pegasus-systems_app-icon_master.svg`
- [ ] `pegasus-systems_app-icon_ios-1024.png`
- [ ] `pegasus-systems_app-icon_android-512.png`
- [ ] `pegasus-systems_login-screen_mockup.png`
- [ ] `pegasus-systems_splash-screen_mockup.png`
- [ ] `pegasus-systems_email-notification_template.html`
- [ ] `pegasus-systems_icon-set.svg` (full set as a sprite)

---

## Pre-lock checklist

- [ ] All in-app copy reviewed against `01_BRAND_GUIDE/04_Voice_and_Tone.md`
- [ ] Empty state copy approved per product
- [ ] Peggy interaction patterns reviewed for Doctrine 9 compliance (no implicit autonomy)
- [ ] Icon set produced and delivered
- [ ] Email notification templates rendered and tested across email clients
- [ ] Accessibility audit passed for all primary surfaces

---

*End of App Branding Spec v1.0.*
