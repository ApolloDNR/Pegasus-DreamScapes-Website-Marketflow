# Pegasus Systems — Positioning
**The software arm of Pegasus Dreamscapes**
Version 1.0 — Draft

---

## In one sentence

**Pegasus Systems is the operating infrastructure for disciplined real estate execution — built by operators, for operators.**

---

## The pitch in 90 seconds

Real estate operators run their businesses on a stack of tools that wasn't built for them: spreadsheets meant for accountants, CRMs built for SaaS sales teams, project management apps built for software engineers, and email threads holding the whole thing together.

Pegasus Systems is what happens when an operator builds the system they wished existed.

Pegasus HQ is the command core: every deal becomes a War Room from day one. Strategy approval triggers an atomic transaction that generates the tasks, documents, milestones, and department activations the deal needs to actually run. From there, the fleet — BuildForge for construction, CapStack for capital, MarketFlow for distribution — handles the operational specialties without losing the single source of truth. Peggy, the AI advisor, watches everything and recommends, but never writes without operator approval.

It runs Pegasus Dreamscapes today. It is being licensed to the broader operator market starting in 2026.

---

## Who Pegasus Systems is for

### Primary audience: established real estate operators
- Annual deal volume of 5+ deals
- 2–25 person operating teams
- Currently running on a patchwork of Notion, Excel, Airtable, Slack, and email
- Pain point: scope creep, payment delays, lost documents, unclear ownership of decisions
- Trigger event: missed a deadline or lost a deal because the system failed

### Secondary audience: emerging real estate operators (1–4 deals)
- Want to build the discipline before they need it
- Looking for a system that scales as they grow
- Less price-sensitive than enterprise audiences (they buy on conviction, not procurement)

### Not the audience
- Single-family home flippers running 1 deal at a time (overkill)
- Large institutional real estate (different procurement, different feature requirements)
- General contractors (BuildForge handles construction, but Pegasus Systems is positioned to operators, not GCs)
- Real estate agents (KW already serves them; Pegasus HQ is for principals, not agents)

---

## The competitive frame

| Competitor category | Their pitch | Pegasus Systems vs. them |
|---|---|---|
| Notion / Airtable / Coda | "Build whatever you want." | Pegasus is opinionated. Built specifically for real estate operators. The discipline is the product. |
| Buildium / AppFolio | "Property management software." | Pegasus is for operators *acquiring and developing*, not property managers. Different problem. |
| Procore | "Construction project management." | BuildForge handles construction inside the operator's full deal lifecycle. Procore is great at construction; it's not the operator's command core. |
| Carta / Juniper Square | "Investment management." | CapStack handles capital inside the operator's full deal lifecycle. Carta is great at cap tables; it's not the operator's command core. |
| Real estate CRMs (Follow Up Boss, etc.) | "Manage your leads." | Pegasus rejects the lead/deal distinction. Every lead is a deal from day one. CRMs are agent tools; Pegasus is an operator tool. |
| Notion templates sold as "real estate operator OS" | "Drop this template into Notion." | Pegasus is software with logic, not a static template. Strategy approval is an atomic transaction, not a checkbox. |

The unique position: **the only real estate operator OS built by an active real estate operator running it daily**.

---

## The dogfood story (the moat)

Pegasus Dreamscapes — an active real estate operating company — runs on Pegasus Systems. Every feature has been pressure-tested in real deals before it ships to external operators. This is not a marketing claim; it is the architecture.

This means:
- Features that don't work in real operations get killed before they ship
- Features that ship are battle-tested
- The product roadmap is grounded in operator reality, not engineer speculation
- External operators inherit a product that has already paid for its own design through Pegasus Dreamscapes' deals

The dogfood story is the most defensible moat the brand has. It cannot be copied by a SaaS company that doesn't operate; it cannot be copied by an operator who doesn't build software.

### The dogfood blind spot (transparency)

The same dogfood that creates moat also creates risk: features matter to Pegasus Dreamscapes might not matter to other operators with different deal mixes, geographies, or team structures. Pegasus Systems mitigates this through:

1. **External operator beta cohorts** before any major feature ships broadly
2. **Quarterly external-operator roadmap reviews** with Tier 2 customers
3. **Configurable doctrine** — the discipline is opinionated, but the implementation supports operator-specific workflows where the doctrine doesn't depend on uniformity

This is published transparently because operators evaluating Pegasus Systems should know both the strength and the limit of the dogfood model.

---

## The doctrine (Authority Hierarchy)

Locked across every Pegasus Systems product:

> **HQ commands. Fleet proposes. Peggy advises.**

- **Pegasus HQ** is the source of truth. Decisions originate here.
- **Fleet products** (BuildForge, CapStack, MarketFlow) propose changes for HQ approval. They operate standalone and connected.
- **Peggy** advises and recommends. **Peggy never writes without explicit operator approval.** This is Doctrine 9, inviolable.

This authority hierarchy is itself a brand asset. Operators evaluating Pegasus Systems hear "AI advisor" and assume the worst (autonomous AI making changes without their approval). The doctrine — and its visible enforcement in product UI — is what differentiates Pegasus Systems from the AI-everything PropTech wave.

---

## Pricing positioning (per Blueprint)

Three tiers, live on Stripe:

| Tier | Monthly | Audience |
|---|---|---|
| Starter | $49/mo | Emerging operators, 1–4 deals/year |
| Pro | $149/mo | Established operators, 5–24 deals/year |
| Enterprise | $399/mo | Larger operators, 25+ deals/year, multi-team |

All tiers include 14-day free trials. Pricing is intentionally accessible relative to the Carta/Procore tier ($1K+/mo) — the strategy is to win on operator-fit, not on price discount.

The embedded finance roadmap (CapStack → Stripe Connect → embedded lending) creates additional revenue surfaces beyond seat-based SaaS. This is Pegasus Systems' long-term commercial moat.

---

## Voice and tone (Pegasus Systems-specific)

Inherits the parent brand voice (operator-mature, direct, specific) but with shifts:

| Context | Voice shift |
|---|---|
| Product copy (in-app strings) | Concise, action-oriented, never cute. "Approve Strategy" not "Let's lock this in!" |
| Marketing copy (`pegasussystems.com`) | More technical than parent site; can use product/SaaS vocabulary ("workflows," "API," "integrations") where appropriate |
| Documentation | Same operator-mature voice; treat the reader as a competent operator, not a novice. Documentation explains *why*, not just *how*. |
| Sales conversations | First-person operator-to-operator, not third-person sales-to-prospect. Apollo and team can speak as the operators they are. |
| AI feature descriptions (Peggy) | Disciplined transparency. Always describe what Peggy does, what it doesn't do, and where the operator approval boundary sits. |

What stays the same: no AI hedges, no exclamation points, no emoji, no "really" / "just" / "literally" intensifiers.

---

## Endorsement and parent brand relationship

Per `01_BRAND_GUIDE/06_Brand_Architecture.md`:

- Pegasus Systems is publicly an operating company of Pegasus Dreamscapes
- The parent relationship is disclosed in product chrome (footer "By Pegasus Systems"), in product website footers ("An operating company of Pegasus Dreamscapes"), and in pricing/legal documents
- Pegasus Dreamscapes is named as Pegasus Systems' founding dogfood customer in marketing
- External SaaS customers do not need to interact with the parent brand to use the product — the brands are co-existent, not co-mingled

This separation is intentional. SaaS customers should feel like first-class citizens of Pegasus Systems, not second-class citizens of Pegasus Dreamscapes.

---

## Visual identity

Inherits the parent palette and typography. Diverges in:

- **Wordmark:** "PEGASUS SYSTEMS" — its own typographic lockup (see `02_LOGOS/Pegasus_Systems/INTAKE_CHECKLIST.md`)
- **Visual mark:** Suggested direction is a stylized geometric simplification of the wing element — architectural, blueprint-grid feel — without the horse head. Signals "infrastructure" rather than "operating company." Pending designer exploration.
- **Web domain:** `pegasussystems.com`
- **Product UI:** Dark mode primary (per parent doctrine), with scoped light surfaces for printable views and selected dashboards

The parent's "classical" aesthetic translates to Pegasus Systems as "architectural" — a related but distinct visual register more appropriate for product surfaces.

---

## Go-to-market posture

### Phase 0: Dogfood (current)
Pegasus Systems runs Pegasus Dreamscapes. No external customers. Building, breaking, refining.

### Phase 1: Tier-1 closed beta (next)
3–5 hand-selected external operators on Pro tier. Free during beta. Direct feedback channel to Apollo. Pricing applies after beta.

### Phase 2: Tier-2 invite-only (next-next)
20–50 operators across all three tiers. Onboarding through a self-serve flow but with Apollo touchpoint. Stripe live. Public site live.

### Phase 3: Open self-serve
General availability. Public marketing. Inbound + content engine. Pegasus Dreamscapes becomes a customer reference, not the only operator on the platform.

Each phase locks before the next opens. The architecture-before-building doctrine applies to GTM as much as to product.

---

## Open architectural items

1. **Pegasus Systems wordmark and visual mark** — pending design (Phase 2)
2. **`pegasussystems.com` domain** — confirm registered and held; site to be built
3. **`hello@pegasussystems.com`** — domain email account creation
4. **Pegasus Systems brand voice exceptions** — documented above; needs validation against actual product copy when product surfaces ship externally
5. **Pegasus Systems compliance posture** — SaaS contracts, ToS, privacy policy, data processing addenda required before external customers onboard

---

*End of Pegasus Systems Positioning v1.0.*
