# 11_PEGASUS_SYSTEMS

The software arm. This folder is **the SaaS brand kit** — distinct from the parent operating company brand kit, but inheriting palette, typography, and voice.

## Why this folder exists separately

Pegasus Systems is a sub-brand with its own:
- Product surface (eventually a standalone site at `pegasussystems.com`)
- Audience (real estate operators evaluating SaaS, distinct from capital partners or distressed sellers)
- Pricing tier and commercial offering
- Product fleet (five products with distinct positioning)

Treating Pegasus Systems brand assets as just-another-document inside the parent kit would conflate two different go-to-market motions. They share doctrine; they differ in execution.

## Files

| File | Purpose |
|---|---|
| `01_Pegasus_Systems_Positioning.md` | The SaaS arm's brand positioning, audience, and competitive frame |
| `02_Product_Fleet_Descriptions.md` | Locked descriptions for all five products (HQ, BuildForge, CapStack, MarketFlow, Peggy) |
| `03_App_Branding_Spec.md` | UI brand system — application chrome, in-app icons, splash screens, empty states |
| `04_Product_Site_Copy_Deck.md` | Website copy for `pegasussystems.com` (drafted later in Phase 2) |

## Status

**Phase 2 deliverable.** Parent brand (Phase 1) lock takes precedence; Pegasus Systems is built on top of the locked parent palette and typography.

## Inheritance rules

| Element | Inherited from parent | Diverges from parent |
|---|---|---|
| Color palette | ✓ Same four colors | — |
| Typography | ✓ Same two fonts | — |
| Voice | ✓ Same operator-mature voice | Slight shift toward product-first language ("ship," "deploy," "API") in technical contexts |
| Logo | ✗ Own wordmark + mark | Pegasus Systems wordmark, not Pegasus Dreamscapes |
| Tagline | ✗ Own tagline | "Operating infrastructure for disciplined real estate execution." |
| Web domain | ✗ Own domain | `pegasussystems.com` |
| Email | ✗ Own domain | `hello@pegasussystems.com` |
